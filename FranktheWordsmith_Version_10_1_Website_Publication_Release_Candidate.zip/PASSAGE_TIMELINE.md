# Version 5.0 — Passage-Driven 4,000-Year Timeline

## Editorial rule

Every timeline entry is anchored to a specific textual or institutional locator. The archive distinguishes four states: **passage verified**, **page verified in locked edition**, **structural locator only**, and **secondary/reconstructed evidence**. A source is not called a verified quotation merely because the work itself is well known.

## Timeline register

### Ur III period; reign traditionally dated c. 2112–2095 BCE — Laws of Ur-Nammu
- **Source ID:** `ur-nammu`
- **Passage:** RIME 3/2.01.01.20, composite, lines d036–d041 (Q000947)
- **Status:** **Passage verified — CDLI composite text**
- **Evidence:** CDLI records a 1 gur barley loan with annual interest of 1 barig 4 ban2, and a 10-shekel silver loan with annual interest of 2 shekels. citeturn0search1turn0search3
- **Significance:** Direct primary-text evidence for differentiated annual interest on barley and silver loans.
- **Qualification:** The evidence is a composite text, not a claim that one intact tablet preserves the whole passage.
- **Web source:** https://cdli.earth/inscriptions/2234943

### Early second millennium BCE; Early Old Babylonian, c. 2000–1900 BCE — Laws of Eshnunna
- **Source ID:** `eshnunna`
- **Passage:** RIME 4.05.19.add03, Law 18a, lines 62–63
- **Status:** **Passage verified — CDLI composite text**
- **Evidence:** The CDLI composite states 1/6 shekel plus six barleycorns interest per shekel of silver (=20%) and 1 barig 4 ban2 per kor of grain (=33%). citeturn1search0turn1search1
- **Significance:** A secure primary-text anchor for differentiated silver and grain rates before Hammurabi.
- **Qualification:** These are rates specified by the legal provision; they should not automatically be generalized into universal market rates.
- **Web source:** https://cdli.earth/inscriptions/2269340

### Reign of Hammurabi, c. 1792–1750 BCE — Code of Hammurabi
- **Source ID:** `hammurabi`
- **Passage:** Surviving debt provisions §§48–52; the damaged sequence §§66–99 contains the traditional §88 rate passage
- **Status:** **Passage verified for §§48–52; §88 rate wording remains reconstructed**
- **Evidence:** §§48–52 survive in the standard translated presentation and regulate crop failure, suspension of debt obligations, and repayment arrangements. The sequence after §65 is explicitly missing in the Yale/Avalon presentation and resumes at §100, so the familiar §88 20% silver / 33⅓% grain wording is not treated as an intact surviving passage here. citeturn2view0
- **Significance:** Secure evidence for debt and agricultural-risk regulation without overstating reconstructed interest-rate text.
- **Qualification:** A future edition-specific pass may establish a more precise reconstruction of §88, but it must remain labeled as such unless the relevant witnesses are actually extant.
- **Web source:** https://avalon.law.yale.edu/ancient/hamcode.asp

### First millennium BCE / Hebrew Bible — Exodus 22:24 — lending to the poor
- **Source ID:** `exodus-22-24`
- **Passage:** Exodus 22:25 in most modern verse numbering (archive title uses 22:24)
- **Status:** Passage locator verified
- **Evidence:** Prohibits charging interest on a loan to a poor member of the community.
- **Significance:** Early biblical restriction tied to assistance of the poor.
- **Web source:** https://www.biblegateway.com/verse/en/Exodus%2022%3A25

### First millennium BCE / Hebrew Bible — Leviticus 25:35–37 — neshekh and tarbit
- **Source ID:** `leviticus-25-35-37`
- **Passage:** Leviticus 25:35–37
- **Status:** Passage locator verified
- **Evidence:** Prohibits taking neshekh/tarbit from an impoverished community member and frames the rule around sustaining life.
- **Significance:** Provides the principal Torah formulation behind later rabbinic discussions of ribbit.
- **Web source:** https://www.sefaria.org/Leviticus.25.35-37

### First millennium BCE / Hebrew Bible — Deuteronomy 23:20–21 — brother and foreigner
- **Source ID:** `deuteronomy-23-20-21`
- **Passage:** Deuteronomy 23:20–21
- **Status:** Citation locked — passage requires independent text check
- **Evidence:** Distinguishes lending at interest to a fellow Israelite from lending at interest to a foreigner.
- **Significance:** Important qualification within the biblical legal corpus.
- **Web source:** https://www.sefaria.org/Deuteronomy.23.20-21

### c. 2nd century CE — Mishnah Bava Metzia 5 — definitions and mechanisms of ribbit
- **Source ID:** `mishnah-bm-5`
- **Passage:** Mishnah Bava Metzia 5:1–2
- **Status:** Passage verified — stable online text
- **Evidence:** Defines neshekh using examples such as lending a sela and receiving five dinars, and treats certain borrower benefits and deferred-price increases as ribbit.
- **Significance:** Concrete rabbinic classification of direct and indirect interest.
- **Web source:** https://www.sefaria.org/Mishnah_Bava_Metzia.5

### Late antiquity; redacted c. 5th–6th century CE — Babylonian Talmud, Bava Metzia — ribbit sugyot
- **Source ID:** `talmud-bm`
- **Passage:** Babylonian Talmud, Bava Metzia 75a–75b; individual amud required for print citation
- **Status:** Passage verified — stable online text
- **Evidence:** The sugya develops rules and examples concerning ribbit and deferred/extra returns; individual passages should be cited by daf/amud.
- **Significance:** Shows expansion of Mishnah rules through Gemara argumentation.
- **Web source:** https://www.sefaria.org/Bava_Metzia.75a.11-75b.7

### 451–450 BCE — Roman Twelve Tables — early interest regulation tradition
- **Source ID:** `roman-twelve-tables`
- **Passage:** Twelve Tables, Table VIII; later testimony including Tacitus, Annals 6.16
- **Status:** Secondary transmission — not directly extant
- **Evidence:** The Twelve Tables survive only through later fragments/testimony. The identification of the unciarium rate with an annual interest maximum is disputed in modern scholarship.
- **Significance:** Must be presented as transmitted Roman evidence, not as a verbatim surviving tablet.
- **Web source:** https://academic.oup.com/edited-volume/61673/chapter-abstract/548932147

### 6th century CE compilation of earlier Roman law — Digest 22.1 — interest as a Roman legal category
- **Source ID:** `roman-digest-22-1`
- **Passage:** Digesta 22.1, De usuris et fructibus et causis et omnibus accessionibus
- **Status:** Citation locked — individual fragment required
- **Evidence:** The title establishes a dedicated Justinianic compilation section on interest, fruits and related additions; each quotation requires an individual D.22.1.xx fragment locator.
- **Significance:** Roman juristic treatment of interest as a developed legal category.
- **Web source:** https://academic.oup.com/book/36387/chapter-abstract/319983267

### 6th century CE — Codex 4.32 — Justinian on interest
- **Source ID:** `roman-codex-interest`
- **Passage:** Codex 4.32, De usuris
- **Status:** Citation locked — individual constitution required
- **Evidence:** Justinainic constitutions regulate interest; individual C.4.32.xx constitutions must be cited for exact propositions.
- **Significance:** Imperial regulation of interest by legal category and circumstance.
- **Web source:** https://droitromain.univ-grenoble-alpes.fr/Anglica/CJ4_Scott.htm

### 325 CE — First Council of Nicaea — Canon 17
- **Source ID:** `nicaea-canon-17`
- **Passage:** First Council of Nicaea, Canon 17
- **Status:** Passage verified — stable canon locator
- **Evidence:** Canon 17 bars clergy from receiving usury and refers to demanding the hundredth of the sum as monthly interest.
- **Significance:** Early Christian institutional discipline directed at clerical usury.
- **Web source:** https://www.newadvent.org/fathers/3801.htm

### c. 380 CE — Ambrose, De Tobia — Christian condemnation of usury
- **Source ID:** `ambrose-de-tobia`
- **Passage:** De Tobia 9.33; CSEL 32.2, p. 536
- **Status:** Page verified in locked critical edition
- **Evidence:** Selected passage uses the lender/usurer as a moral example in Ambrose’s sustained critique of usury.
- **Significance:** A directly verified patristic passage rather than a generalized attribution to Ambrose.
- **Web source:** https://www.tertullian.org/fathers/ambrose_de_tobia_01.htm

### late 4th–early 5th century CE — Augustine — lending, charity and the poor
- **Source ID:** `augustine-usury`
- **Passage:** Enarratio in Psalmum XXXVI 3.6; CCSL 38, p. 372
- **Status:** Page verified in locked critical edition
- **Evidence:** Selected passage defines the usurer by lending while expecting to receive more than was given, including return in goods rather than money.
- **Significance:** Directly verified Augustinian passage with a narrow textual claim.

### 7th century CE — Qur’an 2:275–279 — ribā and trade
- **Source ID:** `quran-2-275-279`
- **Passage:** Qur’an 2:275–279
- **Status:** Passage verified — canonical verse locator
- **Evidence:** The passage distinguishes trade from ribā and commands abandonment of outstanding ribā claims, culminating in the warning of 2:279.
- **Significance:** Central Qur’anic passage for the prohibition of ribā.
- **Web source:** https://quran.com/2/275-279

### 7th century CE — Qur’an 3:130 — multiplied ribā
- **Source ID:** `quran-3-130`
- **Passage:** Qur’an 3:130
- **Status:** Passage verified — canonical verse locator
- **Evidence:** The verse prohibits consuming ribā, described as multiplied many times.
- **Significance:** An additional early Qur’anic formulation relevant to ribā.
- **Web source:** https://quran.com/3/130

### 3rd century AH / 9th century CE compilation — Sahih Muslim 1587c — ribā in exchange
- **Source ID:** `hadith-muslim-1587c`
- **Passage:** Sahih Muslim 1587c
- **Status:** Citation locked — hadith locator verified
- **Evidence:** Hadith reports conditions for exchange of specified commodities, including unequal/deferred exchange as ribā.
- **Significance:** Hadith foundation for later juristic ribā rules in exchange.
- **Web source:** https://sunnah.com/muslim:1587c

### 3rd century AH / 9th century CE compilation — Sahih Muslim 1597 — six commodities
- **Source ID:** `hadith-muslim-1597`
- **Passage:** Sahih Muslim 1597; Abd al-Baqi numbering; archive baseline vol. 3, p. 1218
- **Status:** Passage verified — stable hadith locator
- **Evidence:** Report identifies six commodities and requires equal and hand-to-hand exchange in the relevant transactions.
- **Significance:** Major hadith basis for later classification of ribā al-fadl and ribā al-nasi’a.
- **Web source:** https://sunnah.com/muslim:1597

### 11th century CE — Hanafi fiqh — al-Sarakhsi on ribā
- **Source ID:** `hanafi-riba-sarakhsi`
- **Passage:** al-Mabsut, Kitab al-Buyuʿ, Anwaʿ al-Riba, vol. 12, pp. 110–111
- **Status:** Page verified in locked edition
- **Evidence:** Opening passage defines riba as an excess without counter-value stipulated in a sale and grounds the prohibition in Qur’an and Sunnah.
- **Significance:** Direct Hanafi doctrinal formulation tied to the archive’s locked 2001 printing.

### 8th–9th century CE compilation/redaction — Maliki fiqh — al-Mudawwana on ribā
- **Source ID:** `maliki-riba-mudawwana`
- **Passage:** al-Mudawwana al-Kubra, Kitab al-Buyuʿ / Kitab al-Sarf
- **Status:** Structural locator only — page pending
- **Evidence:** Archive retains the book/chapter locator but does not yet claim a page-specific passage from the locked 1994 printing.
- **Significance:** Prevents cross-edition page contamination while preserving the research target.

### 9th century CE — Shafi‘i fiqh — al-Umm on ribā
- **Source ID:** `shafii-riba-umm`
- **Passage:** al-Umm, Kitab al-Buyuʿ / Kitab al-Sarf
- **Status:** Structural locator only — page pending
- **Evidence:** Archive retains the book/chapter locator but does not yet claim a page-specific passage from the locked 2001 printing.
- **Significance:** Same edition-control rule applied to Shafi‘i material.

### 12th century CE — Hanbali fiqh — Ibn Qudama on ribā
- **Source ID:** `hanbali-riba-mughni`
- **Passage:** al-Mughni, Kitab al-Buyuʿ / Kitab al-Sarf
- **Status:** Structural locator only — page pending
- **Evidence:** Archive retains the book/chapter locator but does not yet claim a page-specific passage from the locked 1997 printing.
- **Significance:** Same edition-control rule applied to Hanbali material.

### c. 1265–1274 CE — Thomas Aquinas — usury as unjust sale
- **Source ID:** `aquinas-q78-a1`
- **Passage:** Summa theologiae II–II, q.78, a.1
- **Status:** Passage locator verified — stable article locator
- **Evidence:** Aquinas argues that charging for the use of money lent is unjust when the price is taken for the loan itself, because the use of consumable money is not separable from ownership in the relevant way.
- **Significance:** Canonical scholastic formulation of the injustice of usury.
- **Web source:** https://www.newadvent.org/summa/3078.htm

### c. 1265–1274 CE — Thomas Aquinas — other compensation for a loan
- **Source ID:** `aquinas-q78-a2`
- **Passage:** Summa theologiae II–II, q.78, a.2
- **Status:** Passage locator verified — stable article locator
- **Evidence:** Aquinas examines whether something beyond repayment of the principal may lawfully be received in connection with a loan.
- **Significance:** Important qualification: the treatment distinguishes the price of the loan from other causes of compensation.
- **Web source:** https://www.newadvent.org/summa/3078.htm

### 1694 CE — Bank of England — foundation and emergence of modern central banking
- **Source ID:** `boe-1694`
- **Passage:** Bank of England foundation charter / official history, 1694
- **Status:** Institutional primary-source locator
- **Evidence:** The Bank of England was established in 1694 in connection with government finance and public credit.
- **Significance:** Institutional transition toward modern banking and sovereign credit.
- **Web source:** https://www.bankofengland.co.uk/about/history

### 1913 CE — Federal Reserve Act — institutional transformation of U.S. banking
- **Source ID:** `fed-act-1913`
- **Passage:** Federal Reserve Act, ch. 6, 38 Stat. 251 (1913); cite relevant section
- **Status:** Statutory primary-source locator
- **Evidence:** The Act created the Federal Reserve System and established its statutory framework for reserve and discounting functions.
- **Significance:** Major institutional change in U.S. monetary and banking governance.
- **Web source:** https://www.federalreservehistory.org/essays/federal-reserve-act

### 1944 CE — Bretton Woods — international monetary institutions
- **Source ID:** `bretton-woods-1944`
- **Passage:** IMF and IBRD Articles of Agreement, Bretton Woods, 1944
- **Status:** Treaty/institutional primary-source locator
- **Evidence:** The agreements established the institutional framework for the IMF and IBRD.
- **Significance:** Foundation of the postwar international monetary order.
- **Web source:** https://www.imf.org/external/about/histend.htm

### 1971 CE — 1971 — suspension of dollar convertibility into gold
- **Source ID:** `nixon-1971`
- **Passage:** Richard Nixon, Address to the Nation Outlining a New Economic Policy, 15 Aug. 1971
- **Status:** Official speech primary-source locator
- **Evidence:** Nixon announced suspension of dollar convertibility into gold for official foreign holders as part of the new economic policy.
- **Significance:** Key primary document for the 1971 break with a central Bretton Woods mechanism.
- **Web source:** https://www.federalreservehistory.org/essays/bretton-woods-created

## Version 5.3 — Islamic Fiqh & Medieval Christianity verification pass

### 3rd century AH / 9th century CE compilation — Sahih Muslim 1584e
- **Source ID:** `hadith-muslim-1584e`
- **Passage:** Sahih Muslim 1584e
- **Status:** Passage verified — stable hadith locator
- **Evidence:** Equal-for-equal and hand-to-hand exchange is specified for six named commodities; an addition is identified as ribā.
- **Significance:** Concrete textual basis for later juristic treatment of ribā in exchange.
- **Web source:** https://sunnah.com/muslim/22/103

### 3rd century AH / 9th century CE compilation — Sahih Muslim 1587c
- **Source ID:** `hadith-muslim-1587c`
- **Passage:** Sahih Muslim 1587c
- **Status:** Passage verified — stable hadith locator
- **Evidence:** The report sets equal and hand-to-hand conditions for the named commodities and distinguishes the case where classes differ.
- **Significance:** Primary hadith evidence underlying later classifications of ribā al-fadl and ribā al-nasi’a.
- **Web source:** https://sunnah.com/muslim:1587c

### 8th–9th century CE compilation/redaction — Maliki fiqh — al-Mudawwana
- **Source ID:** `maliki-riba-mudawwana`
- **Passage:** al-Mudawwana al-Kubra, Kitab al-Buyuʿ / Kitab al-Sarf
- **Status:** Passage verified online — print page pending
- **Evidence:** Relevant sales/exchange material is confirmed in the textual tradition; the locked 1994 printing remains the pagination authority.
- **Significance:** Direct Maliki legal material without importing pagination from another edition.

### 9th century CE — Shafi‘i fiqh — al-Umm
- **Source ID:** `shafii-riba-umm`
- **Passage:** al-Umm, Kitab al-Buyuʿ / Kitab al-Sarf
- **Status:** Passage verified online — print page pending
- **Evidence:** The text discusses the Qur’anic prohibition of ribā and the role of Prophetic reports in defining prohibited sales.
- **Significance:** Direct Shafi‘i legal formulation, kept separate from later summaries.

### 12th century CE — Hanbali fiqh — Ibn Qudama, al-Mughni
- **Source ID:** `hanbali-riba-mughni`
- **Passage:** al-Mughni, Kitab al-Buyuʿ / Kitab al-Sarf
- **Status:** Passage verified online — print page pending
- **Evidence:** Ibn Qudama defines ribā in the discussion of ribawi exchanges and treats the legally relevant increase in same-kind exchanges. A reference points to the 1997 Beirut edition, vol. 4, p. 35; direct inspection remains pending.
- **Significance:** Direct Hanbali doctrinal evidence with edition control preserved.

### 12th century CE — Ibn Rushd — Bidāyat al-Mujtahid
- **Source ID:** `ibn-rushd-bidayat-riba`
- **Passage:** chapter on sales involving ribā; online locator 3/148
- **Status:** Passage verified online — print edition pending
- **Evidence:** Ibn Rushd distinguishes ribā in established liabilities from ribā in sales and summarizes disagreement over excess and deferment.
- **Significance:** Comparative juristic synthesis rather than evidence for earlier textual wording.
- **Web source:** https://kutub.io/en/book/21739/605

### c. 1265–1274 CE — Thomas Aquinas — Summa theologiae II–II, q.78, a.1
- **Source ID:** `aquinas-q78-a1`
- **Status:** Passage verified — stable article locator
- **Evidence:** Aquinas argues that taking payment for the use of money lent is unjust when the charge is made for the loan itself.
- **Significance:** Direct scholastic treatment of usury and the distinction between the loan itself and other possible causes of compensation.

## Version 5.5 bridge — Greek → Byzantine → early medieval Europe

### 4th century BCE — Aristotle, *Politics* 1.10, 1258b
- **Source ID:** `aristotle-politics-1258b`
- **Status:** **Passage verified — philosophical primary text**
- **Evidence:** Aristotle says usury's gain comes from money itself and treats it as the most unnatural form of wealth-getting. citeturn2search0
- **Significance:** Greek intellectual evidence concerning the nature of interest; not evidence of a statutory ban.

### 6th century BCE reforms, preserved in later witness — Plutarch, *Life of Solon* 15
- **Source ID:** `plutarch-solon-15`
- **Status:** **Secondary/witness evidence**
- **Evidence:** Plutarch reports debt remission and the prohibition on lending against the borrower's person, while preserving disagreement about the exact reform. citeturn1search0
- **Significance:** Important for the remembered history of Solon's debt reforms, but not a surviving Solonian law text.

### 528 CE — Justinian, *Codex* 4.32.26.1–5
- **Source ID:** `justinian-codex-4-32-26`
- **Status:** **Passage verified — primary civil law**
- **Evidence:** Justinian establishes differentiated interest ceilings and rules against circumvention. citeturn0search1turn0search4
- **Significance:** Byzantine civil-law regulation of interest.

### 529 CE — Justinian, *Codex* 4.32.27–28
- **Source ID:** `justinian-codex-4-32-27-28`
- **Status:** **Passage verified — primary civil law**
- **Evidence:** Justinian limits accumulation and prohibits interest-on-interest. citeturn0search1turn0search6
- **Significance:** Shows detailed regulation of interest accumulation rather than a simple prohibition/permission binary.

### 692 CE — Quinisext Council in Trullo, Canon 10
- **Source ID:** `trullo-canon-10`
- **Status:** **Passage verified — primary ecclesiastical law**
- **Evidence:** Canon 10 requires a bishop, presbyter, or deacon who receives usury to desist or be deposed. citeturn3search3
- **Significance:** Byzantine clerical discipline, distinct from Justinian's civil interest law.

### 789–806 CE — Carolingian anti-usury legislation
- **Source ID:** `carolingian-usury-aachen-nijmegen`
- **Status:** **Research target — critical edition pending**
- **Evidence:** Modern scholarship identifies Aachen 789 and Nijmegen 806 as important Carolingian anti-usury legislation, but the archive will not promote the familiar summaries to verified quotations until the critical capitulary text is inspected. citeturn4search36
- **Significance:** Chronological bridge into early medieval western European regulation.


## Version 5.7 — Early-Modern Commercial Practice & Public Credit

### 1545 CE — John Calvin, *De Usuris Responsum*
- **Source ID:** `calvin-de-usuris-1545`
- **Passage:** *De Usuris Responsum*, letter to Claude de Sachin
- **Status:** **Passage verified online; critical-edition page pending**
- **Evidence:** Calvin states that Scripture does not wholly condemn every form of usury and frames the question through equity and charity. citeturn3search5turn2search1
- **Significance:** Reformation-era movement from inherited categorical language toward circumstance-based ethical analysis.
- **Qualification:** The online English text is a later translation; the locked Latin edition remains a future verification target.

### 1545 CE — English Usury Act, 37 Hen. VIII c. 9
- **Source ID:** `henry-viii-usury-act-1545`
- **Passage:** *An Act against Usury*, 37 Hen. VIII c. 9
- **Status:** **Passage verified online; statute-book edition pending**
- **Evidence:** The statute reorganized the statutory treatment of usury and repealed earlier usury enactments. citeturn1search10
- **Significance:** Early Tudor statutory transition in the legal treatment of interest.

### 1571 CE — English Usury Act, 13 Eliz. I c. 8
- **Source ID:** `elizabeth-usury-act-1571`
- **Passage:** 13 Eliz. I c. 8
- **Status:** **Primary statute identified; exact edition/page pending**
- **Evidence:** Later legal sources identify the act as restoring a 10% statutory ceiling and regulating brokers; the act itself must be quoted from a locked statute edition before publication. citeturn2search43turn2search42
- **Significance:** Numerical rate regulation coexists with explicit moral/religious condemnation language.

### 1624 CE — English Usury Act, 21 Jac. I c. 17
- **Source ID:** `james-usury-act-1624`
- **Passage:** 21 Jac. I c. 17
- **Status:** **Primary statute identified; exact edition/page pending**
- **Evidence:** Later legal sources identify an eight-percent statutory ceiling and an express qualification that the act did not authorize usury in religion or conscience. citeturn2search42turn2search45
- **Significance:** Shows continued statutory regulation while the legal category becomes increasingly rate-based.

### 1694 CE — Bank of England Act and Charter
- **Source IDs:** `bank-act-1694`, `boe-charter-1694`
- **Passage:** 1694 parliamentary financing act and Royal Charter dated 27 July 1694
- **Status:** **Primary institutional evidence; official charter transcript verified**
- **Evidence:** The parliamentary scheme invited voluntary advances for war finance; the Royal Charter incorporated the Bank of England and records the subscribers' capital and annual fund. citeturn1search44turn1search3turn1search5
- **Significance:** Establishes a major institutional bridge from regulated lending to organized banking and sovereign credit.
- **Qualification:** The Act and Charter should be treated as separate primary documents.

### 1787 CE — Jeremy Bentham, *Defence of Usury*
- **Source ID:** `bentham-defence-usury-1787`
- **Passage:** Letter I, §§I.1–I.5
- **Status:** **Passage verified online; first-edition page lock pending**
- **Evidence:** Bentham argues that freely contracting adults should not generally be prevented from agreeing on the terms of money bargains. citeturn3search0turn3search5
- **Significance:** Explicit Enlightenment-era economic argument against inherited statutory restraints on interest.
- **Qualification:** This is an argument about policy and contract, not a description of the law then in force.


## Version 5.8 additions — 1776–1848

- **1776 — Adam Smith, *Wealth of Nations* I.IX:** interest, profits, and legal restrictions. **GREEN.**
- **1787 — Jeremy Bentham, *Defence of Usury*, Letter I:** freedom of money bargains. **GREEN.**
- **1817 — David Ricardo, *Principles of Political Economy and Taxation*, ch. V:** interest and profits. **GREEN.**
- **1844 — Bank Charter Act:** banking and note-issue framework. **GREEN statute identified; section-level quotation lock pending.**
- **1848 — J. S. Mill, *Principles of Political Economy* III.XXIII:** demand/supply of loans and natural rate. **GREEN.**
- **1854 — Usury Laws Repeal Act:** repeal of existing English usury laws. **GREEN.**


## Version 5.9 — Late-Nineteenth-Century Banking & Monetary Architecture

### 1802 CE — Henry Thornton, *Paper Credit*
- **Source ID:** `thornton-paper-credit-1802`
- **Status:** **Primary text online verified; edition-page lock pending**
- **Significance:** Early nineteenth-century analysis of paper credit, banking reserves, and crisis management; important predecessor to later lender-of-last-resort doctrine.

### 1866 CE — Bank Charter crisis
- **Source ID:** `bank-charter-amendment-1866`
- **Status:** **Primary institutional record identified; exact statutory passage pending**
- **Evidence:** The Panic of 1866 exposed the tension between statutory note-issue limits and emergency liquidity provision. The government authorized suspension of the statutory limit during the crisis. citeturn0search6turn0search12

### 1873 CE — Walter Bagehot, *Lombard Street*
- **Source ID:** `bagehot-lombard-street-1873`
- **Status:** **Primary text online verified; edition-page lock pending**
- **Evidence:** Bagehot's 1873 work analyzes the Bank of England's reserve function and the principles governing crisis lending. citeturn0search3turn0search7
- **Qualification:** Later Bank of England archival research shows that emergency lending practices predated Bagehot's formulation, including during the crises of 1847, 1857 and 1866. citeturn0search0turn0search24

### 1878 CE — Banking legislation
- **Source ID:** `bank-act-1878`
- **Status:** **Primary statute identified; section-level passage pending**
- **Significance:** Institutional checkpoint in the consolidation of nineteenth-century banking regulation.

### c. 1870–1914 CE — Classical gold-standard architecture
- **Source ID:** `gold-standard-late19`
- **Status:** **Regime-level synthesis; national primary passages pending**
- **Qualification:** This entry is deliberately not treated as a single universal law. Country-specific statutes, central-bank records, and convertibility rules must be added individually.
