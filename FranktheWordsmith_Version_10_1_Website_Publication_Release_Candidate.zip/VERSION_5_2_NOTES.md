# Version 5.2 — Mesopotamia Passage Verification

Date: 2026-09-22

## Completed

### 1. Laws of Ur-Nammu
Verified the loan provisions against the CDLI RIME 3/2.01.01.20 composite and its line-level transcription/translation. The relevant passage is d036–d041 (Q000947): one gur barley carries one barig four ban2 annual interest; ten shekels silver carries two shekels annual interest.

### 2. Laws of Eshnunna
Upgraded Law 18a from “citation locked” to passage verified. CDLI lines 62–63 explicitly give the silver and grain calculations and identify them as 20% and 33%. The record is a composite with multiple witnesses, so “composite text” remains part of the evidentiary description.

### 3. Code of Hammurabi
Separated secure surviving debt provisions (§§48–52) from the traditional §88 interest-rate passage. The Yale/Avalon presentation explicitly has a missing sequence after §65 and resumes at §100. Accordingly, §88 is retained as reconstructed/damaged evidence rather than being presented as an intact quotation.

## Editorial rule added

For ancient legal collections, “passage verified” means the wording is actually represented in an accessible primary-text edition or critical digital text. A familiar quotation that falls inside a damaged or missing sequence remains “reconstructed” unless the specific witness/edition supporting it is identified.

## Sources checked
- CDLI, RIME 3/2.01.01.20, Laws of Ur-Nammu composite: https://cdli.earth/inscriptions/2234943
- CDLI, RIME 4.05.19.add03, Laws of Eshnunna composite: https://cdli.earth/inscriptions/2269340
- Yale Avalon Project, Code of Hammurabi: https://avalon.law.yale.edu/ancient/hamcode.asp
