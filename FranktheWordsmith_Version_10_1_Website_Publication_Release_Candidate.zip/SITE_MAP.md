# FranktheWordsmith — Version 3.1 Site Map

## Author platform
- Home
- About
- Contact

## Books
- Books catalogue
- Book One: Why Only Usury Invokes Allah's War?
- Future Book Two
- Future Book Three

## Research
- Research Library
- 4,000-Year Timeline
- References / Bibliography
- Central Question (Book One)

## Publishing
- Articles / Essays

## Next development
1. Dedicated source pages
2. Verified bibliography and footnotes
3. Interactive timeline connections
4. Search/filter by civilization, period, language, topic and book
5. Book cover and author photo
6. Newsletter / mailing list only if desired

## Version 4.2
Research archive populated using Hammurabi as canonical source-record template.
