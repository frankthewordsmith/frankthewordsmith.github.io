# Version 9.0 — 4,000-Year Narrative Evidence Integration

## Editorial frame

This narrative is passage-driven but deliberately conservative. Each major proposition below is bound to canonical source records in `research-data.json`. The archive's current evidence inventory remains **A=8, B=46, C=4, D=1**. A-grade means an exact primary text and edition/locator lock; B-grade means a stable primary passage whose print/critical-edition lock remains open; C-grade covers reconstruction, composite text, or later witness; D-grade is unresolved.

The distinction matters because a primary source is the historical object created in the period under study, while a modern transcription, translation, composite reconstruction, or later witness is evidence about that object rather than necessarily the object itself. The Library of Congress likewise emphasizes identifying the creator, title, version/edition, publisher/date, and location when citing primary sources. citeturn0search0turn0search1

## I. Mesopotamia: lending becomes a rule-governed institution

The earliest layer in this archive does not begin with a modern concept of “banking.” It begins with loans embedded in agricultural and commodity economies. The Laws of Ur-Nammu preserve interest provisions for barley and silver, but the surviving legal collection is fragmentary and the relevant wording is reconstructed in the composite tradition. The archive therefore treats the interest rates as **C-grade composite/reconstructed evidence**, not as an intact tablet quotation. [`ur-nammu`]

The Laws of Eshnunna provide another early legal formulation in which silver and grain loans receive differentiated interest provisions. Again, the archive treats the passage as a composite text rather than assuming that the modern composite represents one intact surviving manuscript. [`eshnunna`]

The Code of Hammurabi adds a different dimension: its surviving debt provisions regulate what happens when agricultural failure affects repayment and how debt obligations are handled. The famous numerical interest passage is not treated here as an intact surviving section because the relevant sequence is damaged; the secure claim concerns debt regulation, while the rate wording remains reconstructed. [`hammurabi`]

**Narrative implication:** the early Mesopotamian evidence supports a history of regulated credit, but it does not justify the stronger claim that one fixed interest system operated universally across all loans or communities. The sources are normative legal collections, and documentary loan practice must be distinguished from legal prescription.

## II. Biblical law: interest is differentiated by social relationship

The Hebrew Bible changes the frame by connecting lending rules to social membership and vulnerability. Exodus prohibits interest on a loan to a poor community member. [`exodus-22-24`] Leviticus prohibits taking *neshekh* and *tarbit* from an impoverished member of the community while framing the obligation around sustaining life. [`leviticus-25-35-37`]

Deuteronomy introduces an important qualification by distinguishing lending to a “brother” from lending to a foreigner. [`deuteronomy-23-20-21`] The archive therefore does not reduce biblical law to the proposition “all interest is prohibited.” Its more precise historical claim is that different categories of borrower and lender matter within the legal text.

## III. Classical Greece and Rome: from moral argument to technical legal categories

Aristotle's *Politics* contains the canonical philosophical critique of money-making through money itself, in the passage at 1258b. [`aristotle-politics-1258b`] That is an intellectual argument about the nature and use of money, not a banking statute and not evidence that Greek markets lacked credit.

Roman evidence then moves toward technical legal categorization. The Twelve Tables are not directly extant; their interest-related tradition reaches the archive through later testimony, so the material is explicitly treated as **later-witness evidence** rather than a surviving tablet. [`roman-twelve-tables`]

The Justinianic *Digest* and *Codex* show a mature Roman legal vocabulary in which *usurae* and related additions receive dedicated treatment. The archive uses individual constitutional or fragment locators for exact propositions rather than treating the existence of a title such as *De usuris* as proof of every substantive rule later associated with Roman interest law. [`roman-digest-22-1`, `roman-codex-interest`, `justinian-codex-4-32-26`, `justinian-codex-4-32-27-28`]

**Narrative implication:** the Roman contribution is not simply a continuation of an ancient moral prohibition. It is also a development of a technical legal system capable of classifying interest, delay, fruits, and related contractual consequences.

## IV. Christianity: institutional discipline and moral critique

The Christian evidence develops on several levels. Nicaea's Canon 17 addresses clerical usury and therefore belongs specifically to institutional discipline rather than a complete economic code for every Christian transaction. [`nicaea-canon-17`]

Ambrose's *De Tobia* provides a directly verified patristic critique of usury, while Augustine's selected passage discusses the usurer in terms of lending with an expectation of receiving more than was given. [`ambrose-de-tobia`, `augustine-usury`]

The archive therefore separates **clerical rule**, **moral-theological argument**, and **general economic practice**. A condemnation in a sermon or theological treatise is not by itself evidence that a society eliminated interest-bearing credit.

## V. Islam: ribā becomes a scriptural and juristic field

The Qur'anic evidence distinguishes trade from ribā and calls for abandonment of outstanding ribā claims in Qur'an 2:275–279; Qur'an 3:130 gives an additional formulation involving multiplied ribā. [`quran-2-275-279`, `quran-3-130`]

Hadith then supplies more specific rules for exchange. Sahih Muslim 1587c and 1597 are used here as stable hadith locators for rules concerning specified commodities, equality, and immediate exchange. [`hadith-muslim-1587c`, `hadith-muslim-1597`] The archive also preserves Muslim 1584e as an additional exchange-related passage. [`hadith-muslim-1584e`]

Medieval fiqh transforms these scriptural and hadith materials into differentiated legal doctrines. Al-Sarakhsi gives a directly page-locked Hanafi formulation of ribā. [`hanafi-riba-sarakhsi`] The Maliki, Shafi‘i, Hanbali, and Ibn Rushd records are retained as passage-level evidence while their print-edition pagination remains open where noted. [`maliki-riba-mudawwana`, `shafii-riba-umm`, `hanbali-riba-mughni`, `ibn-rushd-bidayat-riba`]

**Narrative implication:** “Islam prohibits interest” is too coarse for a passage-driven archive. The stronger historical statement is that Qur'anic and hadith texts became the basis for an expanding jurisprudence of ribā, including rules governing loans and exchanges and distinctions that later jurists debated and systematized.

## VI. Medieval Christian and Jewish jurisprudence: classification becomes systematic

Thomas Aquinas treats usury within a scholastic analysis of justice and the nature of the loan contract. The archive uses *Summa Theologiae* II-II q.78 as the canonical passage-level record, while preserving the distinction between a verified online text and a not-yet-locked print/critical-edition page. [`aquinas-q78-a1`, `aquinas-q78-a2`]

Maimonides' *Sefer ha-Mitzvot* and *Mishneh Torah* provide a parallel Jewish legal system in which the biblical prohibition is developed into detailed rules governing creditor and debtor relationships. [`maimonides-sefer-mitzvot-235-237`, `maimonides-mishneh-torah-ml-4`, `maimonides-mishneh-torah-ml-5`]

The *Shulchan Arukh*, Yoreh De'ah 160, continues this codification into the early-modern period. [`shulchan-arukh-yoreh-deah-160`]

**Narrative implication:** medieval legal traditions did not merely repeat ancient prohibitions. They classified transactions, exceptions, reciprocal benefits, and contractual forms. The archive therefore treats medieval usury law as a history of legal taxonomy as much as a history of prohibition.

## VII. Reformation and early-modern states: moral law meets statutory administration

Calvin's *De Usuris Responsum* represents a Reformation-era attempt to reason about usury within Christian ethics and law. The archive retains the text as primary-source evidence but notes that its present witness is a stable reproduction rather than a fully locked early edition. [`calvin-de-usuris-1545`]

English legislation makes the institutional shift visible. The 1545 Usury Act, the 1571 statute, and the 1624 statute form a sequence in which the state regulates interest through statutory rules. [`henry-viii-usury-act-1545`, `elizabeth-usury-act-1571`, `james-usury-act-1624`]

The key historical change is therefore not simply “religion became secular.” It is that a subject formerly handled through religious, moral, and customary law increasingly became a matter of statute, enforcement, ceilings, exceptions, and administrative design.

## VIII. Public credit and the Bank of England

The 1694 Bank of England records mark a major institutional transition. The archive distinguishes the Bank's original charter from the statute establishing its legal framework: the Charter is preserved through an official Bank of England archival witness, while the Bank Act remains separately identified as a statutory source whose exact print-page lock is still open. [`boe-charter-1694`, `bank-act-1694`]

This distinction prevents a common narrative compression: the foundation of the Bank, the statutory creation of its privileges, and the later emergence of central-bank functions were not a single event. They developed through legal and institutional changes over time.

## IX. Eighteenth- and nineteenth-century political economy: interest becomes an object of explicit economic theory

Jeremy Bentham's *Defence of Usury* argues directly against statutory restrictions on voluntary lending and is one of the archive's page-locked first-edition A-grade texts. [`bentham-defence-usury-1787`] Adam Smith's *Wealth of Nations*, Book I, chapter IX, supplies a page-locked discussion of interest in the context of profit and the rate of interest. [`adam-smith-wealth-nations-i9`]

Ricardo's *Principles of Political Economy and Taxation*, chapter V, continues the classical analysis of distribution and interest. [`ricardo-principles-ch-v`] John Stuart Mill's *Principles of Political Economy*, Book III, chapter XXIII, extends the analysis of the rate of interest and capital. [`js-mill-principles-interest`]

The archive's point is not that classical economists unanimously endorsed one policy. It is that the discourse had shifted: interest was increasingly analyzed as a price, return, or distributional variable within a theory of capital, rather than only as a moral defect in a loan.

## X. Statutory liberalization and the architecture of banking

The Bank Charter Act 1844, the Usury Laws Repeal Act 1854, and later banking legislation show two parallel processes: interest restrictions were being dismantled in some jurisdictions while the monetary and banking system was becoming more formally regulated. [`bank-charter-act-1844`, `usury-laws-repeal-1854`, `bank-charter-amendment-1866`, `bank-act-1878`]

Henry Thornton's *Paper Credit* and Walter Bagehot's *Lombard Street* then move the archive beyond the narrow question of loan interest. Thornton analyzes paper credit and the Bank of England's role during monetary disturbances; Bagehot develops a systematic account of reserve management and crisis lending. [`thornton-paper-credit-1802`, `bagehot-lombard-street-1873`]

The distinction is central: **interest on a loan** and **the institutional management of liquidity and reserves** are related but not identical historical phenomena.

## XI. Twentieth-century monetary architecture: from banking regulation to international monetary order

The Federal Reserve Act of 1913 establishes the U.S. central-bank framework in statute. [`fed-act-1913`] The Banking Acts of 1933 and 1935 then restructure banking and monetary governance, including the institutional development of the Federal Reserve System. [`banking-act-1933`, `banking-act-1935`]

The 1944 Bretton Woods Final Act is an A-grade primary-source anchor for the creation of the IMF and IBRD institutional framework. [`bretton-woods-1944`] The 1945 U.S. implementing statute and 1945 U.K. implementing legislation must remain distinct from the 1944 international agreement: one is domestic implementation, the other an international negotiating instrument. [`bretton-woods-act-1945`, `uk-bretton-woods-act-1945`]

The archive therefore describes Bretton Woods as a layered legal event: international agreement in 1944, domestic implementation in 1945, and later institutional amendments.

## XII. 1971–1978: the transition away from the Bretton Woods convertibility framework

The 15 August 1971 Nixon address is preserved as a primary speech source for the suspension of dollar convertibility into gold. [`nixon-1971`] The Jamaica reform must not be collapsed into that speech: the archive separately records the 1976 IMF agreement and the legal entry into force of the Second Amendment in 1978. [`jamaica-1976-imf`]

The historical sequence is therefore institutional and legal rather than a single “end of Bretton Woods” date: 1971 marks a major policy announcement, while subsequent agreements and amendments changed the formal international monetary framework.

## XIII. Contemporary regulation

Dodd-Frank in 2010 represents a later phase in which financial regulation addresses systemic risk, market structure, consumer protection, and institutional failure rather than simply setting a permissible rate of interest. [`dodd-frank-2010`]

This final period reinforces the archive's central distinction. The history of interest is not identical to the history of banking, and the history of banking is not identical to the history of monetary regimes. They intersect, but the relevant primary sources belong to different legal and institutional categories.

## XIV. What the 4,000-year evidence can support

Taken together, the archive supports a bounded historical narrative:

1. **Early Mesopotamian law** records recognizable interest-bearing loans and attempts to regulate debt, but some of the oldest interest-rate passages survive only through composite/reconstructed texts. [`ur-nammu`, `eshnunna`, `hammurabi`]
2. **Biblical law** differentiates lending rules according to social relationship and borrower vulnerability rather than presenting one undifferentiated rule about all interest. [`exodus-22-24`, `leviticus-25-35-37`, `deuteronomy-23-20-21`]
3. **Greek and Roman sources** add philosophical and technical legal categories, with Roman law eventually giving interest a developed juristic treatment. [`aristotle-politics-1258b`, `roman-twelve-tables`, `roman-digest-22-1`, `roman-codex-interest`]
4. **Christian, Islamic, and Jewish traditions** transform inherited rules into institutional, scriptural, and juristic systems. [`nicaea-canon-17`, `ambrose-de-tobia`, `quran-2-275-279`, `hadith-muslim-1597`, `hanafi-riba-sarakhsi`, `maimonides-mishneh-torah-ml-4`, `shulchan-arukh-yoreh-deah-160`]
5. **Early-modern states** increasingly administer interest through statute and public institutions. [`henry-viii-usury-act-1545`, `elizabeth-usury-act-1571`, `james-usury-act-1624`, `boe-charter-1694`]
6. **Classical political economy** increasingly theorizes interest as a return associated with capital and lending, while statutory restrictions are challenged or repealed in some settings. [`bentham-defence-usury-1787`, `adam-smith-wealth-nations-i9`, `ricardo-principles-ch-v`, `js-mill-principles-interest`, `usury-laws-repeal-1854`]
7. **Modern banking and monetary institutions** broaden the field from bilateral lending to reserves, central banking, banking regulation, and international monetary governance. [`thornton-paper-credit-1802`, `bagehot-lombard-street-1873`, `fed-act-1913`, `bretton-woods-1944`, `nixon-1971`, `jamaica-1976-imf`, `dodd-frank-2010`]

## XV. What the archive still does not prove

The source record does **not** establish a single uninterrupted doctrine of “usury” spanning four millennia. The vocabulary, legal categories, institutional structures, and economic mechanisms change substantially across periods. Nor does the existence of a legal prohibition prove that interest disappeared from practice, just as a statute permitting or regulating interest does not prove uniform compliance.

The archive also does not treat reconstructed ancient wording, later testimony, modern transcription, or online passage verification as interchangeable with a locked historical edition. That restraint is deliberate: citation is part of the historical argument because it identifies where the evidence comes from and lets later researchers retrieve and test it. citeturn0search1

## XVI. Publication-use rule

For publication, each paragraph should be traceable back to its source IDs in the registry. Exact quotations should be reserved for records with an adequate passage and edition/locator lock. B-grade material may support carefully bounded paraphrase; C-grade material must retain its reconstruction/later-witness label; D-grade material should not carry an affirmative historical proposition beyond the fact that it remains an unresolved research target.
