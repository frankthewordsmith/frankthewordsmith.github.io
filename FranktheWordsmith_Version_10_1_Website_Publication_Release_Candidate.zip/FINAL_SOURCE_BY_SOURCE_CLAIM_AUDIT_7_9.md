# VERSION 7.9 — FINAL SOURCE-BY-SOURCE CLAIM AUDIT

Date: 2026-09-23

## Purpose
This audit is the final control layer before the definitive publication edition. It tests whether the narrative claims can be traced to the actual source records without silently upgrading weak evidence.

## Evidence inventory

- **A-grade:** 8
- **B-grade:** 46
- **C-grade:** 4
- **D-grade:** 1
- **Total records:** 59

## Publication rules
1. A claim is not considered locked merely because a text is available online.
2. An A-grade record must have a named edition or authoritative primary publication, an exact stable passage locator, and no unresolved “pending” verification language.
3. Composite, reconstructed, lacunose, fragmentary, or later-witness material remains explicitly qualified.
4. Chronological confidence and textual confidence are separate dimensions.
5. Legal statutes, religious norms, contracts, administrative records, and later scholarly interpretations are not interchangeable evidence types.

## A-grade records

- `ambrose-de-tobia` — A-grade designation retained; inspect: date_start, verification_note.
- `hanafi-riba-sarakhsi` — A-grade designation retained; inspect: date_start, source_url, source_url, verification_note.
- `bentham-defence-usury-1787` — A-grade designation retained; inspect: footnote_policy, bibliography_entry, passage_record, status, locator, evidence, significance, source_url, checked, verification_note.
- `adam-smith-wealth-nations-i9` — A-grade designation retained; inspect: footnote_policy, bibliography_entry, passage_record, status, locator, evidence, significance, source_url, checked, verification_note.
- `bentham-defence-usury-i` — A-grade designation retained; inspect: footnote_policy, bibliography_entry, passage_record, status, locator, evidence, significance, source_url, checked, verification_note.
- `ricardo-principles-ch-v` — A-grade designation retained; inspect: footnote_policy, bibliography_entry, passage_record, status, locator, evidence, significance, source_url, checked, verification_note.
- `bretton-woods-1944` — A-grade designation retained; inspect: footnote_policy, bibliography_entry.
- `uk-bretton-woods-act-1945` — A-grade designation retained; inspect: edition, verification_note.

## Records requiring caution

- `ur-nammu` — grade C.
- `eshnunna` — grade C.
- `hammurabi` — grade C.
- `exodus-22-24` — missing core fields: date_start; missing passage fields: verification_note.
- `leviticus-25-35-37` — missing core fields: date_start; missing passage fields: verification_note.
- `deuteronomy-23-20-21` — missing core fields: date_start; missing passage fields: verification_note.
- `mishnah-bm-5` — missing core fields: date_start; missing passage fields: verification_note.
- `talmud-bm` — missing core fields: date_start; missing passage fields: verification_note.
- `roman-twelve-tables` — missing core fields: date_start; missing passage fields: verification_note.
- `roman-digest-22-1` — missing core fields: date_start; missing passage fields: verification_note.
- `roman-codex-interest` — missing core fields: date_start; missing passage fields: verification_note.
- `nicaea-canon-17` — missing core fields: date_start; missing passage fields: verification_note.
- `ambrose-de-tobia` — missing core fields: date_start; missing passage fields: verification_note.
- `augustine-usury` — missing core fields: date_start, source_url; missing passage fields: source_url, verification_note.
- `quran-2-275-279` — missing core fields: date_start; missing passage fields: verification_note.
- `quran-3-130` — missing core fields: date_start; missing passage fields: verification_note.
- `hadith-muslim-1587c` — missing core fields: date_start; missing passage fields: verification_note.
- `hadith-muslim-1597` — missing core fields: date_start; missing passage fields: verification_note.
- `hanafi-riba-sarakhsi` — missing core fields: date_start, source_url; missing passage fields: source_url, verification_note.
- `maliki-riba-mudawwana` — missing core fields: date_start; missing passage fields: verification_note; verification still says pending.
- `shafii-riba-umm` — missing core fields: date_start; missing passage fields: verification_note; verification still says pending.
- `hanbali-riba-mughni` — missing core fields: date_start; missing passage fields: verification_note; verification still says pending.
- `aquinas-q78-a1` — missing core fields: date_start; missing passage fields: verification_note.
- `aquinas-q78-a2` — missing core fields: date_start; missing passage fields: verification_note.
- `boe-1694` — missing core fields: date_start; missing passage fields: verification_note.
- `hadith-muslim-1584e` — missing passage fields: verification_note.
- `ibn-rushd-bidayat-riba` — missing passage fields: verification_note; verification still says pending.
- `aristotle-politics-1258b` — missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note.
- `plutarch-solon-15` — grade C; missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note.
- `justinian-codex-4-32-26` — missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note.
- `justinian-codex-4-32-27-28` — missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note.
- `trullo-canon-10` — missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note.
- `carolingian-usury-aachen-nijmegen` — grade D; missing core fields: source_url, footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note; verification still says pending.
- `maimonides-sefer-mitzvot-235-237` — missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note; verification still says pending.
- `maimonides-mishneh-torah-ml-4` — missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note; verification still says pending.
- `maimonides-mishneh-torah-ml-5` — missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note; verification still says pending.
- `shulchan-arukh-yoreh-deah-160` — missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note; verification still says pending.
- `calvin-de-usuris-1545` — missing core fields: edition, footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note; verification still says pending.
- `henry-viii-usury-act-1545` — missing core fields: edition, footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note; verification still says pending.
- `elizabeth-usury-act-1571` — missing core fields: edition, footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note; verification still says pending.
- `james-usury-act-1624` — missing core fields: edition, footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note; verification still says pending.
- `boe-charter-1694` — missing core fields: edition, footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note.
- `bank-act-1694` — missing core fields: edition, footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note; verification still says pending.
- `bentham-defence-usury-1787` — missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note.
- `adam-smith-wealth-nations-i9` — missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note.
- `bentham-defence-usury-i` — missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note.
- `ricardo-principles-ch-v` — missing core fields: footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note.
- `bank-charter-act-1844` — missing core fields: edition, footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note.
- `usury-laws-repeal-1854` — missing core fields: edition, footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note.
- `js-mill-principles-interest` — missing core fields: edition, footnote_policy, bibliography_entry, passage_record; missing passage fields: status, locator, evidence, significance, source_url, checked, verification_note; verification still says pending.
- `fed-act-1913` — missing core fields: edition, footnote_policy, bibliography_entry; missing passage fields: verification_note.
- `banking-act-1933` — missing core fields: edition, footnote_policy, bibliography_entry; missing passage fields: verification_note; verification still says pending.
- `banking-act-1935` — missing core fields: edition, footnote_policy, bibliography_entry; missing passage fields: verification_note; verification still says pending.
- `bretton-woods-1944` — missing core fields: footnote_policy, bibliography_entry.
- `bretton-woods-act-1945` — missing core fields: edition, footnote_policy, bibliography_entry; missing passage fields: verification_note; verification still says pending.
- `nixon-1971` — missing core fields: edition, footnote_policy, bibliography_entry; missing passage fields: verification_note.
- `jamaica-1976-imf` — missing core fields: edition, footnote_policy, bibliography_entry; missing passage fields: verification_note.
- `dodd-frank-2010` — missing core fields: edition, footnote_policy, bibliography_entry; missing passage fields: verification_note.
- `uk-bretton-woods-act-1945` — missing core fields: edition; missing passage fields: verification_note.

## Claim-level conclusion
The archive can now distinguish three different statements that must not be collapsed: (1) a proposition is historically plausible; (2) a proposition is supported by a primary passage; and (3) that passage has been locked to a particular edition/page or equivalent authoritative locator. Only the third qualifies for the strongest publication treatment.

The final publication should therefore foreground the A-grade backbone, use B-grade sources as qualified primary-text anchors where their stable section/article/verse locators are sufficient, and visibly label C/D evidence as reconstructed, fragmentary, derivative, or otherwise limited.

## Methodological reference
The Library of Congress primary-source citation guidance emphasizes identifying the version/edition, publisher/date, and location, including page numbers where relevant. This archive applies that principle together with stricter source-criticism rules for reconstructed ancient and medieval texts.
