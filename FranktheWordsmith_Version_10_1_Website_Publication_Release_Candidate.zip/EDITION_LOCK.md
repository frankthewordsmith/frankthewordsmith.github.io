# Edition Lock — Version 4.5

## Locked bibliographic baselines

- **Al-Sarakhsi, al-Mabsut:** ed. Abu Abd Allah Muhammad Hasan Ismaʿil al-Shafiʿi, Beirut: Dar al-Kutub al-ʿIlmiyyah, 2001, **31 vols.** The supplied 30-volume figure is corrected here because the named edited printing is documented as 31 volumes.
- **Al-Mudawwana al-Kubra:** Sahnun, ed. Ahmad ʿAbd al-Salam, Beirut: Dar al-Kutub al-ʿIlmiyyah, 1st ed., 1415/1994, **5 vols.**
- **Al-Umm:** al-Shafiʿi, ed. Rifat Fawzi ʿAbd al-Muttalib, al-Mansurah: Dar al-Wafaʾ, 1st ed., 1422/2001, **11 vols.**
- **Al-Mughni:** Ibn Qudama, ed. ʿAbd Allah ibn ʿAbd al-Muhsin al-Turki and ʿAbd al-Fattah Muhammad al-Hulu, Riyadh: Dar ʿAlam al-Kutub, 3rd ed., 1417/1997, **15 vols.**
- **Sahih Muslim:** ed. Muhammad Fuʾad ʿAbd al-Baqi, Cairo: Dar Ihya al-Kutub al-ʿArabiyyah, 1374/1954–55, **5 vols.** Later reprints may reproduce this baseline; page citations must identify the copy consulted.
- **Qurʾan English translation:** M. A. S. Abdel Haleem, *The Qur’an*, Oxford World’s Classics (Oxford: Oxford University Press, 2004). *The Study Quran*, 1st ed. (HarperOne, 2015), is a comparative translation/commentary.
- **Ambrose, De Tobia:** ed. Karl Schenkl, **CSEL 32.2**, 1897, pp. 519–573.
- **Augustine:** Latin critical-text baseline **CSEL/CCSL**; English baseline **The Works of Saint Augustine: A Translation for the 21st Century**, New City Press, 1990–2019. A precise Augustine work must be selected before a quotation is publication-locked.

## Citation rule

Every quotation must identify the work, stable internal locator, edition, and page where that edition provides stable pagination. Never transfer a page number from one edition to another.


## Version 5.2 additions — Mesopotamia
- Ur-Nammu: CDLI RIME 3/2.01.01.20 composite, lines d036–d041.
- Eshnunna: CDLI RIME 4.05.19.add03 composite, Law 18a lines 62–63.
- Hammurabi: Yale/Avalon §§48–52 verified; §88 remains reconstructed because the sequence containing it is missing in that presentation.
