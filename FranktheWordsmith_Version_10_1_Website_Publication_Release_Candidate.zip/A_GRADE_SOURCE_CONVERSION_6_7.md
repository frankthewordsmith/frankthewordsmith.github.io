# VERSION 6.7 — A-GRADE SOURCE CONVERSION DOSSIER

## Purpose
Version 6.7 begins the conversion of publication-ready B-grade records into fully locked A-grade evidence. The standard is deliberately conservative: a stable online locator alone does not create an A-grade source.

## A-grade definition
An A-grade record must have: (1) a primary passage selected; (2) a named authoritative/critical edition; (3) an edition-specific page, section, canon, fragment, or equivalent fixed locator; and (4) enough provenance information that another researcher can reproduce the citation.

## A-grade conversions completed

### Ambrose, De Tobia — Christian condemnation of usury
- **Source ID:** `ambrose-de-tobia`
- **Grade:** A
- **Edition:** Ambrosius Mediolanensis, De Tobia, ed. Karl Schenkl, Corpus Scriptorum Ecclesiasticorum Latinorum 32.2 (Prague/Vienna/Leipzig: Hoelder-Pichler-Tempsky, 1897), pp. 519–573.
- **Exact locator:** De Tobia 9.33; CSEL 32.2, p. 536
- **Verification:** Page verified in locked critical edition
- **Why locked:** Exact passage selected: De Tobia 9.33; CSEL 32.2, p. 536; critical-edition page and section locked.

### Hanafi fiqh — al-Sarakhsi on ribā
- **Source ID:** `hanafi-riba-sarakhsi`
- **Grade:** A
- **Edition:** al-Sarakhsi, al-Mabsut, ed. Abu Abd Allah Muhammad Hasan Ismaʿil al-Shafiʿi, Beirut: Dar al-Kutub al-ʿIlmiyyah, 2001, 31 vols.
- **Exact locator:** al-Mabsut, Kitab al-Buyuʿ, Anwaʿ al-Riba, vol. 12, pp. 110–111
- **Verification:** Page verified in locked edition
- **Why locked:** Exact passage selected: al-Mabsut, Kitab al-Buyuʿ, Anwaʿ al-Riba, vol. 12, pp. 110–111, in the named 2001 Dar al-Kutub al-ʿIlmiyyah edition; edition volume count corrected to 31.

## High-priority B-grade conversion queue

- **exodus-22-24 — Exodus 22:25 — lending to the poor**: The Hebrew Bible: New JPS Translation according to the Traditional Hebrew Text; current locator: Exodus 22:25 in most modern verse numbering (archive title uses 22:24); next action: verify the exact edition/page before any A-grade promotion.
- **leviticus-25-35-37 — Leviticus 25:35–37 — neshekh and tarbit**: The Hebrew Bible: New JPS Translation according to the Traditional Hebrew Text; current locator: Leviticus 25:35–37; next action: verify the exact edition/page before any A-grade promotion.
- **deuteronomy-23-20-21 — Deuteronomy 23:20–21 — brother and foreigner**: The Hebrew Bible: New JPS Translation according to the Traditional Hebrew Text; current locator: Deuteronomy 23:20–21; next action: verify the exact edition/page before any A-grade promotion.
- **mishnah-bm-5 — Mishnah Bava Metzia 5 — definitions and mechanisms of ribbit**: Mishnah, Seder Nezikin, Bava Metzia 5; Koren-Steinsaltz digital edition; current locator: Mishnah Bava Metzia 5:1–2; next action: verify the exact edition/page before any A-grade promotion.
- **talmud-bm — Babylonian Talmud, Bava Metzia — ribbit sugyot**: Vilna Shas / standard Bavli pagination; use a named critical/digital edition for quotations; current locator: Babylonian Talmud, Bava Metzia 75a–75b; individual amud required for print citation; next action: verify the exact edition/page before any A-grade promotion.
- **roman-twelve-tables — Roman Twelve Tables — early interest regulation tradition**: Fontes Iuris Romani Antejustiniani; modern translations should identify the edition; current locator: Twelve Tables, Table VIII; later testimony including Tacitus, Annals 6.16; next action: verify the exact edition/page before any A-grade promotion.
- **roman-digest-22-1 — Digest 22.1 — interest as a Roman legal category**: Corpus Iuris Civilis, Digesta; Mommsen/Krueger editions or a named modern translation; current locator: Digesta 22.1, De usuris et fructibus et causis et omnibus accessionibus; next action: verify the exact edition/page before any A-grade promotion.
- **roman-codex-interest — Codex 4.32 — Justinian on interest**: Corpus Iuris Civilis, Codex 4.32; current locator: Codex 4.32, De usuris; next action: verify the exact edition/page before any A-grade promotion.
- **nicaea-canon-17 — First Council of Nicaea — Canon 17**: Decrees of the Ecumenical Councils; NPNF translation for public-domain English; current locator: First Council of Nicaea, Canon 17; next action: verify the exact edition/page before any A-grade promotion.
- **augustine-usury — Augustine — lending, charity and the poor**: Latin critical-text baseline locked to CSEL/CCSL for the individual Augustinian work selected; English baseline locked to The Works of Saint Augustine: A Translation for the 21st Century (New City Press, 1990–2019), edited by John E. Rotelle et al. Individual work/volume must be selected before quotation.; current locator: Enarratio in Psalmum XXXVI 3.6; CCSL 38, p. 372; next action: verify the exact edition/page before any A-grade promotion.
- **quran-2-275-279 — Qur’an 2:275–279 — ribā and trade**: Primary English translation locked to M. A. S. Abdel Haleem, The Qur’an, Oxford World’s Classics (Oxford: Oxford University Press, 2004). Comparative: Nasr et al., The Study Quran, 1st ed. (New York: HarperOne, 2015).; current locator: Qur’an 2:275–279; next action: verify the exact edition/page before any A-grade promotion.
- **quran-3-130 — Qur’an 3:130 — multiplied ribā**: Primary English translation locked to M. A. S. Abdel Haleem, The Qur’an, Oxford World’s Classics (Oxford: Oxford University Press, 2004). Comparative: Nasr et al., The Study Quran, 1st ed. (New York: HarperOne, 2015).; current locator: Qur’an 3:130; next action: verify the exact edition/page before any A-grade promotion.
- **hadith-muslim-1587c — Sahih Muslim 1587c — ribā in exchange**: Muslim ibn al-Hajjaj, Sahih Muslim, ed. Muhammad Fuʾad ʿAbd al-Baqi, Cairo: Dar Ihya al-Kutub al-ʿArabiyyah, 1374 AH/1954–1955 CE, 5 vols.; later Beirut reprints reproduce this baseline.; current locator: Sahih Muslim 1587c; next action: verify the exact edition/page before any A-grade promotion.
- **hadith-muslim-1597 — Sahih Muslim 1597 — six commodities**: Muslim ibn al-Hajjaj, Sahih Muslim, ed. Muhammad Fuʾad ʿAbd al-Baqi, Cairo: Dar Ihya al-Kutub al-ʿArabiyyah, 1374 AH/1954–1955 CE, 5 vols.; later Beirut reprints reproduce this baseline.; current locator: Sahih Muslim 1597; Abd al-Baqi numbering; archive baseline vol. 3, p. 1218; next action: verify the exact edition/page before any A-grade promotion.
- **maliki-riba-mudawwana — Maliki fiqh — al-Mudawwana on ribā**: Sahnun, al-Mudawwana al-Kubra, ed. Ahmad ʿAbd al-Salam, Beirut: Dar al-Kutub al-ʿIlmiyyah, 1st ed., 1415 AH/1994 CE, 5 vols.; current locator: al-Mudawwana al-Kubra, Kitab al-Buyuʿ / Kitab al-Sarf; next action: verify the exact edition/page before any A-grade promotion.
- **shafii-riba-umm — Shafi‘i fiqh — al-Umm on ribā**: al-Shafiʿi, al-Umm, ed. Rifat Fawzi ʿAbd al-Muttalib, al-Mansurah: Dar al-Wafaʾ, 1st ed., 1422 AH/2001 CE, 11 vols.; current locator: al-Umm, Kitab al-Buyuʿ / Kitab al-Sarf; next action: verify the exact edition/page before any A-grade promotion.
- **hanbali-riba-mughni — Hanbali fiqh — Ibn Qudama on ribā**: Ibn Qudama, al-Mughni, ed. ʿAbd Allah ibn ʿAbd al-Muhsin al-Turki and ʿAbd al-Fattah Muhammad al-Hulu, Riyadh: Dar ʿAlam al-Kutub, 3rd ed., 1417 AH/1997 CE, 15 vols.; current locator: al-Mughni, Kitab al-Buyuʿ / Kitab al-Sarf; next action: verify the exact edition/page before any A-grade promotion.
- **aquinas-q78-a1 — Thomas Aquinas — usury as unjust sale**: Summa Theologiae, Latin critical edition (Leonine); use Dominican English translation for web quotation; current locator: Summa theologiae II–II, q.78, a.1; next action: verify the exact edition/page before any A-grade promotion.
- **aquinas-q78-a2 — Thomas Aquinas — other compensation for a loan**: Summa Theologiae, Leonine critical edition; English Dominican translation; current locator: Summa theologiae II–II, q.78, a.2; next action: verify the exact edition/page before any A-grade promotion.
- **boe-1694 — Bank of England — foundation and emergence of modern central banking**: Bank of England historical archive; current locator: Bank of England foundation charter / official history, 1694; next action: verify the exact edition/page before any A-grade promotion.
- **hadith-muslim-1584e — Sahih Muslim 1584e — equal exchange and ribā**: Sahih Muslim, stable hadith numbering; current locator: Sahih Muslim 1584e; next action: verify the exact edition/page before any A-grade promotion.
- **ibn-rushd-bidayat-riba — Ibn Rushd — Bidāyat al-Mujtahid on ribā**: Online text locator; current locator: Bidāyat al-Mujtahid, chapter on sales involving ribā; online locator 3/148; next action: verify the exact edition/page before any A-grade promotion.
- **aristotle-politics-1258b — Aristotle, Politics 1.10, 1258b**: Perseus / Loeb-derived text; current locator: Politics 1.10, 1258b; next action: verify the exact edition/page before any A-grade promotion.
- **justinian-codex-4-32-26 — Justinian, Codex 4.32.26**: Codex Iustinianus, Book 4, Title 32; current locator: C. 4.32.26.1–5; next action: verify the exact edition/page before any A-grade promotion.
- **justinian-codex-4-32-27-28 — Justinian, Codex 4.32.27–28**: Codex Iustinianus, Book 4, Title 32; current locator: C. 4.32.27.1–2; C. 4.32.28pr.; next action: verify the exact edition/page before any A-grade promotion.
- **trullo-canon-10 — Quinisext Council in Trullo, Canon 10**: Canons of the Quinisext Council; current locator: Canon 10; next action: verify the exact edition/page before any A-grade promotion.
- **maimonides-sefer-mitzvot-235-237 — Maimonides, Sefer ha-Mitzvot — Negative Commandments 235–237**: Sefer ha-Mitzvot, Negative Commandments 235–237; online text; current locator: Negative Commandments 235–237; next action: verify the exact edition/page before any A-grade promotion.
- **maimonides-mishneh-torah-ml-4 — Maimonides, Mishneh Torah — Malveh ve-Loveh, Chapter 4**: Mishneh Torah, Hilchot Malveh ve-Loveh, chapter 4; online text; current locator: Malveh ve-Loveh 4:1–10; next action: verify the exact edition/page before any A-grade promotion.
- **maimonides-mishneh-torah-ml-5 — Maimonides, Mishneh Torah — Malveh ve-Loveh, Chapter 5**: Mishneh Torah, Creditor and Debtor 5; online text; current locator: Malveh ve-Loveh 5:1–8; next action: verify the exact edition/page before any A-grade promotion.
- **shulchan-arukh-yoreh-deah-160 — Shulchan Arukh, Yoreh De'ah 160 — Laws of Interest**: Shulchan Arukh, Yoreh De'ah 160; online text; current locator: Yoreh De'ah 160:1–23; next action: verify the exact edition/page before any A-grade promotion.
- **calvin-de-usuris-1545 — John Calvin, De Usuris Responsum**: None; current locator: Letter to Claude de Sachin; next action: verify the exact edition/page before any A-grade promotion.
- **henry-viii-usury-act-1545 — Usury Act 1545 (37 Hen. VIII c. 9)**: None; current locator: 37 Hen. VIII c. 9; next action: verify the exact edition/page before any A-grade promotion.
- **elizabeth-usury-act-1571 — Usury Act 1571 (13 Eliz. I c. 8)**: None; current locator: 13 Eliz. I c. 8; next action: verify the exact edition/page before any A-grade promotion.
- **james-usury-act-1624 — Usury Act 1624 (21 Jac. I c. 17)**: None; current locator: 21 Jac. I c. 17; next action: verify the exact edition/page before any A-grade promotion.
- **boe-charter-1694 — Bank of England Charter 1694**: None; current locator: Bank of England Charter, 27 July 1694; next action: verify the exact edition/page before any A-grade promotion.
- **bank-act-1694 — Bank of England Act 1694**: None; current locator: 5 & 6 Will. & Mar. c. 20; next action: verify the exact edition/page before any A-grade promotion.
- **bentham-defence-usury-1787 — Jeremy Bentham, Defence of Usury**: None; current locator: Letter I, §§I.1–I.5; next action: verify the exact edition/page before any A-grade promotion.
- **adam-smith-wealth-nations-i9 — Adam Smith, The Wealth of Nations, Book I, Chapter IX**: None; current locator: Book I, Chapter IX; next action: verify the exact edition/page before any A-grade promotion.
- **bentham-defence-usury-i — Jeremy Bentham, Defence of Usury, Letter I**: None; current locator: Letter I; next action: verify the exact edition/page before any A-grade promotion.
- **ricardo-principles-ch-v — David Ricardo, On the Principles of Political Economy and Taxation, Chapter V**: None; current locator: Chapter V, On Profits; next action: verify the exact edition/page before any A-grade promotion.
- **bank-charter-act-1844 — Bank Charter Act 1844**: None; current locator: 7 & 8 Vict. c. 32; next action: verify the exact edition/page before any A-grade promotion.
- **usury-laws-repeal-1854 — Usury Laws Repeal Act 1854**: None; current locator: 17 & 18 Vict. c. 90; next action: verify the exact edition/page before any A-grade promotion.
- **js-mill-principles-interest — John Stuart Mill, Principles of Political Economy, Book III, Chapter XXIII**: None; current locator: Book III, Chapter XXIII, Of the Rate of Interest; next action: verify the exact edition/page before any A-grade promotion.
- **fed-act-1913 — Federal Reserve Act — 1913**: None; current locator: Federal Reserve Act, ch. 6, 38 Stat. 251 (1913), especially §§2, 13, 14; next action: verify the exact edition/page before any A-grade promotion.
- **banking-act-1933 — Banking Act of 1933 / Glass-Steagall**: None; current locator: Banking Act of 1933; FOMC provisions and banking-separation provisions; next action: verify the exact edition/page before any A-grade promotion.
- **banking-act-1935 — Banking Act of 1935 — modern FOMC structure**: None; current locator: Banking Act of 1935, Title II; Federal Reserve Act §12A as amended; next action: verify the exact edition/page before any A-grade promotion.
- **bretton-woods-1944 — Bretton Woods — IMF and IBRD Articles of Agreement**: None; current locator: IMF Articles of Agreement, Articles I–IV; IBRD Articles of Agreement, relevant institutional provisions; next action: verify the exact edition/page before any A-grade promotion.
- **bretton-woods-act-1945 — Bretton Woods Agreements Act — U.S. implementation**: None; current locator: Bretton Woods Agreements Act, 59 Stat. 512 (1945); next action: verify the exact edition/page before any A-grade promotion.
- **nixon-1971 — Nixon — 15 August 1971 suspension of dollar convertibility**: None; current locator: Richard Nixon, Address to the Nation Outlining a New Economic Policy, 15 Aug. 1971; next action: verify the exact edition/page before any A-grade promotion.
- **jamaica-1976-imf — Jamaica monetary reform / IMF Second Amendment**: None; current locator: IMF Second Amendment, Article IV; Jamaica agreement, January 1976; next action: verify the exact edition/page before any A-grade promotion.
- **dodd-frank-2010 — Dodd-Frank Wall Street Reform and Consumer Protection Act**: None; current locator: Pub. L. 111-203 (2010), selected Titles I, II, VII, X; next action: verify the exact edition/page before any A-grade promotion.

## C/D safeguards

- **ur-nammu — C**: C-grade — retain explicit reconstruction/later-witness qualification
- **eshnunna — C**: C-grade — retain explicit reconstruction/later-witness qualification
- **hammurabi — C**: C-grade — retain explicit reconstruction/later-witness qualification
- **plutarch-solon-15 — C**: C-grade — retain explicit reconstruction/later-witness qualification
- **carolingian-usury-aachen-nijmegen — D**: D-grade — unresolved publication target

## Research rule
Never transfer page numbers between editions. Where a text is reconstructed, composite, fragmentary, or preserved only by later witnesses, the archive must retain that limitation even if a modern edition provides convenient pagination.
