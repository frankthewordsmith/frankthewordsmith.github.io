# Version 7.6 Notes — Islamic Fiqh Primary-Edition Lockdown

This release performs the targeted Islamic fiqh source audit. The aim is not to inflate the A-grade count but to make the provenance chain defensible.

### A-grade retained
1. al-Sarakhsi, *al-Mabsut*, Kitab al-Buyuʿ, Anwaʿ al-Riba, vol. 12, pp. 110–111, Dar al-Kutub al-ʿIlmiyyah 2001, 31 vols.

### B-grade retained pending direct page lock
2. Sahnun, *al-Mudawwana al-Kubra*, Dar al-Kutub al-ʿIlmiyyah 1415/1994, 5 vols.
3. al-Shafiʿi, *al-Umm*, ed. Rifat Fawzi ʿAbd al-Muttalib, Dar al-Wafaʾ 1422/2001, 11 vols.
4. Ibn Qudama, *al-Mughni*, ed. al-Turki/al-Hulu, Dar ʿAlam al-Kutub 1417/1997, 15 vols.

No source was promoted merely because an online page or secondary citation supplied a plausible pagination. This is intentional.
