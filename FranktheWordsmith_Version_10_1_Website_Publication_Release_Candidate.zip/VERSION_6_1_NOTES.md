# VERSION 6.1 NOTES

Version 6.1 is a publication-control release. It does not add a new historical period. It consolidates the passage-verification standard across the full 4,000-year timeline and identifies every remaining publication blocker.

## Completed
- Master audit table created for all source and record entries.
- Evidence classes normalized for audit purposes.
- Publication blockers isolated rather than silently upgraded.
- Citation manifest generated.
- research-data.json updated to version 6.1.

## Key rule
A familiar source title is not enough. A published quotation requires an exact locator, and an edition/page claim requires inspection of the exact locked edition. Composite and reconstructed ancient texts must remain labeled as such.
