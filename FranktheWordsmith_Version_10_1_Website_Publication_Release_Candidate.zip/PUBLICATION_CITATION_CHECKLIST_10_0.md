# Publication Citation Checklist — Version 10.0

Before quoting any passage in a derivative publication, verify:

- [ ] Author/creator identified where known.
- [ ] Work title identified.
- [ ] Edition/version identified.
- [ ] Publisher and publication date identified where applicable.
- [ ] Stable internal locator supplied (book/chapter/section/canon/verse/table/statute/etc.).
- [ ] Page supplied only when verified against that named edition.
- [ ] Translation and translator identified when a translation is quoted.
- [ ] Reconstruction, lacuna, composite text, or later witness explicitly labeled.
- [ ] Online passage verification not described as print-page verification.
- [ ] Claim's evidence grade does not exceed the cited source record's grade.

The Library of Congress recommends giving enough bibliographic information to allow future researchers to locate the primary source, including version/edition, publisher/date, location, and access information for online resources. citeturn0search1turn0search3
