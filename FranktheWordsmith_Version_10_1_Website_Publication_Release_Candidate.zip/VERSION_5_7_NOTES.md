# Version 5.7 — Early-Modern Commercial Practice & Public Credit

## Scope
This pass bridges the medieval/early-modern legal traditions into modern commercial practice. It focuses on Reformation-era arguments, English statutory rate regulation, public credit, institutional banking, and the late-18th-century economic critique of usury restrictions.

## Added records
1. John Calvin, *De Usuris Responsum* (1545).
2. 37 Hen. VIII c. 9, Usury Act (1545).
3. 13 Eliz. I c. 8, Usury Act (1571).
4. 21 Jac. I c. 17, Usury Act (1624).
5. Bank of England Act (1694).
6. Bank of England Royal Charter (27 July 1694).
7. Jeremy Bentham, *Defence of Usury* (1787), Letter I.

## Methodological decisions
- Statutes are treated as primary legal evidence, but later summaries are not substituted for the statutory text when a publication-grade quotation is required.
- The Bank of England Act and Royal Charter are separate primary records: one establishes the financing/subscription framework; the other incorporates the corporation.
- Calvin is treated as a theological argument, not as a legal rule.
- Bentham is treated as a normative economic argument, not evidence that statutory usury restrictions had already disappeared.
- The 16th-century Jewish *Shulchan Arukh* / *iska* material from Version 5.6 remains part of this transition and is not duplicated merely to fill the chronology.

## High-priority next verification
1. Lock the exact statute-book edition and pages for 37 Hen. VIII c. 9, 13 Eliz. I c. 8, and 21 Jac. I c. 17.
2. Lock a critical Latin edition/page for Calvin's *De Usuris Responsum*.
3. Lock the first-edition pagination for Bentham (1787).
4. Add 18th–19th century British rate changes and the 1854 repeal only after the relevant Acts are independently verified.
5. Then proceed to the 19th-century banking/interest transition and U.S./continental European legal developments.
