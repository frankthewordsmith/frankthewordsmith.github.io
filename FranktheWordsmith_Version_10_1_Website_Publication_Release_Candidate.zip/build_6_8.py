import json, os, re, zipfile, datetime
root='/mnt/data/v68work'; p=os.path.join(root,'research-data.json')
D=json.load(open(p)); recs=D['sources']
D['version']=6.8
matrix=[]; flags=[]
for r in recs:
    fields={k:bool(r.get(k)) for k in ['date_start','date_end','title','source_type','reference_number','language','primary_or_secondary','historical_claim','context','verification_status','source_url','edition','page']}
    status=r.get('verification_status','') + ' ' + str(r.get('evidence_grade_6_7',''))
    gaps=[]
    if not r.get('reference_number'): gaps.append('locator')
    if 'page' not in status.lower() and 'section' not in status.lower() and '§' not in str(r.get('reference_number','')): gaps.append('edition/page-or-section-lock')
    if 'pending' in status.lower(): gaps.append('pending-verification')
    if 'reconstruct' in status.lower() or 'fragment' in status.lower() or 'Primary' not in str(r.get('primary_or_secondary','')): gaps.append('provenance-caution')
    matrix.append({'id':r['source_id'],'grade':re.search(r'\b([ABCD])\b',status).group(1) if re.search(r'\b([ABCD])\b',status) else 'UNSET','fields_complete':all(fields.values()),'gaps':gaps,'source_url':r.get('source_url',''),'reference_number':r.get('reference_number','')})
# Known chronology integrity checks based on project rules and audited records.
flags += [
 {'id':'boe-charter-1694','issue':'Separate the 27 July 1694 Royal Charter from the 5 & 6 Will. & Mar. c.20 Act; do not treat them as the same instrument.','resolution':'Retain as distinct records/citations.'},
 {'id':'jamaica-1976-imf','issue':'Distinguish the January 1976 Jamaica Agreement / Proposed Second Amendment from the legal entry into force on 1 April 1978.','resolution':'Keep 1976 as agreement/reform stage; 1978 as legal-effective date.'},
 {'id':'ancient-composites','issue':'Composition dates and surviving manuscript/witness dates are not interchangeable for reconstructed ancient law collections.','resolution':'Use explicit composition/reconstruction and witness language.'},
 {'id':'statute-lifecycle','issue':'Enactment, later consolidation, amendment, repeal, and surviving-text dates must not be collapsed.','resolution':'Preserve original enactment citation and separately note later status.'},
]
D['audit_6_8']={'title':'Independent Citation & Chronology Audit','date':'2026-09-23','record_count':len(recs),'matrix_summary':{'complete_field_rows':sum(x['fields_complete'] for x in matrix),'rows_with_gaps':sum((not x['fields_complete']) or bool(x['gaps']) for x in matrix),'grade_counts':{g:sum(x['grade']==g for x in matrix) for g in 'ABCD'}},'chronology_flags':flags,'citation_matrix':matrix}
with open(p,'w') as f: json.dump(D,f,ensure_ascii=False,indent=2)
# reports
from collections import Counter
c=Counter(x['grade'] for x in matrix)
missing=Counter(g for x in matrix for g in x['gaps'])
open(os.path.join(root,'INDEPENDENT_CITATION_CHRONOLOGY_AUDIT_6_8.md'),'w').write(f'''# Version 6.8 — Independent Citation & Chronology Audit\n\nDate: 2026-09-23\n\n## Scope\nEvery record in the 6.7 source inventory was checked for chronology fields, primary/secondary provenance, locator presence, source URL, and whether the current verification language claims an edition/page/section lock. This is an integrity audit, not a mass promotion of grades.\n\n## Inventory\n- Records audited: {len(recs)}\n- Grade counts: A={c["A"]}, B={c["B"]}, C={c["C"]}, D={c["D"]}\n- Rows with explicit gaps or caution flags: {sum(bool(x["gaps"]) for x in matrix)}\n\n## High-priority chronology controls\n1. **Bank of England, 1694:** the Royal Charter dated 27 July 1694 and the Bank of England Act 1694 (5 & 6 Will. & Mar. c.20) are separate instruments.\n2. **IMF/Jamaica:** the 1976 Jamaica reform agreement is distinct from the Second Amendment's legal effectiveness on 1 April 1978.\n3. **Ancient legal corpora:** composition/reconstruction dates must not be presented as identical to manuscript/witness dates.\n4. **Statutes:** enactment must be distinguished from later amendment, consolidation, repeal, or survival.\n\n## Citation integrity rule\nA stable online passage is not automatically a locked-print citation. Records remain B unless the project has independently locked the exact edition plus page/section locator.\n\n## Result\nNo broad historical expansion is authorized by this audit. The next publication step is editorial cleanup plus freezing only those citations that already satisfy the A-grade standard.\n''')
open(os.path.join(root,'WHAT_WE_CANNOT_PROVE_6_8.md'),'w').write('''# What We Cannot Prove — Version 6.8\n\n- A reconstructed or fragmentary ancient law collection cannot be treated as a verbatim, continuously preserved code without qualification.\n- An online transcription does not by itself establish a locked-print edition page.\n- A later witness or secondary report cannot be silently upgraded into a surviving contemporary primary passage.\n- The 1976 Jamaica Agreement should not be dated as though the IMF Second Amendment legally entered into force in 1976; the effective date was 1 April 1978.\n- The 1694 Bank of England Act and the 1694 Royal Charter must not be merged into one citation.\n- Where an exact passage has not been independently locked to an edition/page or precise section, the record remains below A grade even if the historical proposition is well established.\n''')
open(os.path.join(root,'CITATION_INTEGRITY_MATRIX_6_8.md'),'w').write('# Citation Integrity Matrix — Version 6.8\n\n| ID | Grade | Locator | Edition/page/section lock signal | Gaps |\n|---|---|---|---|---|\n'+'\n'.join(f"| {x['id']} | {x['grade']} | {'yes' if x['reference_number'] else 'no'} | {'yes' if 'edition-page-or-section-lock' not in x['gaps'] else 'no'} | {', '.join(x['gaps']) or '—'} |" for x in matrix)+'\n')
open(os.path.join(root,'VERSION_6_8_NOTES.md'),'w').write('''# Version 6.8 Notes\n\nVersion 6.8 performs the independent citation and chronology audit proposed after the 6.7 A-grade conversion. It deliberately does not expand the historical corpus. The purpose is to expose remaining evidence gaps, protect chronology distinctions, and prepare the final research edition.\n''')
for fn in ['index.html','about.html','research.html','references.html','source.html','timeline.html','synthesis.html','publication.html']:
    fp=os.path.join(root,fn)
    if os.path.exists(fp):
        s=open(fp,encoding='utf8').read().replace('Version 6.7','Version 6.8').replace('6.7','6.8')
        open(fp,'w',encoding='utf8').write(s)
zip_path='/mnt/data/FranktheWordsmith_Version_6_8_Independent_Citation_Chronology_Audit.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for base,dirs,files in os.walk(root):
        for fn in files:
            if fn==os.path.basename(zip_path): continue
            fp=os.path.join(base,fn); z.write(fp,os.path.relpath(fp,root))
print(zip_path, os.path.getsize(zip_path), c, 'rows',len(recs))
