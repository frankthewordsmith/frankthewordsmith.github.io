# A-Grade Conversion 7.6 — Evidence Ledger

| Source | Edition lock | Page lock | Result |
|---|---|---:|---|
| Bentham, *Defence of Usury* | London, T. Payne and Son, 1787, first ed. | p. 1 | **A** |
| Adam Smith, *Wealth of Nations* I.IX | Glasgow Edition, vol. 2 | p. 105 | **A** |
| Ricardo, *Principles* V* / On Profits | London, John Murray, 1817, first ed. | p. 116 | **A** |

### Bentham
Google Books catalogs the 1787 T. Payne and Son first-edition object at 206 pages and places the Introduction at p. 1. Princeton catalogs a 1787 T. Payne and Son copy. The online text is used to identify the Letter I passage; the publication locator is the first-edition page. See web sources recorded in `research-data.json`.

### Adam Smith
The Glasgow Edition contents place Book I, Chapter IX, “Of the Profits of Stock,” at p. 105. This gives a named scholarly edition and stable page lock.

### Ricardo
The first-edition contents preserve the duplicated chapter numbering: Chapter V = “On Wages” and Chapter V* = “On Profits,” with V* beginning at p. 116. Later editions renumber the chapter, so the first-edition designation is retained.

No other candidate was promoted merely because a web transcript or modern edition supplied a convenient locator.
