# Version 9.0 — Targeted Passage Extraction

Date: 2026-09-23

## Purpose

This round extracts passage-level evidence from four high-value B-grade records that are already stable at the work/chapter/article/constitution level:

- Thomas Aquinas, *Summa theologiae* II–II, q.78, a.1
- Maimonides, *Mishneh Torah*, *Malveh ve-Loveh* 4:1–10
- *Digest* 22.1, *De usuris et fructibus et causis et omnibus accessionibus*
- Justinian, *Codex* 4.32.26.1–5

## Lock rule

This is an extraction round, not an automatic grade-promotion round. A stable online passage locator is not treated as a substitute for a verified critical/print-edition page. The project therefore promotes **no** B-grade source in this release.

## Output

Each selected record receives a `passage_extraction_8_8` object containing its locator, bounded paraphrase, and verification status. Short online-witness excerpts are included only for orientation and are not treated as the final publication text.

The archive remains at **59 records: A=8, B=46, C=4, D=1**.
