# Master Audit 5.4

| Evidence class | Meaning | Current use |
|---|---|---|
| GREEN | Primary passage directly verified | May support direct quotation with locator |
| YELLOW | Passage identified; locked edition/page pending | Citation can be provisional; no publication-grade page quote yet |
| ORANGE | Fragmentary/reconstructed/composite | Quote only with reconstruction status stated |
| BLUE | Secondary witness or later synthesis | Context only; never presented as intact primary text |

## High-risk entries requiring continued caution
- Roman Twelve Tables: do not state a precise annual maximum as certain without fragmentary-evidence qualification.
- Hammurabi §88: keep separate from the secure debt/crop-failure provisions.
- Solonian law: later literary witnesses are not equivalent to a surviving Solonian statute.
- Augustine/Ambrose: always name the exact work and passage.
- al-Mudawwana, al-Umm, al-Mughni: online passage verification does not replace locked-print pagination.
- Ibn Rushd: comparative synthesis, not an early foundational legal text.

## Medieval canon-law checkpoint
Gratian's *Decretum*, Causa XIV, Quaestio III explicitly presents the rule that demanding more than one gave constitutes usury, while Quaestio IV collects rules concerning clerical lending and usury. The compilation date is c. 1140; later manuscript witnesses and commentaries must not be retrojected into earlier canon law.
