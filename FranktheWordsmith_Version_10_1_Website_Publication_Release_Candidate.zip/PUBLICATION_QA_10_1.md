# Publication QA — Version 10.1

## Functional surface
- Home and primary navigation
- Research library search
- 4,000-year timeline
- References/bibliography
- Synthesis
- Individual source records
- Publication/evidence methodology
- About/contact

## Evidence integrity
The publication interface exposes the frozen A/B/C/D grades rather than flattening them into a single confidence category. The source register remains the authoritative research data file.

## Citation presentation
The site follows a source-first model: author/title/edition/publisher/date/location are retained where available, with structural locators used where page locking is unavailable. This is consistent with the Library of Congress guidance that primary-source citations should contain enough information for readers to identify and locate the source. See the project's citation checklist and bibliography. 

## Known deployment-dependent checks
- Test final production URLs after deployment.
- Test external links from the live domain.
- Add the production-domain canonical URL to HTML once the domain is fixed.
- Validate robots/sitemap against the chosen host.
- Run a browser-based accessibility audit in the final hosting environment.
