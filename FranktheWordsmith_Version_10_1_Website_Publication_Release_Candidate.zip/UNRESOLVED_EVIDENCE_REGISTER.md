# Unresolved Evidence Register — Version 10.0

The following limitations are intentionally preserved.

## B-grade edition/page locks
Many B-grade records have stable internal locators but no verified print/critical-edition page in the current archive. This includes major Roman, Christian, Islamic, Jewish, scholastic, early-modern legal, and modern statutory records.

## C-grade ancient evidence
Ur-Nammu and Eshnunna survive in composite/reconstructed forms; Hammurabi contains lacunae/reconstruction issues in the relevant interest-rate material; Plutarch is a later literary witness rather than a contemporary Solonian document.

## D-grade Carolingian target
The Aachen 789 / Nijmegen 806 anti-usury record remains a research target pending direct critical-edition verification. It must not be represented as a locked passage in the final narrative.

## What would justify a future revision
A later edition may promote a B record only when the exact named edition/scan and stable page or equivalent authoritative location are directly verified. Such a revision should change the individual record and audit trail, not rewrite the historical narrative silently.
