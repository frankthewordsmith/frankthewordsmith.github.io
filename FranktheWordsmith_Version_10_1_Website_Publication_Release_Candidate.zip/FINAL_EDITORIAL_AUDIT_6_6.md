# Version 6.6 — Final Editorial Audit

## Scope
This is the publication-edition audit of the 58-source research archive. It does not promote a source merely because a readable online transcription exists. The project distinguishes exact primary text, stable online verification, reconstructed/composite material, later witnesses, and unresolved edition work.

## Evidence inventory
- Total source records: 58
- Grade A: 0
- Grade B: 53
- Grade C: 4
- Grade D: 1

## Publication rules
1. Use Chicago Notes and Bibliography as the default historical citation system; this is particularly suitable for humanities research and flexible primary-source documentation. citeturn0search2
2. For digitized primary sources, identify the original creator/work and the digital repository or access path; include an exact locator when available. citeturn0search0turn0search5
3. Do not silently convert a secondary quotation into a primary-source quotation. When the original is unavailable, identify the secondary source as the intermediary. citeturn0search10
4. Legal statutes remain cited in their legal form and are not forced into ordinary book-bibliography formatting where that would obscure the legal citation. citeturn0search11
5. Never invent pagination, edition data, original-language wording, or manuscript details.
6. Grade C/D material remains explicitly qualified in the public narrative.

## Remaining limitations
- No required core metadata field or locator was found missing under the project validation rules.

## Publication status
The archive is suitable for a publication-facing edition with visible evidence grades. The remaining scholarly work is refinement of individual Grade B records into edition/page-locked Grade A records, not a reason to conceal their present status.
