# Version 10.1 — Website Publication Release Candidate

This release moves the archive from research construction into website publication QA. The historical evidence inventory is frozen; this release does not promote any source merely for presentation.

## Frozen evidence inventory
- A: 8
- B: 46
- C: 4
- D: 1
- Total: 59

## Publication principles
1. A primary passage is not represented as page-locked unless the edition/page evidence is actually locked.
2. Reconstructed, composite, fragmentary, and later-witness materials remain explicitly marked.
3. Source IDs are stable identifiers used by the research library and source pages.
4. External links are presented as access paths, not as substitutes for bibliographic identity.
5. The downloadable research files remain part of the publication record.

## Release-candidate QA
- Internal HTML navigation checked.
- Script and stylesheet references checked.
- Research JSON parsed successfully.
- Source-record count and evidence-grade counts checked against the frozen inventory.
- Mobile-responsive navigation and layout supplied in the publication assets.
- Searchable research library connected to the source records.
- Individual source pages connected through `source.html?id=...`.

## Remaining deployment actions
These require the eventual hosting environment rather than the archive itself: production-domain canonical URLs, DNS/HTTPS, final external-link monitoring, analytics/privacy configuration if desired, and any server-specific security headers.
