# Final Publication Audit — Version 10.0

Date: 2026-09-23

## Inventory

| Grade | Meaning | Records |
|---|---|---:|
| A | Edition/location locked | 8 |
| B | Primary passage with stable locator; edition/page lock may remain open | 46 |
| C | Reconstructed/composite/fragmentary/later-witness | 4 |
| D | Unresolved research target | 1 |
| **Total** | | **59** |

## Publication decision
The archive is frozen as a **Final Research Publication Edition**. It is suitable for public research use provided that the grade distinctions remain visible. It is not represented as an edition-page-complete corpus.

## Strongest evidence backbone
The A-grade backbone consists of Ambrose, al-Sarakhsi, Bentham, Adam Smith, Ricardo, the 1944 Bretton Woods Final Act, and the United Kingdom's 1945 Bretton Woods implementing statute. These records have the strongest edition/location controls in the present archive.

## Qualified primary-text layer
The B-grade layer contains the majority of the archive. These are usable primary-text anchors where the stable internal locator is sufficient for the claim, while unresolved print/critical-edition pagination remains visible rather than silently filled.

## Limited-evidence layer
C-grade records include Ur-Nammu, Eshnunna, Hammurabi, and Plutarch's Solon passage. Their reconstruction, composite, lacunose, or witness limitations must remain attached to any narrative claim.

The D-grade Carolingian Aachen/Nijmegen record remains an unresolved research target and is not treated as a locked passage.

## Final integrity checks
- 59 source records retained.
- Evidence grade explicitly stored on every record.
- No new A-grade promotion inferred from online availability alone.
- Earlier audit trail preserved.
- Publication page identifies the edition as a transparent research archive rather than a universally page-locked corpus.
- Unresolved evidence is listed rather than hidden.
