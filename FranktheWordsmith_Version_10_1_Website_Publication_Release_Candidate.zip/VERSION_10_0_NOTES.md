# Version 10.0 — Final Research Publication Edition

Date: 2026-09-23

## Purpose
Version 10.0 is the publication freeze of the passage-driven research archive. It stops the open-ended edition-acquisition loop and converts the verified Version 9.0 state into an explicit, auditable publication record.

## What changed
- Added an explicit `evidence_grade` to all 59 source records.
- Added `publication_status` to all source records so that grade meaning is visible at record level.
- Froze the evidence inventory at **A 8 / B 46 / C 4 / D 1**.
- Added a final claim-to-passage control map and unresolved-evidence register.
- Added a publication bibliography/checklist emphasizing edition, publisher, date, and location fields.
- Marked the site as a **Final Research Publication Edition** rather than implying that every passage has a print-page lock.
- Preserved all earlier audits and research notes rather than deleting them.

## Editorial rule
No record was promoted to A merely because its text is available online. A-grade status requires the stronger edition/location standard used throughout the archive. This follows the archive's source-critical rule that passage availability and edition/page verification are distinct states.

## Publication status
**Ready for public research use with transparent evidence grading.**

This edition should not be described as a claim that every ancient, medieval, legal, religious, or modern passage has been verified against a physical or scanned critical-edition page. The B/C/D registers make those remaining limits explicit.
