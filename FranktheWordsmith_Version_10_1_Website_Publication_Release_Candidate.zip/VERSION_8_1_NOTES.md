# Version 8.1 — Remaining B-Grade Primary-Edition Lockdown

Date: 2026-09-23

## Purpose

Version 8.1 is a targeted primary-edition conversion campaign following the 8.0 publication freeze. It focuses on the highest-value remaining B-grade records rather than reopening the entire archive.

## Standard

A record is promoted only when the project can identify:

1. the primary text;
2. the edition/version used;
3. an exact stable passage locator; and
4. a reproducible citation, with print pagination where the edition supplies stable pagination.

An online transcription is treated as a verification witness, not automatically as a substitute for a locked print/critical-edition citation.

## Result

No unjustified grade promotions were made in this round. The targeted records received explicit conversion-review notes and, where useful, independent online primary-text checks. Records that still lack the required edition/page lock remain B.

## High-priority conversion targets

- Roman: Digest 22.1; Codex 4.32; Justinian constitutions; Nicaea Canon 17.
- Medieval Christian: Aquinas, *Summa Theologiae* II-II q.78.
- Medieval Jewish: Maimonides, *Mishneh Torah*, Creditor and Debtor.
- Islamic fiqh: al-Mudawwana, al-Umm, al-Mughni.
- English law: 1545, 1571, 1624 usury statutes.
- Banking: Bank of England Charter/Act 1694; Bank Charter Act 1844; Usury Laws Repeal Act 1854.
- Modern monetary architecture: Federal Reserve Act 1913; Banking Acts 1933/1935; U.S. Bretton Woods implementing Act 1945; Nixon 1971; IMF Second Amendment 1976; Dodd-Frank 2010.

## Evidence inventory

A = 8  
B = 46  
C = 4  
D = 1

The inventory is unchanged from the 8.0 publication freeze because the conversion standard was not met by the newly checked online witnesses alone.
