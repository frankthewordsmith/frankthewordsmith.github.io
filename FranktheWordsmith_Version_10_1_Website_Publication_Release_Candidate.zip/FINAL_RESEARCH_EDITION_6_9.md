# Final Research Edition — 6.9

The archive's 4,000-year synthesis is now frozen as a research edition. Its central method is passage-driven: major historical transitions are tied to identifiable primary texts or explicitly labeled reconstructed, fragmentary, later-witness, or secondary evidence.

## Evidence status
- **A:** 2
- **B:** 51
- **C:** 4
- **D:** 1
- **Total:** 58

The grades are descriptive evidence controls, not judgments about the historical importance of a source.

## What the edition does not claim
The edition does not claim that every cited online passage has a verified locked-print page. It does not treat reconstructed ancient texts as surviving autograph witnesses. It does not collapse a later witness into an original composition date. It does not treat statutory enactment as equivalent to later legal status. It does not treat the 1976 IMF reform agreement/adoption stage as the same date as the Second Amendment's legal effectiveness in 1978.

## Final publication rule
Where evidence remains incomplete, the edition preserves the incompleteness rather than manufacturing precision.
