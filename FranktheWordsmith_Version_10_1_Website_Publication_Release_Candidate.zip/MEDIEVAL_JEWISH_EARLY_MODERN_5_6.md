# Version 5.6 Timeline Insert

| Date | Source | Passage | Evidence status |
|---|---|---|---|
| c. 1160s | Maimonides, *Sefer ha-Mitzvot* | Negative Commandments 235–237 | Primary passage directly verified online |
| 12th c. | Maimonides, *Mishneh Torah* | Malveh ve-Loveh 4:1–10 | Primary passage directly verified online |
| 12th c. | Maimonides, *Mishneh Torah* | Malveh ve-Loveh 5:1–8 | Primary passage directly verified online |
| 1563–1565 | *Shulchan Arukh*, Yoreh De'ah 160 | §§1–23 | Primary passage directly verified online |

These entries document legal codification and should not be read as direct evidence of uniform economic practice.
