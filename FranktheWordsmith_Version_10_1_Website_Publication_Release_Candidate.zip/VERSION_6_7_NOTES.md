# Version 6.7 — A-Grade Source Conversion

Version 6.7 begins the source-by-source conversion of the publication edition into edition-locked evidence. Two records are promoted to A-grade: Ambrose, *De Tobia* 9.33 (CSEL 32.2, p. 536), and al-Sarakhsi, *al-Mabsut*, vol. 12, pp. 110–111 in the named 2001 Dar al-Kutub al-ʿIlmiyyah edition.

The project remains conservative: online passage verification does not automatically equal edition/page lock. The next batches should convert B-grade records only after their exact editions and locators are independently checked.
