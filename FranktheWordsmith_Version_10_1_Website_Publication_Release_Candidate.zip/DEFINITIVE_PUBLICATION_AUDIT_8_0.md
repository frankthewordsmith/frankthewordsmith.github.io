# Definitive Publication Audit — Version 8.1

## 1. Evidence freeze
The archive contains 59 source records. The frozen inventory is A=8, B=46, C=4, D=1.

## 2. Interpretation controls
1. A primary text is not upgraded merely because a modern website reproduces it.
2. A stable passage locator (canon/chapter/section/article/tablet) is not the same thing as a physical-edition page lock.
3. Reconstructed/composite texts are labeled as such.
4. Later witnesses are not represented as surviving originals.
5. A legal/economic concept is not projected backward merely because a later tradition uses similar vocabulary.
6. The chronology records dates separately from evidentiary confidence.
7. The narrative distinguishes loan interest/usury from later banking, public credit, and monetary architecture.

## 3. Claim discipline
Every major narrative transition must be traceable to one or more canonical source records. Where evidence is contested, fragmentary, reconstructed, or dependent on later transmission, the prose must preserve that qualification.

## 4. Publication citation discipline
The final citation should identify the author/creator, title, edition/version, publisher/date where applicable, and a precise location. For digitized sources, the stable online location may be added as a retrieval aid; it does not erase the need to identify the underlying source.

## 5. Final editorial decision
The archive is publication-ready as a **graded evidence edition**. It should not be described as a uniformly A-grade primary-source corpus. The remaining B/C/D records are intentional and transparent limitations.
