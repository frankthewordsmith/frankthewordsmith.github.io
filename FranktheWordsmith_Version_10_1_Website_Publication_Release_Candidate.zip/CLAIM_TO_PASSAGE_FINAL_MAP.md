# Claim-to-Passage Final Map — Version 10.0

This map is the final editorial control layer. Narrative claims should point to a source record and inherit that record's evidence grade.

## Core propositions

### 1. Ancient Near Eastern debt and interest
Use the Ur-Nammu, Eshnunna, and Hammurabi records only with their C-grade reconstruction/composite qualifications. Do not turn reconstructed interest-rate passages into verbatim, edition-locked quotations.

### 2. Biblical/Jewish prohibition and regulation
Exodus 22:25, Leviticus 25:35–37, and Deuteronomy 23:20–21 provide the principal biblical passage anchors. Mishnah Bava Metzia 5 and the Bavli Bava Metzia records provide later rabbinic legal development; their dating and textual transmission should be kept distinct from the biblical passages.

### 3. Roman law
The Twelve Tables, Digest 22.1, and Codex 4.32 records are B-grade anchors. Stable Roman-law locators are preferred; no print-page lock should be implied unless the named edition/page has actually been verified.

### 4. Christian and Byzantine regulation
Nicaea Canon 17, Ambrose, Augustine, and Trullo Canon 10 form the principal Christian/Byzantine evidence layer. Ambrose is A-grade in the current archive; the others retain their qualified status.

### 5. Islamic ribā
Qur'an 2:275–279 and 3:130, Sahih Muslim passages, and the four Sunni fiqh records provide the Islamic evidence sequence. Al-Sarakhsi is A-grade; the other fiqh records remain B unless an edition/page lock is separately established.

### 6. Medieval scholastic and Jewish legal thought
Aquinas, Ibn Rushd, Maimonides, and the Shulchan Arukh are B-grade anchors in the present freeze. Their stable internal locators can support qualified passage-level claims without pretending that a critical-edition page has been checked where it has not.

### 7. Early-modern usury law and commercial credit
Calvin, the English Usury Acts, the Bank of England Charter/Act, and the later repeal legislation form the legal transition layer. Statute/chapter locators are retained; edition/page requirements remain visible where applicable.

### 8. Political economy and banking theory
Bentham, Smith, Ricardo, and Mill are used for the transition from moral/legal usury regulation toward political economy and interest-rate theory. Bentham, Smith, and Ricardo are A-grade; Mill remains B in the present freeze.

### 9. Modern monetary architecture
The Federal Reserve Act, Banking Acts, Bretton Woods, the 1971 Nixon address, Jamaica/IMF reform, and Dodd-Frank form the modern institutional sequence. Bretton Woods 1944 and the UK 1945 implementation act are A-grade; other modern records retain their documented qualified status.

## Rule for the narrative
A claim should never inherit a stronger evidence status than its cited passage. If a narrative sentence combines A and B evidence, the sentence should either separate the propositions or preserve the B qualification.
