# Version 7.0 Notes — Public Research Edition

Date: 2026-09-23

Version 7.0 converts the frozen 6.9 research archive into a publication-oriented research master. It adds the canonical evidence matrix, Passage Book, claim-level synthesis audit, and permanent integrity rules.

No source was promoted merely for completeness or narrative convenience.
