# Version 4.6 — Passage-Verified Research Archive

Version 4.6 extends the Version 4.5 edition-locked baseline into passage-level verification.

Changes:
- Added `PASSAGE_VERIFICATION.md`.
- Added structured `verified_passages` data to the first individually verified passages.
- Added a dedicated Passage Verification field to source pages.
- Added exact critical locators for Qur'an verses, Sahih Muslim 1597, al-Sarakhsi's *al-Mabsut* "Anwa' al-Riba", Ambrose *De Tobia* 9.33, and Augustine *Enarratio in Psalmum XXXVI* 3.6.
- Preserved a strict distinction between edition-locked and page-verified evidence.
- Did not copy page numbers from other editions into the locked al-Mudawwana, al-Umm, or al-Mughni records.

Research rule:
No quotation should receive an edition-specific page citation unless the exact locked edition has been checked. Structural locators may be used provisionally.
