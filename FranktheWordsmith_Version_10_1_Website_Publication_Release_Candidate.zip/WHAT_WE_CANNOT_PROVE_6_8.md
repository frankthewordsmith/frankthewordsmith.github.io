# What We Cannot Prove — Version 6.8

- A reconstructed or fragmentary ancient law collection cannot be treated as a verbatim, continuously preserved code without qualification.
- An online transcription does not by itself establish a locked-print edition page.
- A later witness or secondary report cannot be silently upgraded into a surviving contemporary primary passage.
- The 1976 Jamaica Agreement should not be dated as though the IMF Second Amendment legally entered into force in 1976; the effective date was 1 April 1978.
- The 1694 Bank of England Act and the 1694 Royal Charter must not be merged into one citation.
- Where an exact passage has not been independently locked to an edition/page or precise section, the record remains below A grade even if the historical proposition is well established.
