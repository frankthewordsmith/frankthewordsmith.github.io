# Citation Manifest — Version 6.4

Selected live verification points used during the 6.4 build:

- Justinian, *Digest* 22.1: https://droitromain.univ-grenoble-alpes.fr/Corpus/d-22.htm
- Federal Reserve Act §12A: https://www.federalreserve.gov/aboutthefed/section12a.htm
- Maimonides, *Mishneh Torah*, Creditor and Debtor 4:5: https://www.sefaria.org/Mishneh_Torah%2C_Creditor_and_Debtor.4.5
- Maimonides, *Mishneh Torah*, Creditor and Debtor 5:2: https://www.sefaria.org/Mishneh_Torah%2C_Creditor_and_Debtor.5.2
- *Shulchan Arukh*, Yoreh De'ah 161:1: https://www.sefaria.org.il/Shulchan_Arukh%2C_Yoreh_De%27ah.161.1
- Exodus 22:25: https://www.sefaria.org/Exodus.22.25
