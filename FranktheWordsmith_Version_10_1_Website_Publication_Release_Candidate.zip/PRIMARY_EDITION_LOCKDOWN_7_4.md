# Primary-Edition Lockdown 7.4

| Target | Result | Reason |
|---|---|---|
| Aquinas II-II q.78 a.1 | B retained | Stable article locator verified; Leonine page lock not established |
| Aquinas II-II q.78 a.2 | B retained | Stable article locator verified; Leonine page lock not established |
| Maimonides, Creditor and Debtor 4 | B retained | Stable chapter/section locator; print pagination still edition-dependent |
| Maimonides, Creditor and Debtor 5 | B retained | Stable chapter/section locator; print pagination still edition-dependent |
| 37 Hen. VIII c.9 | B retained | Statute identification secure; authoritative scan/page lock not established |
| 13 Eliz. I c.8 | B retained | Statute identification secure; authoritative scan/page lock not established |
| 21 Jac. I c.17 | B retained | Statute identification secure; authoritative scan/page lock not established |
| Bank of England Act 1694 | B retained | Citation secure; original/authoritative print page lock not established |
| Bretton Woods Agreements Act 1945 (U.S.) | B retained | 59 Stat. 512 locator secure; exact original page/section quotation lock remains separate task |
| Bretton Woods Agreements Act 1945 (UK) | **A promoted** | Official legislation.gov.uk scan; 9 & 10 Geo. 6 c.19; printed p. I and §§1–5 locked |
