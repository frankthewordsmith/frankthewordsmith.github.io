# Version 5.6 — Medieval Jewish Legal Tradition & Early-Modern Transition

## Scope
This pass adds passage-level records for medieval Jewish legal codification and a 16th-century early-modern bridge. It does not treat later codifiers as if they were the biblical or Talmudic source itself.

## Added records
1. Maimonides, *Sefer ha-Mitzvot*, Negative Commandments 235–237.
2. Maimonides, *Mishneh Torah*, Malveh ve-Loveh chapter 4.
3. Maimonides, *Mishneh Torah*, Malveh ve-Loveh chapter 5.
4. *Shulchan Arukh*, Yoreh De'ah 160.

## Verification rule
Online passage verification is not equivalent to final locked-edition pagination. The records therefore remain marked as primary passages directly verified online, with edition-page verification pending.

## Historical caution
The Maimonides records are medieval codifications of earlier biblical and rabbinic law. The *Shulchan Arukh* is a 16th-century early-modern codification and is therefore a bridge into the next period, not a medieval source in the narrow chronological sense.

## Next research target
Version 5.7 should investigate early-modern commercial practice: *heter iska*, Jewish and Christian merchant contracts, public debt, banking, early interest-rate regulation, and the emergence of modern theories of interest. Each mechanism should receive its own primary passage where possible.
