# Version 6.6 — Publication Edition Notes

Version 6.6 converts the Version 6.5 synthesis into a publication-facing research package.

### Added
- Publication bibliography generated from the source records.
- Passage / quotation index linking each source to its controlled locator and evidence grade.
- Final editorial audit and publication rules.
- Evidence-grade and publication-status fields in `research-data.json`.
- Publication Edition page in the site navigation.

### Citation policy
The project uses Chicago Notes and Bibliography as its default historical style, with adaptations for digitized primary sources and legal materials. The Library of Congress notes that digitized primary-source citations should provide enough information for readers to identify and retrieve the source; the Chicago Manual likewise supports Notes and Bibliography for humanities work and unusual source types.

### Final status
This is a publication edition, not a claim that every source is edition-perfect. Grade B/C/D labels remain visible and are part of the evidence rather than editorial noise.
