# PRIMARY-SOURCE SPRINT 6.2

| Source | Action | Result | Final publication lock? |
|---|---|---|---|
| Maimonides, Mishneh Torah 4 | chronology + primary locator | corrected to 12th c. CE; stable text verified | page pending |
| Maimonides, Mishneh Torah 5 | chronology + primary locator | corrected to 12th c. CE; stable text verified | page pending |
| Calvin, De Usuris Responsum | source URL and provenance | erroneous Bentham URL removed; Calvin bibliographic record restored | critical edition pending |
| Exodus 22 | verse locator | corrected to 22:25 modern numbering | yes for verse locator |
| 37 Hen. VIII c. 9 | statutory identification | stable text and citation confirmed | statute-book page pending |
| 13 Eliz. c. 8 | statutory identification | citation independently confirmed | statute-book page pending |
| 21 Jac. I c. 17 | statutory identification | citation/rate history independently confirmed | statute-book page pending |
| Bank of England Act 1694 | citation | corrected to 5 & 6 Will. & Mar. c. 20 | statute scan pending |
| Banking Act 1933 | section targets | FOMC/Regulation Q provisions confirmed | statute scan pending |
| Banking Act 1935 | section targets | modern FOMC structure / §12A confirmed | statute scan pending |
| IMF Second Amendment | chronology | 1976 approval separated from 1978 entry into force | primary treaty record verified |

## Remaining high-value blockers
- Critical-edition Carolingian legislation.
- Individual Digest fragments.
- Locked print pages for medieval Islamic/Jewish corpora.
- Statute-book scans for early English usury Acts and 1694 Bank Act.
- Direct enacted text for 1933/1935 U.S. banking legislation.
