# Version 7.6 — Primary-Edition Lockdown II

## Scope
This round continued the project's publication standard: primary text first, exact edition/page or equivalent authoritative locator, and no promotion merely because an online transcription is stable.

## A-grade promotion
- **Bretton Woods Agreements Act 1945 — United Kingdom implementation**
  - Citation: **9 & 10 Geo. 6 c. 19**, enacted 20 December 1945.
  - Official primary source: legislation.gov.uk PDF.
  - Locator: printed p. I (title/opening page), chapter 19; §§1–5 for the operative opening provisions.
  - This is kept distinct from the **1944 Bretton Woods Final Act** and from the **U.S. Bretton Woods Agreements Act, 59 Stat. 512 (1945)**.

## Deliberate non-promotions
Aquinas II-II q.78 aa.1–2, Maimonides *Mishneh Torah* Creditor and Debtor chs. 4–5, the 1545/1571/1624 English usury statutes, and the 1694 Bank of England Act remain B-grade because an authoritative exact print/edition page lock was not established to the project's standard in this round.

## Important distinction
The UK 1945 Act is a separate source record. It must not be substituted for the U.S. 1945 Act or treated as if it were the 1944 international agreement.

## Current direction
The project should now prioritize exact archival/print locks for the remaining high-value medieval and English statutory sources rather than accumulating additional web-only confirmations.
