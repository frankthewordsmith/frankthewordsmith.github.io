# Direct Edition/Facsimile Verification — Version 9.0

## Verification matrix

| Record | Direct passage witness | Edition/page lock | Grade | Action |
|---|---|---|---|---|
| Aquinas II-II q.78 a.1 | Yes, online text | No direct scan/page confirmation | B | Retain B |
| Aquinas II-II q.78 a.2 | Yes, online text | No direct scan/page confirmation | B | Retain B |
| Digest 22.1 | Yes, Mommsen-based Latin text | No print page | B | Retain B |
| Codex 4.32.26 | Yes, Krueger-based Latin text | No print page | B | Retain B |
| Maimonides Sefer ha-Mitzvot 235–237 | Edition identified | No direct edition-page scan | B | Retain B |

## Direct witness notes
The University of Grenoble Roman-law corpus identifies the *Digest* text as based on Mommsen and supplies the exact 22.1 title and 22.1.1 locator. Its *Codex* corpus identifies Krueger and supplies the complete 4.32.26 passage. These are strong passage witnesses, but they are not equivalent to a verified printed page in the project’s A-grade sense.

## Editorial consequence
No A-grade promotion occurred in this round. This is intentional: the archive records the difference between **passage verified** and **edition/page locked** rather than collapsing them.
