# Version 6.8 — Independent Citation & Chronology Audit

Date: 2026-09-23

## Scope
Every record in the 6.7 source inventory was checked for chronology fields, primary/secondary provenance, locator presence, source URL, and whether the current verification language claims an edition/page/section lock. This is an integrity audit, not a mass promotion of grades.

## Inventory
- Records audited: 58
- Grade counts: A=2, B=51, C=4, D=1
- Rows with explicit gaps or caution flags: 51

## High-priority chronology controls
1. **Bank of England, 1694:** the Royal Charter dated 27 July 1694 and the Bank of England Act 1694 (5 & 6 Will. & Mar. c.20) are separate instruments.
2. **IMF/Jamaica:** the 1976 Jamaica reform agreement is distinct from the Second Amendment's legal effectiveness on 1 April 1978.
3. **Ancient legal corpora:** composition/reconstruction dates must not be presented as identical to manuscript/witness dates.
4. **Statutes:** enactment must be distinguished from later amendment, consolidation, repeal, or survival.

## Citation integrity rule
A stable online passage is not automatically a locked-print citation. Records remain B unless the project has independently locked the exact edition plus page/section locator.

## Result
No broad historical expansion is authorized by this audit. The next publication step is editorial cleanup plus freezing only those citations that already satisfy the A-grade standard.
