# Version 7.0 — Research Integrity Rules

1. Primary texts are the first line of evidence; secondary works contextualize rather than replace them.
2. A digital transcription is not automatically an edition-locked print citation.
3. Composition date, manuscript/witness date, publication date, enactment date, repeal date, agreement date, and legal-effective date remain distinct.
4. Reconstructed or composite texts remain explicitly labelled.
5. Later witnesses remain later witnesses.
6. A citation must permit a future researcher to retrace the path from claim to source.
7. No quotation is upgraded merely because it is widely reproduced online.
8. No unsupported historical inference is converted into a fact by repetition.
9. When evidence is incomplete, the limitation is part of the result.
10. AI-assisted research does not substitute for source criticism, provenance checking, or independent verification.

These controls follow standard primary-source practice: identify creator, date, title, location, repository/stewardship, stable digital access, and the limits of what the source can answer.
