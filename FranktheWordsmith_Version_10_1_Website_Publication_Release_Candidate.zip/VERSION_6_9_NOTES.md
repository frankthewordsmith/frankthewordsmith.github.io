# Version 6.9 — Final Research Edition

Date: 2026-09-23

## Purpose
Version 6.9 is the final research edition following the independent citation and chronology audit in Version 6.8.

## Editorial freeze
- 58 source records retained.
- Evidence grades remain A=2, B=51, C=4, D=1.
- No source was promoted without the project's full primary-source/page-lock standard.
- Chronological distinctions identified in 6.8 are preserved.
- The “What We Cannot Prove” register remains part of the edition.
- Online passage verification is not represented as equivalent to locked-print pagination.

## Principal chronology controls
1. Ancient reconstructed law collections: composition/reconstruction and surviving witness dates remain distinct.
2. 1694 Bank of England Charter and 5 & 6 Will. & Mar. c.20 remain separate instruments.
3. Statutory enactment, amendment, repeal, and later consolidation remain distinct events.
4. IMF Second Amendment: 1976 adoption/reform stage is distinct from its legal entry into force on 1 April 1978.

## Research standard
This edition is frozen conservatively. Remaining B/C/D records are explicit research limitations, not silently upgraded claims.
