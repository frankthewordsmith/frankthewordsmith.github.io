# Version 5.4 — Master Audit & Chronology Consolidation

## Purpose
This release audits the passage-driven timeline as a whole before adding another major regional block. The governing rule is: a source is not treated as a verified primary passage merely because the work is historically relevant or a secondary quotation exists.

## Evidence classes
- **GREEN — Primary passage directly verified:** the passage/locator has been checked against a stable primary-text presentation or the locked edition record.
- **YELLOW — Primary passage identified; edition/page pending:** the text is identified, but the locked print edition still needs page-level inspection before publication-grade quotation.
- **ORANGE — Reconstructed/fragmentary:** the historical source is primary, but the surviving textual state is composite, fragmentary, or dependent on reconstruction. The reconstruction must be labelled.
- **BLUE — Secondary/witness evidence:** useful for historical interpretation but not to be presented as an intact primary-source quotation.

## Audit results
1. Mesopotamian legal material is retained as the earliest secure legal evidence. Ur-Nammu and Eshnunna are composite/inscriptional records and must not be described as a single intact tablet when the edition is composite.
2. Hammurabi §§48–52 remain the secure debt/crop-failure evidence. The familiar §88 rate material remains separately flagged as reconstruction/edition-dependent rather than treated as an untouched sequence.
3. Biblical passages are primary textual witnesses, but the Exodus entry has been normalized to **Exodus 22:25** in common modern verse numbering; older numbering may differ. The Hebrew/critical edition is still required for textual-variant work.
4. Greek evidence needs careful treatment: Solon is known through later literary witnesses, so claims about Solonian interest restrictions should not be presented as a surviving Solonian law text without qualification. The audit therefore does not promote secondary summaries to primary status.
5. Roman evidence is divided between surviving juristic/legal texts and later testimony about lost republican material. The Twelve Tables entry remains non-quotation status until fragment/edition verification is complete.
6. Justinianic Digest/Codex material is suitable for direct passage work, with stable title/book/title/fragment locators preferred over page numbers alone.
7. Nicaea Canon 17 is retained as a primary conciliar canon; later Gratian material is treated as a distinct medieval canon-law compilation, not as the original fourth-century canon.
8. Christian patristic material is kept work-specific. “Augustine” and “Ambrose” are not treated as single undifferentiated sources.
9. Qur'anic material is treated as primary scripture; translation is secondary and must be identified as translation.
10. Hadith and fiqh are kept distinct: hadith reports are not silently converted into later juristic doctrine, and fiqh manuals are identified as juristic syntheses.
11. The four Sunni legal-school entries remain edition-page pending where the locked print copies have not yet been inspected.
12. Aquinas is retained as scholastic theology, distinct from canon-law rules and civil law.
13. Modern institutional entries (Bank of England, Federal Reserve, Bretton Woods, 1971) are primary institutional/legal records and should eventually carry document-level locators.

## New audit addition: Gratian
A new medieval canon-law checkpoint is added conceptually at **Gratian, Decretum, Causa XIV, Quaestio III**. The searchable text explicitly distinguishes: “Qui plus quam dederit expetit, usuras accipit,” and Causa XIV, Quaestio IV contains the canonical material on clerical lending and Canon 17. These are medieval compilation passages and must not be confused with the underlying earlier authorities. See the LombardPress text and the Bavarian State Library digital Decretum presentation.

## New audit addition: Greek evidence rule
Greek material will be added in the next regional expansion, but only with a strict witness rule. Aristotle, Lysias, Plato, Plutarch, and later lexicographical/biographical sources can document Greek attitudes and reported laws; they do not automatically constitute surviving Solonian statutory text.

## Next release
Version 5.5 should fill the chronological bridge with **Greek → Byzantine → early medieval Europe**, using the same evidence classes and explicitly identifying later witnesses to lost laws.
