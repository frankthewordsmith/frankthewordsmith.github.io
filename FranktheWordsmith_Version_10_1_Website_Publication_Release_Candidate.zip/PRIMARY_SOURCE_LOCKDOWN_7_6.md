# Primary Source Lockdown 7.6 — Islamic Fiqh

## Objective
Lock the Islamic fiqh layer of the passage-driven archive by separating four things: the historical juristic work, the specific compilation/redaction, the selected modern print edition, and the exact page locator.

## Results
- **Hanafi — al-Sarakhsi, al-Mabsut:** retained **A-grade**. The archive already has a named 2001 Dar al-Kutub al-ʿIlmiyyah edition, 31-volume count, and vol. 12, pp. 110–111 passage lock.
- **Maliki — Sahnun, al-Mudawwana al-Kubra:** remains **B-grade**. The selected 1415/1994 Dar al-Kutub al-ʿIlmiyyah, 5-volume edition is bibliographically established, but the exact ribā passage page has not been directly locked in that copy.
- **Shafiʿi — al-Umm:** remains **B-grade**. The selected 1422/2001 Dar al-Wafaʾ, 11-volume edition is identified, but the exact page for the selected Kitab al-Buyuʿ / Kitab al-Sarf passage remains pending direct copy inspection.
- **Hanbali — Ibn Qudama, al-Mughni:** remains **B-grade**. The selected 1417/1997 Dar ʿAlam al-Kutub, 15-volume edition is identified, but the archive does not promote a page cited only through a secondary witness.

## Research rule
Bibliographic confirmation is not page verification. A later scholarly or online citation can identify a target page, but it does not become an A-grade page lock until the target edition itself is checked.

## Negative controls
Do not transfer pagination between Beirut, Cairo, Riyadh, Istanbul, or other printings. Do not treat a later school's summary as the wording of Qurʾan or Hadith. Do not collapse school-specific doctrine into a single undifferentiated “Islamic position.”
