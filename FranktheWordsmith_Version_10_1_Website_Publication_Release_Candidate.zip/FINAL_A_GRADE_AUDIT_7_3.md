# Final A-Grade Audit — Version 7.6

## Status

Version 7.6 is a targeted primary-edition lockdown, not a blanket upgrade. It promotes only records for which the edition and page fields are now explicitly locked.

## Evidence inventory

A = 6 primary records/record variants
B = remaining passage-level records requiring edition/page or folio conversion
C = fragmentary/reconstructed corpora
D = non-primary/contextual material

## A-grade records added in 7.3

- `bentham-defence-usury-1787`
- `bentham-defence-usury-i`
- `adam-smith-wealth-nations-i9`
- `ricardo-principles-ch-v`

The archive already contained A-grade records for Ambrose, al-Sarakhsi, and the 1944 Bretton Woods Final Act.

## Holdbacks

Do not upgrade Aquinas, Maimonides, the Tudor/Stuart usury statutes, Bank of England Act 1694, or the 1945 Bretton Woods Agreements Act until the required print/folio locks are independently established.
