# Version 4.6 — Passage Verification Register

Version 4.6 moves the archive from edition-locking to passage-level verification where a stable critical locator has been independently checked.

## Verified passage locators

### Qur'an
- Qur'an 2:275–279 — verse locator is the primary stable locator; no print page is required for the canonical Arabic text.
- Qur'an 3:130 — verse locator is the primary stable locator.
- English baseline: M. A. S. Abdel Haleem, *The Qur'an*, Oxford World's Classics (Oxford University Press, 2004). Comparative: Nasr et al., *The Study Quran* (HarperOne, 2015).

### Sahih Muslim
- *Sahih Muslim* 1597 — Muhammad Fu'ad 'Abd al-Baqi numbering.
- Checked bibliographic page reference: vol. 3, p. 1218 in the Abd al-Baqi baseline; cite hadith number plus book/chapter, with page only when the consulted physical/digital copy matches the baseline.
- The hadith concerns the prohibition of consuming and dealing in riba and includes the roles of consumer, payer, recorder and witnesses.

### al-Sarakhsi, *al-Mabsut*
- *Kitab al-Buyu'*, "Anwa' al-Riba" — vol. 12, pp. 110–111 in the text consulted; the passage defines riba as an excess without counter-value stipulated in a sale and grounds the prohibition in Qur'an and Sunnah.
- The exact 2001 Dar al-Kutub al-'Ilmiyyah printing is the archive baseline (31 vols.). Page numbers from other printings must not be silently transferred.

### Ambrose, *De Tobia*
- *De Tobia* 9.33 — CSEL 32.2, p. 536.
- The passage uses the language of a lender/loan-shark as a sinner connected with usury; section numbering and CSEL page are the preferred critical locator.
- The CSEL 32.2 baseline is Karl Schenkl's 1897 edition.

### Augustine
- *Enarratio in Psalmum XXXVI* 3.6 — CCSL 38, p. 372.
- The passage defines the usurer by lending money while expecting to receive more than was given, including an expected return in goods rather than money.
- Because the archive's Augustine record is intentionally not tied to one single work, this passage is now recorded as the first individually selected Augustinian work; it should not be generalized to all Augustine texts without qualification.

## Not yet page-verified against the locked print copies

- Sahnun, *al-Mudawwana al-Kubra*, ed. Ahmad 'Abd al-Salam, DKI Beirut, 1st ed. 1415/1994, 5 vols.
- al-Shafi'i, *al-Umm*, ed. Rifat Fawzi 'Abd al-Muttalib, Dar al-Wafa', 1st ed. 1422/2001, 11 vols.
- Ibn Qudama, *al-Mughni*, ed. Abd Allah ibn Abd al-Muhsin al-Turki and Abd al-Fattah Muhammad al-Hulu, Dar 'Alam al-Kutub, 3rd ed. 1417/1997, 15 vols.

For these three records, the archive preserves the stable book/chapter locator but does **not** claim an edition-specific page until the selected physical/digital copy is checked. Online text pagination from another edition is not treated as equivalent evidence.

## Rule

A passage becomes "page verified" only when the quoted wording, structural locator, and page number can be tied to the exact edition baseline recorded in `EDITION_LOCK.md`. Otherwise the archive uses a structural locator and labels the page as pending.
