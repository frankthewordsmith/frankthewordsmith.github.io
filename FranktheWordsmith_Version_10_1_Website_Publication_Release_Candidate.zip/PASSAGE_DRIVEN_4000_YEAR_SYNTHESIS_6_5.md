# Version 6.5 — 4,000-Year Passage-Driven Synthesis

## Editorial status
This is the first continuous chronological synthesis built from the Version 6.4 master primary-passage table. It is **not** a claim that every surviving source is equally complete. Evidence grades remain visible: **A** exact primary text plus edition/locator lock; **B** primary passage with stable locator but print-edition lock pending; **C** reconstruction/composite/later witness; **D** unresolved research target.

## Central historical thread
Across four millennia, the history of lending is not a single linear transition from “usury” to “interest.” The primary record instead shows recurring attempts to answer several different questions: whether a lender may demand an increase over principal; how much increase is legally permissible; whether different commodities or borrowers receive different treatment; whether charitable lending is distinct from commerce; what counts as an exchange rather than a loan; and, much later, how banking institutions create, intermediate, regulate, and stabilize credit at monetary-system scale.

### I. Mesopotamia: lending becomes a regulated legal object
**c. 2112–2095 BCE — Ur-Nammu (C)**. The surviving Ur III legal collection contains reconstructed provisions for interest on barley and silver loans. The record is fragmentary and the online text is composite, so the significance is not that one intact tablet gives a complete “interest code,” but that legal tradition already distinguishes principal, increase, commodity, and term.

**Early second millennium BCE — Eshnunna (C/B)**. The Laws of Eshnunna preserve rate provisions in a later Mesopotamian legal tradition. Together with Ur-Nammu, they show that interest was not merely an abstract moral question: it could be expressed as a legally intelligible quantity attached to specific loan commodities.

**c. 1792–1750 BCE — Hammurabi (C/B)**. Hammurabi's debt provisions provide stronger evidence for regulated credit, but the famous rate material must remain separated from reconstructed lines. The secure historical proposition is that Mesopotamian law addressed loans, repayment, collateral, and creditor/debtor relations; reconstructed interest provisions require explicit qualification.

**Historical transition:** the earliest layer therefore presents **credit as a legal institution** before later traditions turn increasingly to moral, religious, and theological classifications.

### II. Hebrew Bible: the borrower, the brother, and the foreigner
**First millennium BCE — Exodus 22:25, Leviticus 25:35–37, Deuteronomy 23:20–21 (A/B)**. These passages distinguish lending to the poor, treatment of a “brother,” and treatment of a foreigner. The texts are important precisely because they do not simply state one universal numerical interest ceiling. They embed lending in kinship, poverty, covenant, and social obligation.

The result is a different vocabulary of regulation: Mesopotamian texts frequently specify economic/legal mechanics, while biblical passages connect the permissibility of increase to **social relationship and vulnerability**.

### III. Greek philosophy: interest becomes a question about the nature of money
**4th century BCE — Aristotle, *Politics* 1.10, 1258b (A).** Aristotle treats money-lending at interest as problematic in his account of the unnatural or derivative use of money. The passage shifts the argument from merely regulating a transaction to asking whether money can legitimately generate money through lending.

**451–450 BCE — Twelve Tables (B/C)** and **Plutarch, *Life of Solon* 15 (C)** preserve traditions concerning early Roman/Greek regulation, but these are weaker evidence for exact ancient provisions because the Twelve Tables survive through later witnesses and Plutarch is much later than Solon. They belong in the chronology as evidence of remembered legal traditions, not as verbatim surviving legislation.

### IV. Roman law: from moral category to technical legal doctrine
**6th century CE — Justinian's *Digest* 22.1 and *Codex* 4.32 (B/A depending on passage)**. Roman law turns interest into a technically structured legal category. The relevant texts address the stipulation, calculation, limits, and enforceability of interest. This is a major change in institutional form: the question is no longer only whether interest is morally acceptable; it is also how a legal system defines and administers it.

**528–529 CE — Codex 4.32.26 and 4.32.27–28 (A/B).** The individually isolated constitutions provide a cleaner evidence base than a generic citation to “Roman law.” The project therefore treats each constitution as its own passage record.

### V. Christian late antiquity: lending becomes a moral and clerical discipline
**325 CE — Nicaea, Canon 17 (B).** The canon addresses clerical participation in interest-taking, making the issue one of ecclesiastical discipline as well as economic conduct.

**c. 380 CE — Ambrose, *De Tobia* (B)** and **Augustine (B)** develop the moral and pastoral critique of exploitative lending. The important historical point is not that Christianity invented opposition to interest, but that Christian institutions increasingly attached the practice to clerical ethics, charity, and treatment of the poor.

**692 CE — Quinisext/Trullo, Canon 10 (A/B).** The Byzantine canonical tradition continues this disciplinary trajectory.

### VI. Islamic revelation and fiqh: ribā is differentiated from ordinary trade
**7th century CE — Qur'an 2:275–279 and 3:130 (A/B).** These passages place ribā within a revealed legal-moral framework and distinguish it from permitted trade. The Qur'anic evidence is foundational for the later Islamic legal tradition, but the later juristic definitions should not be retroactively inserted into the Qur'anic wording.

**9th century CE — Sahih Muslim 1584e, 1587c, 1597 (B).** Hadith literature expands the legal categories of ribā, especially in exchange transactions. These passages show how the prohibition was articulated through specific commodity and exchange rules.

**8th–12th centuries — al-Mudawwana, al-Sarakhsi, al-Shafi'i's *Umm*, Ibn Rushd, Ibn Qudama (B).** The juristic record transforms scriptural prohibition into detailed doctrine. Different schools classify transactions through different legal mechanisms, but the shared project is to identify when an increase or inequality belongs to a prohibited exchange or loan. Print-edition pagination remains open for several of these records, so the synthesis uses structural locators rather than invented pages.

### VII. Medieval Jewish law: prohibition becomes a detailed transactional code
**12th century — Maimonides, *Sefer ha-Mitzvot* and *Mishneh Torah*, *Malveh ve-Loveh* 4–5 (B).** Maimonides systematizes rules concerning creditor, debtor, interest, and prohibited forms of increase. The legal tradition is not simply a moral prohibition; it becomes a highly granular taxonomy of transactions.

**16th century — *Shulchan Arukh*, Yoreh De'ah 160 (B).** The early-modern Jewish legal code continues and reorganizes these rules. The continuity from medieval jurisprudence to early modern codification is one of the clearest long-duration patterns in the archive.

### VIII. Medieval Christian scholasticism: the sale of time, risk, and compensation
**13th century — Aquinas, *Summa Theologiae* II–II, q.78, aa.1–2 (B).** Aquinas frames usury through the logic of lending and the sale of something that, in the loan, belongs to the borrower. The second article complicates the picture by examining additional compensation. This becomes a bridge between absolute condemnation of usury and later arguments about legitimate compensation for distinct services or risks.

### IX. Reformation and statutory England: the law moves from prohibition toward regulated price
**1545–1546 — Calvin, *De usuris responsum* (B).** Calvin's response is a major Reformation-era intervention because it treats lending within a more differentiated economic and social framework than a simple universal prohibition. The project keeps the critical/early-edition lock open rather than silently treating a later reproduction as the original edition.

**1545, 1571, 1624 — English Usury Acts (B).** The English statutes progressively establish and modify statutory treatment of interest. Their significance is institutional: the state increasingly regulates the **rate** rather than simply prohibiting the transaction as such. The 1854 repeal statute later identifies the earlier enactments in its repeal schedule.

### X. Public credit and banking: the lender becomes an institution
**1694 — Bank of England Act and Charter (B/A).** The Bank of England's foundation marks a new institutional layer. Public finance, government borrowing, banking, and monetary management begin to overlap. The project keeps the Act and Charter as separate records because they are separate primary documents.

**1776 — Adam Smith, *Wealth of Nations*, I.IX (B)** and **1787 — Bentham, *Defence of Usury* (B)** make the controversy explicitly economic and policy-oriented. The question becomes not only whether interest is morally permissible, but whether legal ceilings improve or impair allocation of capital. Modern scholarship confirms that the Smith–Bentham exchange became a central late-eighteenth-century episode in the transition from “usury” to modern interest-rate analysis. citeturn0search3

**1817 — Ricardo; 1848 — J. S. Mill (B).** Classical political economy increasingly treats interest as part of the distribution and pricing of capital. The older theological/legal category of usury does not disappear, but it is joined by an analytical vocabulary of capital, profit, rent, and market rates.

### XI. Nineteenth century: from usury law to monetary architecture
**1844 — Bank Charter Act; 1854 — Usury Laws Repeal Act (B/A).** The British legal trajectory moves from statutory ceilings toward freer pricing of credit while simultaneously tightening institutional rules around banking and currency issuance. This is a crucial divergence: **interest regulation and monetary-system regulation become increasingly separate policy domains**.

**1873 — Bagehot, *Lombard Street* (B).** Bagehot's analysis treats the central banking problem in terms of liquidity, reserves, and crisis lending. The historical subject has now expanded from the morality of a private lender's gain to the stability of an entire credit system.

Bank of England research also provides a useful modern quantitative reminder that interest rates themselves have a much longer historical record than modern central banking; Schmelzing reconstructs global real interest rates from the fourteenth century onward using archival, printed primary, and secondary sources. That dataset is valuable context but is not substituted for the project's individual primary passages. citeturn0search1

### XII. The twentieth century: central banking and administered credit
**1913 — Federal Reserve Act (A).** The Federal Reserve creates a national central-banking structure intended in part to improve the elasticity and stability of the U.S. banking system. The historical record describes the system as an institutional response to recurring banking panics and an inelastic currency. citeturn0search5

**1933–1935 — Banking Acts (B).** The statutory architecture of the FOMC emerges through the Banking Acts of 1933 and 1935. This is another qualitative shift: monetary policy is no longer only a question of private lending terms; it becomes an organized function of a central-bank system.

### XIII. Bretton Woods to 1971: interest rates become part of international monetary management
**1944–1945 — Bretton Woods Articles and U.S. implementation (A/B).** The international monetary architecture links currencies, gold, reserves, balance-of-payments adjustment, and international lending. The IMF and IBRD are created as institutional mechanisms for the postwar monetary and reconstruction order. The Bretton Woods system was designed around exchange-rate stability and international cooperation; it became fully functional as currencies became convertible in 1958. citeturn0search2turn0search0

**15 August 1971 — Nixon (A).** The suspension of dollar convertibility to gold marks the breakdown of the Bretton Woods monetary mechanism. The historical significance is institutional rather than theological: the relationship among currency, gold, reserves, and international adjustment changes.

### XIV. 1976–2010: international reform and modern financial regulation
**1976 agreement / 1978 legal entry into force — IMF Second Amendment (B).** The Jamaica settlement should be described in two stages: the 1976 agreement and the Second Amendment's later legal entry into force. Collapsing those dates would obscure the distinction between political agreement and formal treaty effectiveness.

**2010 — Dodd-Frank (A/B).** Modern financial law addresses systemic risk, derivatives, consumer protection, resolution, and institutional oversight. By this point the historical category “usury” has become only one small part of a much larger regulatory field governing credit and finance.

## What changes across the 4,000 years?

### 1. From **whether** to **how much**
Early legal and religious traditions often ask whether an increase on a loan is permissible. Mesopotamian law frequently expresses the question through rates and contractual conditions; biblical and religious traditions add relational and moral restrictions. Early-modern statutes increasingly convert the question into a permitted maximum rate.

### 2. From the individual lender to the institution
The lender begins as a private creditor. By the early-modern and modern periods, banks, public debt institutions, central banks, and international financial organizations mediate credit at scales far beyond an individual loan.

### 3. From moral classification to financial architecture
Religious and legal traditions ask whether a transaction is just, charitable, exploitative, or prohibited. Classical economists ask how capital is priced. Modern monetary institutions ask how credit conditions interact with liquidity, currency, banking stability, exchange rates, and systemic risk. These are related historical questions, but they are **not identical questions**.

### 4. The category never simply disappears
The modern word “interest” does not erase the older problem. Modern systems still regulate excessive charges, disclosure, consumer credit, collateral, default, banking conduct, and systemic risk. What changes is the institutional vocabulary and the scale at which the problem is administered.

## Evidence discipline for the final publication
The final publication should quote only passages whose exact locator is established. Composite Mesopotamian texts, later witnesses to lost legislation, and unresolved critical-edition targets should remain visibly labeled. The distinction between a surviving primary passage and a modern historian's reconstruction is itself part of the historical argument.

## Bottom line
The 4,000-year record is best understood as a sequence of **institutional transformations in the meaning and governance of credit**: regulated loan → socially differentiated lending → philosophical critique → technical Roman doctrine → religious/clerical discipline → juristic systems of ribā and interest → scholastic analysis → statutory rate regulation → public credit and banking → classical capital theory → central banking → international monetary architecture → modern financial regulation.
