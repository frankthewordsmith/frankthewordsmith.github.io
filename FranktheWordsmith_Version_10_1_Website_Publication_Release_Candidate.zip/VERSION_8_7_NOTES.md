# Version 9.0 — Narrative Evidence Integration

Date: 2026-09-23

## Purpose
This release converts the source registry into a more explicit passage-to-claim narrative. The aim is not to add unsupported history, but to make the 4,000-year story readable while preserving the evidence distinctions established by the edition-lock audits.

## What changed
- Added `NARRATIVE_EVIDENCE_INTEGRATION_8_7.md`, a chronological synthesis whose substantive claims are bound to canonical source IDs.
- Added `CLAIM_TO_PASSAGE_MAP_8_7.md`, a compact map from major narrative propositions to the source records that support them.
- Updated the publication, synthesis, and timeline landing pages to identify Version 9.0.
- Preserved the Version 8.0/8.4 evidence inventory: A=8, B=46, C=4, D=1.
- Added `audit_8_7` to `research-data.json`.

## Integrity constraints
- No new A-grade promotion is made in this round.
- No new verbatim quotation is introduced without an existing locked locator.
- Composite, reconstructed, later-witness, and edition-pending sources remain explicitly qualified.
- The narrative uses paraphrase when a B-grade source lacks the required print/critical-edition page lock.

## Editorial principle
A readable synthesis is not allowed to become stronger than its underlying evidence. The narrative therefore distinguishes direct legal/textual rules, later juristic interpretation, institutional development, and modern monetary architecture rather than treating them as one continuous doctrine.
