# Primary-Edition Verification & Acquisition Log — 8.4

| Source | Working witness | What is verified | Remaining blocker | Grade |
|---|---|---|---|---|
| Aquinas, *Summa* II-II q.78 | New Advent / CCEL | Text and article structure | Critical/print edition page | B |
| Maimonides, *Mishneh Torah*, Creditor and Debtor 5:2 | Sefaria | Hebrew text and translation | Print-edition page/version lock | B |
| Bank of England Charter 1694 | Bank of England archive M6/48; 10A287/4 | Original charter identity; transcript pp.5–20 | Direct edition/transcript inspection for publication lock | B |
| Bank of England Act 1694 | legislation.gov.uk / point-in-time PDF | Statutory text and citation 5 & 6 Will. & Mar. c.20 | Historical print pagination | B |

## No artificial promotions
The purpose of this log is reproducibility, not grade inflation.
