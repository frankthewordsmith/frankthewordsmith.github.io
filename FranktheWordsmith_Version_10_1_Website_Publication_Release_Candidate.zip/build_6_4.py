import json, os, zipfile, shutil, re
root='/mnt/data/v64work'
p=os.path.join(root,'research-data.json')
D=json.load(open(p))
D['version']='6.4'
# Correct the Exodus URL mismatch carried from 6.2.
for s in D['sources']:
    if s['source_id']=='exodus-22-24':
        s['web_sources']=['https://www.sefaria.org/Exodus.22.25']
        s['passage_record']['source_url']='https://www.sefaria.org/Exodus.22.25'
        s['citation_record']='Hebrew Bible, Exodus 22:25 (JPS 1985; common modern verse numbering).'
        s['bibliography_entry']='Hebrew Bible, Exodus 22:25 (JPS 1985; common modern verse numbering).'

# Evidence-grade rules for the final publication pipeline.
for s in D['sources']:
    sid=s['source_id']; status=s.get('verification_status','').lower(); pr=s.get('primary_or_secondary','').lower()
    grade='B'
    basis='Primary passage is securely located online, but edition/page locking remains incomplete.'
    if 'research target' in status or 'critical edition pending' in status:
        grade='D'; basis='Research target; critical-edition passage still needs to be isolated.'
    elif 'secondary/witness' in status or 'reconstructed' in status or 'composite' in status:
        grade='C'; basis='Later witness, reconstruction, or composite text; usable with explicit provenance labeling.'
    elif 'primary statute verified' in status and 'stable transcription' in status:
        grade='B'; basis='Primary statute passage verified in a stable transcription; statute-book page lock remains open.'
    elif 'green — primary' in status or 'official' in status or 'passage-level record established' in status or 'passage verified' in status or 'citation locked' in status or 'directly verified' in status or 'primary document verified' in status or 'primary institutional record verified' in status:
        grade='B'; basis='Primary text/passage has a stable locator; print/edition locking is not uniformly complete.'
    # Upgrade only where the record itself contains an explicit exact print/page lock.
    if s.get('page') and ('critical' in s.get('edition','').lower() or 'official' in s.get('verification_status','').lower()) and 'pending' not in status:
        # Page numbers alone are not sufficient for A; keep conservative.
        pass
    s['evidence_grade_6_4']=grade
    s['evidence_grade_basis_6_4']=basis

counts={}
for s in D['sources']: counts[s['evidence_grade_6_4']]=counts.get(s['evidence_grade_6_4'],0)+1
D['audit_6_4']={
 'title':'Version 6.4 — Final Primary-Source Evidence Lock',
 'date':'2026-09-23',
 'purpose':'Convert the 6.3 publication-lock inventory into a conservative evidence-grade system and prepare the master passage table for the final 4,000-year synthesis.',
 'grading':{
  'A':'Primary text + exact edition/locator/page (or equivalent critical-edition unit) locked for publication quotation.',
  'B':'Primary text and stable passage locator verified, but print-edition/page locking remains incomplete or varies by edition.',
  'C':'Composite, reconstructed, later-witness, or otherwise indirect evidence; must be labeled as such in narrative use.',
  'D':'Research target whose critical-edition passage has not yet been isolated; do not use as a locked quotation.'},
 'counts':counts,
 'publication_rule':'The final narrative should preferentially quote A records, may cite B records with their exact stable locator and an edition caveat, and should not silently upgrade C or D evidence.',
 'priority_lock_targets':[
  'Carolingian Aachen/Nijmegen: isolate the exact anti-usury capitulary passage in a critical MGH/Capitularia edition.',
  'Roman Digest/Codex: attach exact fragment/constitution numbers and edition units to every quotation used in the narrative.',
  'Islamic legal schools: lock print pagination for al-Mudawwana, al-Umm, and al-Mughni.',
  'Jewish medieval/early-modern law: lock edition pagination for Maimonides and Shulchan Arukh where print quotation is used.',
  'Reformation/early modern: lock an early/critical edition for Calvin and the Tudor-Stuart statutes.',
  'Classical economics and modern monetary law: lock the exact edition or statute section for Smith, Bentham, Ricardo, Mill, Bagehot, Bank Charter Act 1844, Banking Acts 1933/35, and Bretton Woods implementing legislation.'
 ],
 'chronology_checks':[
  'Do not equate composition date with manuscript witness date.',
  'Do not treat a later witness as the original law text.',
  'Keep composite/reconstructed Mesopotamian legal collections separate from intact witnesses.',
  'Keep the 1976 Jamaica agreement distinct from the 1978 entry into force of the IMF Second Amendment.',
  'Keep the 1694 Bank of England Charter distinct from the Bank of England Act 5 & 6 Will. & Mar. c.20.'
 ]
}
open(p,'w').write(json.dumps(D,ensure_ascii=False,indent=2))

# Master passage table
rows=[]
for s in D['sources']:
    pr=s.get('passage_record',{})
    rows.append((s.get('date_start',''), s.get('source_id',''), s.get('date_label',''), s.get('title',''), s.get('reference_number',''), pr.get('locator',''), s.get('evidence_grade_6_4',''), s.get('verification_status','')))
rows.sort(key=lambda x: (int(x[0]) if str(x[0]).lstrip('-').isdigit() else 999999, x[1]))
md=['# VERSION 6.4 — MASTER PRIMARY-PASSAGE TABLE','', 'This table is the evidence spine for the eventual 4,000-year narrative. It deliberately separates secure passage locators from publication-grade edition locks.','', '| Date | Source | Passage / locator | Evidence | Verification |','|---|---|---|---|---|']
for date,sid,label,title,ref,loc,grade,status in rows:
    passage=loc or ref or '—'
    md.append(f'| {label} | `{sid}` — {title} | {passage} | **{grade}** | {status} |')
open(os.path.join(root,'MASTER_PRIMARY_PASSAGE_TABLE_6_4.md'),'w').write('\n'.join(md)+'\n')

# Sprint notes
notes='''# Version 6.4 Notes — Final Primary-Source Evidence Lock\n\n## Purpose\nVersion 6.4 does not broaden the chronology. It converts the Version 6.3 publication-lock work into a conservative evidence-grade system and creates the master passage table that will drive the final 4,000-year synthesis.\n\n## Evidence grades\n- **A** — primary text plus exact edition/locator/page (or equivalent critical-edition unit) locked for publication quotation.\n- **B** — primary text and stable passage locator verified, but print-edition/page locking remains incomplete.\n- **C** — composite, reconstructed, later-witness, or otherwise indirect evidence.\n- **D** — research target whose critical-edition passage is not yet isolated.\n\nThe archive intentionally errs toward the lower grade. A source is not upgraded merely because a webpage reproduces a text.\n\n## Targeted confirmations\n- Justinian, *Digest* 22.1 is organized as **De usuris et fructibus et causis et omnibus accessionibus et mora**, and individual fragments such as D.22.1.1 are available in the Mommsen-based online Latin text.\n- Federal Reserve Act §12A provides the statutory text of the Federal Open Market Committee; the current Federal Reserve transcription identifies the provision as added in 1933 and completely revised in 1935.\n- Maimonides, *Mishneh Torah*, Creditor and Debtor 4:5 and 5:2 are directly locatable in Sefaria.\n- *Shulchan Arukh*, Yoreh De'ah 161:1 is directly locatable in Sefaria.\n\n## Important correction\nThe Exodus record now points consistently to **Exodus 22:25 in common modern verse numbering** rather than retaining the earlier mismatched URL.\n\n## Next stage\nVersion 6.5 should use this table to write the passage-driven 4,000-year synthesis. Remaining A-grade publication locks can be completed in parallel, but C/D material must remain visibly labeled and must not be silently converted into primary quotations.\n'''
open(os.path.join(root,'VERSION_6_4_NOTES.md'),'w').write(notes)

# Citation manifest
manifest=['# Citation Manifest — Version 6.4','', 'Selected live verification points used during the 6.4 build:', '', '- Justinian, *Digest* 22.1: https://droitromain.univ-grenoble-alpes.fr/Corpus/d-22.htm', '- Federal Reserve Act §12A: https://www.federalreserve.gov/aboutthefed/section12a.htm', '- Maimonides, *Mishneh Torah*, Creditor and Debtor 4:5: https://www.sefaria.org/Mishneh_Torah%2C_Creditor_and_Debtor.4.5', '- Maimonides, *Mishneh Torah*, Creditor and Debtor 5:2: https://www.sefaria.org/Mishneh_Torah%2C_Creditor_and_Debtor.5.2', "- *Shulchan Arukh*, Yoreh De'ah 161:1: https://www.sefaria.org.il/Shulchan_Arukh%2C_Yoreh_De%27ah.161.1", '- Exodus 22:25: https://www.sefaria.org/Exodus.22.25', '']
open(os.path.join(root,'CITATION_MANIFEST_6_4.md'),'w').write('\n'.join(manifest))

# Update visible site version strings and append a small audit notice.
for fn in ['index.html','timeline.html','research.html','references.html','source.html','about.html']:
    fp=os.path.join(root,fn)
    if not os.path.exists(fp): continue
    txt=open(fp,encoding='utf-8').read()
    txt=re.sub(r'Version 6\.3', 'Version 6.4', txt)
    txt=re.sub(r'v6\.3', 'v6.4', txt, flags=re.I)
    open(fp,'w',encoding='utf-8').write(txt)

# Create ZIP
zip_path='/mnt/data/FranktheWordsmith_Version_6_4_Final_Primary_Source_Evidence_Lock.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for dirpath,_,files in os.walk(root):
        for f in files:
            if f.endswith('.zip'): continue
            full=os.path.join(dirpath,f)
            z.write(full, os.path.relpath(full,root))
print(zip_path)
print('counts',counts)
print('files',len(zipfile.ZipFile(zip_path).namelist()))
