# FINAL A-GRADE CONVERSION AUDIT — 6.7

Source records: 58


## Grade A — 2 records

- ambrose-de-tobia
- hanafi-riba-sarakhsi

## Grade B — 51 records

- exodus-22-24
- leviticus-25-35-37
- deuteronomy-23-20-21
- mishnah-bm-5
- talmud-bm
- roman-twelve-tables
- roman-digest-22-1
- roman-codex-interest
- nicaea-canon-17
- augustine-usury
- quran-2-275-279
- quran-3-130
- hadith-muslim-1587c
- hadith-muslim-1597
- maliki-riba-mudawwana
- shafii-riba-umm
- hanbali-riba-mughni
- aquinas-q78-a1
- aquinas-q78-a2
- boe-1694
- hadith-muslim-1584e
- ibn-rushd-bidayat-riba
- aristotle-politics-1258b
- justinian-codex-4-32-26
- justinian-codex-4-32-27-28
- trullo-canon-10
- maimonides-sefer-mitzvot-235-237
- maimonides-mishneh-torah-ml-4
- maimonides-mishneh-torah-ml-5
- shulchan-arukh-yoreh-deah-160
- calvin-de-usuris-1545
- henry-viii-usury-act-1545
- elizabeth-usury-act-1571
- james-usury-act-1624
- boe-charter-1694
- bank-act-1694
- bentham-defence-usury-1787
- adam-smith-wealth-nations-i9
- bentham-defence-usury-i
- ricardo-principles-ch-v
- bank-charter-act-1844
- usury-laws-repeal-1854
- js-mill-principles-interest
- fed-act-1913
- banking-act-1933
- banking-act-1935
- bretton-woods-1944
- bretton-woods-act-1945
- nixon-1971
- jamaica-1976-imf
- dodd-frank-2010

## Grade C — 4 records

- ur-nammu
- eshnunna
- hammurabi
- plutarch-solon-15

## Grade D — 1 records

- carolingian-usury-aachen-nijmegen

## Editorial findings

- Two records were promoted to A-grade because their exact passages and edition-specific page locators were already locked.
- All other B-grade records remain B until their specific edition/page locks are independently verified.
- C-grade composite/reconstructed/later-witness material remains explicitly qualified.
- No D-grade record was promoted without new evidence.