# Primary Source Lockdown 7.5

## Ancient and Late-Antique Audit

**Ur-Nammu — C-grade retained.** CDLI's RIME 3/2.01.01.20 composite records the interest provisions for barley and silver loans. Cite the exact composite lines, but do not present the reconstruction as an intact single-tablet quotation.

**Eshnunna — C-grade retained.** The selected provision remains dependent on a fragmentary/composite textual tradition; physical-page A-grade conversion remains pending.

**Hammurabi — C-grade retained.** Secure debt/crop-failure provisions must remain separate from the lacunary/reconstructed interest-rate material.

**Digest 22.1 — B-grade retained.** The Mommsen-based online text establishes *De usuris et fructibus et causis et omnibus accessionibus et mora* and D.22.1.1. A print-page lock remains outstanding.

**Codex 4.32 — B-grade retained.** The Krueger-based online text establishes *De usuris* and C.4.32.26–28, including rate ceilings, treatment of excess interest, and prohibition of interest on interest. Exact print pagination remains outstanding.

**Nicaea, Canon 17 — B-grade retained.** The canon is secure at canon-level locator. Turner/EOMIA is the critical Latin-edition route, but this sprint did not establish the exact page from the primary scan.

**Trullo, Canon 10 — B-grade retained.** Canon-level verification is sufficient for contextual use; physical primary-edition lock remains pending.

**Ambrose, De Tobia 9.33 — A-grade retained.** CSEL 32.2, p. 536 remains the locked edition/page reference.

## Rule enforced

A-grade = primary text + named edition + exact edition-specific page/folio or equally stable physical locator + passage-level identification + provenance record.

Online visibility alone never upgrades a source.
