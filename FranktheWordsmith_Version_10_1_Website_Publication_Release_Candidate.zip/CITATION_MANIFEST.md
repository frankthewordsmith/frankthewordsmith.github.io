# FranktheWordsmith Version 4.4 — Citation Manifest

This manifest records the citation identity for every research source. Stable locators are preferred; edition-specific page numbers are included only when verified.

## Laws of Ur-Nammu (`ur-nammu`)
**Status:** Citation locked — primary/source locator recorded
**Citation:** Martha T. Roth, Law Collections from Mesopotamia and Asia Minor, 2nd ed. (Atlanta: Scholars Press, 1997), Laws of Ur-Namma, pp. 13–39; compare CDLI composite.
**Web:** https://cdli.earth/artifacts/432130; https://cir.nii.ac.jp/crid/1390001205342537856

## Laws of Eshnunna (`eshnunna`)
**Status:** Citation locked — primary/source locator recorded
**Citation:** Martha T. Roth, Law Collections from Mesopotamia and Asia Minor, 2nd ed. (Atlanta: Scholars Press, 1997), Laws of Eshnunna, pp. 57–66; Law 18a.
**Web:** https://cdli.earth/artifacts/480696; https://cdli.earth/inscriptions/2269340

## Code of Hammurabi (`hammurabi`)
**Status:** Citation locked — primary/source locator recorded
**Citation:** Martha T. Roth, Law Collections from Mesopotamia and Asia Minor, 2nd ed. (Atlanta: Scholars Press, 1997), Laws of Hammurabi, pp. 71–142.
**Web:** https://avalon.law.yale.edu/ancient/hamcode.asp; https://doi.org/10.2307/jj.25577265

## Exodus 22:24 — lending to the poor (`exodus-22-24`)
**Status:** Citation locked — primary/source locator recorded
**Citation:** Hebrew Bible, Exodus 22:24 (JPS 1985).
**Web:** https://www.sefaria.org/Exodus.22.24

## Leviticus 25:35–37 — neshekh and tarbit (`leviticus-25-35-37`)
**Status:** Citation locked — primary/source locator recorded
**Citation:** Hebrew Bible, Leviticus 25:35–37 (JPS 1985).
**Web:** https://www.sefaria.org/Leviticus.25.35-37

## Deuteronomy 23:20–21 — brother and foreigner (`deuteronomy-23-20-21`)
**Status:** Citation locked — primary/source locator recorded
**Citation:** Hebrew Bible, Deuteronomy 23:20–21 (JPS 1985).
**Web:** https://www.sefaria.org/Deuteronomy.23.20-21

## Mishnah Bava Metzia 5 — definitions and mechanisms of ribbit (`mishnah-bm-5`)
**Status:** Citation locked at stable source locator; edition/page to be added if a print quotation is used
**Citation:** Mishnah Bava Metzia 5:1–11; Neusner, The Mishnah: A New Translation (Yale University Press, 1988), tractate Bava Metzia, ch. 5.
**Web:** https://www.sefaria.org/Mishnah_Bava_Metzia.5

## Babylonian Talmud, Bava Metzia — ribbit sugyot (`talmud-bm`)
**Status:** Citation locked at stable source locator; edition/page to be added if a print quotation is used
**Citation:** Babylonian Talmud, Bava Metzia 60b–75b; cite the individual daf/amud for every quotation.
**Web:** https://www.sefaria.org/Bava_Metzia.60b

## Roman Twelve Tables — early interest regulation tradition (`roman-twelve-tables`)
**Status:** Citation framework locked — exact edition/page still required before publication quotation
**Citation:** Twelve Tables, Table VIII; surviving wording is fragmentary and transmitted through later authors. Use a modern critical edition such as Crawford, Roman Statutes (1996), with the specific fragment cited.
**Web:** https://academic.oup.com/edited-volume/61673/chapter-abstract/548932147

## Digest 22.1 — interest as a Roman legal category (`roman-digest-22-1`)
**Status:** Citation locked at stable source locator; edition/page to be added if a print quotation is used
**Citation:** Justinian, Digesta 22.1, De usuris et fructibus et causis et omnibus accessionibus; cite individual fragment (D. 22.1.xx) rather than a page number.
**Web:** https://academic.oup.com/book/36387/chapter-abstract/319983267

## Codex 4.32 — Justinian on interest (`roman-codex-interest`)
**Status:** Citation locked at stable source locator; edition/page to be added if a print quotation is used
**Citation:** Justinian, Codex 4.32, De usuris; cite individual constitution (C. 4.32.xx).
**Web:** https://droitromain.univ-grenoble-alpes.fr/Anglica/CJ4_Scott.htm

## First Council of Nicaea — Canon 17 (`nicaea-canon-17`)
**Status:** Citation locked at stable source locator; edition/page to be added if a print quotation is used
**Citation:** First Council of Nicaea (325), Canon 17; cite the canon number. For a modern critical edition use Norman P. Tanner, Decrees of the Ecumenical Councils, vol. 1 (Georgetown University Press, 1990), Nicaea I, Canon 17.
**Web:** https://www.newadvent.org/fathers/3801.htm

## Ambrose, De Tobia — Christian condemnation of usury (`ambrose-de-tobia`)
**Status:** Citation framework locked — exact edition/page still required before publication quotation
**Citation:** Ambrose, De Tobia, esp. chs. 1–15; final print citation should name the edition used for the Latin text and its page/column range.
**Web:** https://www.tertullian.org/fathers/ambrose_de_tobia_01.htm

## Augustine — lending, charity and the poor (`augustine-usury`)
**Status:** Citation framework locked — exact edition/page still required before publication quotation
**Citation:** Augustine: select an individual sermon/letter before quotation; do not cite “Augustine” as a single undifferentiated source. Noonan, The Scholastic Analysis of Usury (Harvard University Press, 1957), provides the historical analysis.
**Web:** 

## Qur’an 2:275–279 — ribā and trade (`quran-2-275-279`)
**Status:** Citation framework locked — exact edition/page still required before publication quotation
**Citation:** Qur’an 2:275–279; for publication, identify the Arabic text edition and the named English translation used.
**Web:** https://quran.com/2/275-279

## Qur’an 3:130 — multiplied ribā (`quran-3-130`)
**Status:** Citation framework locked — exact edition/page still required before publication quotation
**Citation:** Qur’an 3:130; for publication, identify the Arabic text edition and the named English translation used.
**Web:** https://quran.com/3/130

## Sahih Muslim 1587c — ribā in exchange (`hadith-muslim-1587c`)
**Status:** Citation locked at stable source locator; edition/page to be added if a print quotation is used
**Citation:** Sahih Muslim 1587c, Book 22 (Musaqah), hadith 102 in Sunnah.com numbering; cite the Arabic text/edition if quoting Arabic.
**Web:** https://sunnah.com/muslim:1587c

## Sahih Muslim 1597 — six commodities (`hadith-muslim-1597`)
**Status:** Citation framework locked — exact edition/page still required before publication quotation
**Citation:** Sahih Muslim 1597; cite the specific in-book numbering and a named Arabic/print edition for publication.
**Web:** https://sunnah.com/muslim:1597

## Hanafi fiqh — al-Sarakhsi on ribā (`hanafi-riba-sarakhsi`)
**Status:** Citation framework locked — exact edition/page still required before publication quotation
**Citation:** al-Sarakhsi, al-Mabsut, Kitab al-Buyuʿ / Kitab al-Sarf; because Beirut printings vary, the archive should store the exact edition, volume and page used for each quotation.
**Web:** 

## Maliki fiqh — al-Mudawwana on ribā (`maliki-riba-mudawwana`)
**Status:** Citation framework locked — exact edition/page still required before publication quotation
**Citation:** Sahnun, al-Mudawwana al-Kubra, relevant Kitab al-Buyuʿ / Kitab al-Sarf; store exact edition, volume and page for each quotation.
**Web:** 

## Shafi‘i fiqh — al-Umm on ribā (`shafii-riba-umm`)
**Status:** Citation framework locked — exact edition/page still required before publication quotation
**Citation:** al-Shafiʿi, al-Umm, Kitab al-Buyuʿ / Kitab al-Sarf; store exact edition, volume and page for each quotation.
**Web:** 

## Hanbali fiqh — Ibn Qudama on ribā (`hanbali-riba-mughni`)
**Status:** Citation framework locked — exact edition/page still required before publication quotation
**Citation:** Ibn Qudama, al-Mughni, Kitab al-Buyuʿ / Kitab al-Sarf; store exact edition, volume and page for each quotation.
**Web:** 

## Thomas Aquinas — usury as unjust sale (`aquinas-q78-a1`)
**Status:** Citation locked at stable source locator; edition/page to be added if a print quotation is used
**Citation:** Thomas Aquinas, Summa theologiae II–II, q. 78, a. 1; cite objection/reply number when quoting.
**Web:** https://www.newadvent.org/summa/3078.htm

## Thomas Aquinas — other compensation for a loan (`aquinas-q78-a2`)
**Status:** Citation locked at stable source locator; edition/page to be added if a print quotation is used
**Citation:** Thomas Aquinas, Summa theologiae II–II, q. 78, a. 2; cite objection/reply number when quoting.
**Web:** https://www.newadvent.org/summa/3078.htm

## Bank of England — foundation and emergence of modern central banking (`boe-1694`)
**Status:** Citation locked at stable source locator; edition/page to be added if a print quotation is used
**Citation:** Bank of England, official institutional history, “History of the Bank”; cite the web page and access date for current web content.
**Web:** https://www.bankofengland.co.uk/about/history

## Federal Reserve Act — institutional transformation of U.S. banking (`fed-act-1913`)
**Status:** Citation locked at stable source locator; edition/page to be added if a print quotation is used
**Citation:** Federal Reserve Act, ch. 6, 38 Stat. 251 (1913); cite the relevant section of the Act.
**Web:** https://www.federalreservehistory.org/essays/federal-reserve-act

## Bretton Woods — international monetary institutions (`bretton-woods-1944`)
**Status:** Citation locked at stable source locator; edition/page to be added if a print quotation is used
**Citation:** Articles of Agreement of the International Monetary Fund and International Bank for Reconstruction and Development, Bretton Woods, 1944; cite the relevant Article/Section.
**Web:** https://www.imf.org/external/about/histend.htm

## 1971 — suspension of dollar convertibility into gold (`nixon-1971`)
**Status:** Citation locked at stable source locator; edition/page to be added if a print quotation is used
**Citation:** Richard Nixon, Address to the Nation Outlining a New Economic Policy, 15 August 1971; pair with subsequent official monetary records when describing legal/institutional effects.
**Web:** https://www.federalreservehistory.org/essays/bretton-woods-created


# Version 5.0 Passage Timeline Addendum

See `PASSAGE_TIMELINE.md` for the chronological passage register and explicit verification states.
