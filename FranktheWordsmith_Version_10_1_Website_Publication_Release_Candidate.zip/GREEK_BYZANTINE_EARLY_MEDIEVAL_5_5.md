# Version 5.5 — Greek → Byzantine → Early Medieval Europe

## Purpose
Fill the chronological bridge identified by the Version 5.4 audit without treating later witnesses as surviving texts of lost laws.

## New passage records

### c. 4th century BCE — Aristotle, Politics 1.10, 1258b
- **Status:** Primary passage verified — stable Greek/English text
- **Passage:** Politics 1258b
- **Evidence:** Aristotle distinguishes money-lending from other wealth-getting and argues that interest derives gain from money itself; he calls usury the form of wealth-getting most contrary to nature.
- **Historical role:** Greek economic thought, not statutory law.
- **Qualification:** This is philosophical analysis, not evidence that Athens enacted a general statutory prohibition on interest.
- **Web source:** https://www.perseus.tufts.edu/hopper/text?doc=Perseus%3Atext%3A1999.01.0058%3Abook%3D1%3Asection%3D1258b

### 6th century BCE reform tradition, preserved in later witness — Plutarch, Life of Solon 15
- **Status:** Secondary/witness evidence — later biography of an earlier lawgiver
- **Passage:** Solon 15.3–5
- **Evidence:** Plutarch reports that Solon's reforms remitted existing debts and prohibited lending secured by the borrower's person; he also records disagreement over the precise mechanism of the "disburdenment."
- **Historical role:** Important evidence for the later reception of Solon's debt reforms.
- **Qualification:** Plutarch is a later witness and this entry must not be presented as the surviving text of a Solonian statute.
- **Web source:** https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Plutarch/Lives/Solon%2A.html

### 692 CE — Quinisext Council in Trullo, Canon 10
- **Status:** Primary conciliar passage verified — stable translation/text
- **Passage:** Canon 10
- **Evidence:** A bishop, presbyter, or deacon who receives usury (hecatostoe) is ordered to desist or be deposed.
- **Historical role:** Byzantine ecclesiastical discipline concerning clerical usury.
- **Qualification:** This is an ecclesiastical rule for clergy, not a general Byzantine civil interest-rate statute.
- **Web source:** https://sourcebooks.web.fordham.edu/basis/trullo.asp

### 528 CE — Justinian, Codex 4.32.26.1–5
- **Status:** Primary legal passage verified — individual constitution
- **Passage:** C. 4.32.26.1–5
- **Evidence:** Justinian reduces and differentiates permissible interest ceilings by social/commercial category and prohibits evasive arrangements designed to exceed the statutory limits.
- **Historical role:** Byzantine civil-law regulation of interest.
- **Qualification:** The percentages belong to a specific imperial constitution and should not be projected backward onto all Roman periods.
- **Web source:** https://droitromain.univ-grenoble-alpes.fr/Corpus/CJ4.htm

### 529 CE — Justinian, Codex 4.32.27–28
- **Status:** Primary legal passage verified — individual constitutions
- **Passage:** C. 4.32.27.1–2; C. 4.32.28pr.
- **Evidence:** Interest is capped relative to principal in specified contexts, and interest-on-interest is expressly prohibited.
- **Historical role:** Demonstrates the Byzantine legal system's detailed regulation of accumulation and compounding.
- **Qualification:** These are imperial civil-law rules, distinct from ecclesiastical prohibitions.
- **Web source:** https://droitromain.univ-grenoble-alpes.fr/Corpus/CJ4.htm

### 789–806 CE — Carolingian anti-usury legislation
- **Status:** Research target / secondary witness pending critical-edition inspection
- **Passage target:** Aachen 789 and Nijmegen 806 capitularies concerning usury.
- **Evidence currently available:** Modern scholarship reports that Charlemagne's Aachen legislation extended the prohibition beyond clergy and that the Nijmegen legislation defined usury broadly as demanding more back than was given.
- **Historical role:** Potentially important transition from late antique/Byzantine clerical regulation toward broader Carolingian secular/ecclesiastical prohibition.
- **Qualification:** Do not quote the capitularies as primary passages until the critical capitulary edition is inspected. This entry therefore remains non-quotation status.

## Bridge conclusion
The Greek-to-Byzantine-to-Carolingian sequence now distinguishes three different evidence types: philosophical criticism of interest (Aristotle), later testimony about archaic debt reform (Plutarch), Byzantine civil-law regulation (Justinian), Byzantine ecclesiastical discipline (Trullo), and a still-pending Carolingian legislative transition. This prevents a false impression of a single uninterrupted legal rule across the entire period.
