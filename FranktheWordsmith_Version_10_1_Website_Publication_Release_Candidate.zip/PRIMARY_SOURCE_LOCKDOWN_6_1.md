# VERSION 6.1 — PRIMARY-SOURCE LOCKDOWN & FINAL AUDIT
**Audit date:** 2026-09-23
**Baseline:** Version 6.0 — Twentieth-Century Monetary Architecture

## Purpose
This release is a publication-control audit, not a new historical chapter. It tests whether each timeline item has an identifiable passage, a stable locator, an appropriate evidence class, and—where the project promises page-level precision—an edition-specific page lock.

## Evidence classes
- **GREEN:** primary passage/source has been directly verified in a stable online or documentary source. This does not automatically mean the locked print edition page has been checked.
- **YELLOW:** source or locator is identified, but the exact quotation, section, edition, or page still needs publication-level verification.
- **ORANGE:** reconstructed, composite, fragmentary, or otherwise materially qualified primary evidence. The underlying source is primary, but wording must not be presented as an intact witness.
- **BLUE:** secondary witness, later testimony, or research target; not suitable as a verbatim primary quotation without additional verification.

## Current audit counts
- GREEN — passage/source verified; check edition lock where applicable: **27** records
- YELLOW — locator locked; passage/edition verification still required: **3** records
- YELLOW — primary/source identified; publication lock pending: **30** records
- BLUE — secondary/witness or research-target evidence: **3** records

## Publication blockers
- Hammurabi §88 remains reconstructed; the secure surviving debt provisions should be quoted separately.
- The Twelve Tables are not directly extant; later witnesses such as Tacitus must remain explicitly identified as witnesses.
- Roman Digest/Codex entries need individual fragment/constitution locators when a quotation is used.
- Sahnun *al-Mudawwana*, al-Shafi'i *al-Umm*, and Ibn Qudama *al-Mughni* have stable structural locators but still lack locked-edition pagination.
- Carolingian usury legislation remains a research target until the critical capitulary edition is inspected.
- English 1571/1624 usury statutes and the 1694 Bank Act need exact statute-section/page locks before publication quotations.
- Banking Acts 1933/1935 require direct statutory section verification rather than reliance on historical summaries.
- The Jamaica/IMF 1976–78 material must distinguish the 1976 political agreement from the amended Articles entering into force in 1978.

## Verified institutional checkpoints
- The Federal Reserve Act of 1913 is available in official section-by-section form from the Federal Reserve and in the U.S. Statutes at Large/GovInfo. citeturn0search1turn0search0
- The Nixon August 15, 1971 address is preserved in the Nixon Library record and official presidential-document collections; the gold-convertibility suspension should be cited to the speech plus the contemporaneous executive record. citeturn0search3turn0search9
- The Bretton Woods chronology should treat the 1944 agreement, 1945 implementation, and later IMF amendments as separate documentary stages. citeturn0search5turn0search12

## Rule for final publication
No sentence in the finished 4,000-year narrative should call a passage “verified” unless the reader can be taken directly to the exact source locator. Where a print edition is promised, the edition and page must also be locked.
