# Version 9.0 — Claim-to-Passage Map

| Narrative proposition | Canonical source IDs | Evidence handling |
|---|---|---|
| Early Mesopotamian law recognizes regulated interest-bearing loans | `ur-nammu`; `eshnunna`; `hammurabi` | Ur-Nammu/Eshnunna remain composite; Hammurabi rate passage reconstructed |
| Biblical lending rules differentiate borrower/social category | `exodus-22-24`; `leviticus-25-35-37`; `deuteronomy-23-20-21` | Passage-level legal claims only |
| Greek philosophy critiques money-making through money | `aristotle-politics-1258b` | Passage verified; do not equate with banking prohibition |
| Roman law develops technical interest categories | `roman-twelve-tables`; `roman-digest-22-1`; `roman-codex-interest`; `justinian-codex-4-32-26`; `justinian-codex-4-32-27-28` | Twelve Tables are later-witness; Justinianic sources require individual fragment/constitution locators for quotations |
| Christian institutions and theologians condemn/discipline usury | `nicaea-canon-17`; `ambrose-de-tobia`; `augustine-usury` | Distinguish canon, theology, and economic practice |
| Qur'an and hadith provide the scriptural foundation for ribā rules | `quran-2-275-279`; `quran-3-130`; `hadith-muslim-1584e`; `hadith-muslim-1587c`; `hadith-muslim-1597` | Canonical verse/hadith locators; avoid adding unverified translation quotations |
| Medieval Islamic jurists systematize ribā doctrine | `hanafi-riba-sarakhsi`; `maliki-riba-mudawwana`; `shafii-riba-umm`; `hanbali-riba-mughni`; `ibn-rushd-bidayat-riba` | Hanafi page lock strongest; others bounded to passage-level evidence |
| Medieval Christian/Jewish law develops detailed usury rules | `aquinas-q78-a1`; `aquinas-q78-a2`; `maimonides-sefer-mitzvot-235-237`; `maimonides-mishneh-torah-ml-4`; `maimonides-mishneh-torah-ml-5`; `shulchan-arukh-yoreh-deah-160` | Print/critical-edition locks remain open for several records |
| Early-modern states regulate interest by statute | `henry-viii-usury-act-1545`; `elizabeth-usury-act-1571`; `james-usury-act-1624` | Primary statutes; page locks remain open where noted |
| Bank of England's 1694 foundation marks institutional change | `boe-charter-1694`; `bank-act-1694` | Charter and Act kept distinct; Act print lock open |
| Classical political economy reframes interest as an economic variable | `bentham-defence-usury-1787`; `adam-smith-wealth-nations-i9`; `ricardo-principles-ch-v`; `js-mill-principles-interest` | A-grade anchors plus page-locked Mill record from publication freeze |
| Nineteenth-century banking shifts attention toward liquidity/reserves | `thornton-paper-credit-1802`; `bagehot-lombard-street-1873`; `bank-charter-act-1844`; `bank-charter-amendment-1866`; `bank-act-1878` | Paraphrase for edition-pending treatises/statutes |
| Twentieth-century monetary governance expands beyond bilateral lending | `fed-act-1913`; `banking-act-1933`; `banking-act-1935`; `bretton-woods-1944`; `bretton-woods-act-1945`; `uk-bretton-woods-act-1945` | Distinguish international agreement from domestic implementation |
| 1971–1978 monetary transition is legally layered | `nixon-1971`; `jamaica-1976-imf` | Keep 1971 announcement, 1976 agreement, and 1978 legal effect distinct |
| Modern regulation addresses broader financial-system risks | `dodd-frank-2010` | Statutory/institutional claim, not an interest-rate history claim |
