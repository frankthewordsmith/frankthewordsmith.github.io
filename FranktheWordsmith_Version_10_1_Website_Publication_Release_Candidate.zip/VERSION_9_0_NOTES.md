# Version 9.0 — Direct Edition/Facsimile Verification

Date: 2026-09-23

## Purpose
This round attempts the final evidence step before A-grade promotion: direct verification of the edition/scan and exact page/location.

## Results
Five high-priority B-grade records were rechecked:

- Aquinas, *Summa theologiae* II-II q.78 a.1 — B retained.
- Aquinas, *Summa theologiae* II-II q.78 a.2 — B retained.
- Justinian, *Digest* 22.1 — B retained.
- Justinian, *Codex* 4.32.26 — B retained.
- Maimonides, *Sefer ha-Mitzvot* 235–237 — B retained.

The online witnesses permit passage-level verification for the Roman materials, but they do not by themselves establish the required print/critical-edition page lock. No source is promoted merely because a secondary work supplies a page reference.

## Evidence inventory
59 records: A=8, B=46, C=4, D=1.

## Standard
The project continues to require creator, title, edition/version, publisher/date where applicable, and a precise location sufficient for another researcher to recover the passage. The Library of Congress likewise emphasizes complete citation information and source location for reproducibility.
