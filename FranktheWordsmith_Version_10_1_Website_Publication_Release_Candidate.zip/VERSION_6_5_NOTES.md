# Version 6.5 Notes

## Purpose
Version 6.5 converts the Version 6.4 evidence table into a continuous chronological, passage-driven synthesis. It deliberately does not add a new broad research corpus.

## Method
- Major historical transitions are anchored to existing source records.
- Evidence grades are preserved.
- No unresolved page number is invented.
- Later witnesses and reconstructions remain labeled.
- Institutional monetary history is connected to the usury/interest story without claiming that all periods asked the same question.

## External contextual checks
- Federal Reserve History confirms the 1913 founding purpose and later monetary evolution.
- Federal Reserve History describes Bretton Woods as a 1944 creation of an international monetary system that became fully functional with convertibility in 1958 and ended in its original form after the 1971 suspension.
- AEA's retrospective identifies the late-eighteenth-century Smith–Bentham exchange as a major episode in the transition from usury debate to modern interest analysis.
- Bank of England research provides a long-run real-interest-rate reconstruction from the fourteenth century onward, used here only as secondary quantitative context.

## Next version
Version 6.6 should be the publication-editing pass: normalize footnotes, create a quotation index, expose evidence grades in the UI, and remove research-only scaffolding while preserving an audit trail.
