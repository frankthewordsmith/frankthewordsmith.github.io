# Version 8.4 — Primary-Edition Verification & Acquisition Round

Date: 2026-09-23

## Purpose
This round turns the Version 8.4 acquisition queue into a verification record for high-value B-grade sources. Online primary-text witnesses were checked, but no record was promoted solely because an online witness exists.

## Verified working witnesses
- Thomas Aquinas, *Summa Theologiae* II-II q.78: New Advent and CCEL provide the relevant online primary text.
- Maimonides, *Mishneh Torah*, Creditor and Debtor 5:2: Sefaria provides Hebrew plus translation.
- Bank of England Charter, 1694: Bank of England archive identifies original charter M6/48 and related printed transcript 10A287/4, pp.5–20.
- Bank of England Act, 1694: enacted statutory text and a point-in-time PDF reproduction are available as working witnesses.

## Integrity rule
A web witness verifies the passage; it does not by itself prove a particular critical/print edition page. The archive therefore preserves the B grade until the required edition-specific lock is obtained.

## Evidence inventory
A=8, B=46, C=4, D=1.
