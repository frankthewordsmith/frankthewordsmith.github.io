# A-Grade Conversion Ledger — 7.2

| Source | Prior | Result | Basis |
|---|---:|---:|---|
| Bretton Woods Final Act / IMF & IBRD Articles | B | **A** | 1944 primary Final Act; government-print edition identified; Annex A begins p. 19 in an independent government parliamentary reproduction; institutional archive confirms provenance. |
| Aquinas II-II q.78 | B | B | Stable article locator, but no locked critical-edition page. |
| Maimonides | B | B | Stable chapter/section locators, print pagination still edition-dependent. |
| 1545/1571/1624 statutes | B | B | Statutory identities secure; scanned authoritative edition/page lock incomplete. |
| Bank Act 1694 | B | B | Act/Charter distinction secure; edition/page quotation lock incomplete. |
| Bentham/Smith/Ricardo | B | B | Primary works identified; exact publication-page locks incomplete for the selected passages. |
