import json, os, zipfile, datetime
from pathlib import Path
root=Path('/mnt/data/v63work')
p=root/'research-data.json'
d=json.loads(p.read_text())
d['version']='6.3'

byid={s['source_id']:s for s in d['sources']}

def upd(i, **kw):
    byid[i].update(kw)

# Roman Digest: isolate a directly locatable fragment rather than leaving the whole title generic.
upd('roman-digest-22-1',
    verification_status='Passage verified — individual fragment locator locked; print-page lock pending',
    source_url='https://www.thelatinlibrary.com/justinian/digest22.shtml',
    web_sources=['https://www.thelatinlibrary.com/justinian/digest22.shtml'],
    reference_number='Digest 22.1.17 (Paulus, liber singularis de usuris); compare 22.1.9pr–1',
    passage_record={
        'status':'Individual fragment verified online',
        'locator':'D.22.1.17pr–8 (Paulus, l.S. de usur.); additional control passage D.22.1.9pr–1',
        'evidence':'The online Latin text identifies the individual fragments and preserves the usury/default rules; D.22.1.9pr rejects a stipulation exceeding lawful interest and D.22.1.17pr directs an excessive stipulation to be reduced to a just measure.',
        'significance':'Moves the record from a title-level citation to fragment-level primary-text control.',
        'source_url':'https://www.thelatinlibrary.com/justinian/digest22.shtml',
        'checked':'2026-09-23',
        'verification_note':'Online text is stable for locator verification. No print-edition page is asserted.'
    })

upd('roman-codex-interest',
    verification_status='Passage verified — individual constitutions 4.32.26–28 locked; print-page lock pending',
    source_url='https://droitromain.univ-grenoble-alpes.fr/Corpus/CJ4.htm',
    web_sources=['https://droitromain.univ-grenoble-alpes.fr/Corpus/CJ4.htm'],
    reference_number='Codex 4.32.26.1–5; 4.32.27pr–2; 4.32.28pr',
    passage_record={
        'status':'Individual constitutions verified online',
        'locator':'CJ 4.32.26.1–5; CJ 4.32.27pr–2; CJ 4.32.28pr',
        'evidence':'The online Krueger text identifies the separate constitutions and preserves Justinian’s rate ceilings, the duplum limit, and the prohibition on interest on interest.',
        'significance':'Separates three distinct enacted constitutions rather than treating Codex 4.32 as one undifferentiated passage.',
        'source_url':'https://droitromain.univ-grenoble-alpes.fr/Corpus/CJ4.htm',
        'checked':'2026-09-23',
        'verification_note':'No print-edition page is asserted.'
    })

upd('james-usury-act-1624',
    verification_status='Primary statute identified and rate provision independently verified; statute-book page lock pending',
    source_url='https://constitution.org/1-Constitution/tb/tb5.htm',
    web_sources=['https://constitution.org/1-Constitution/tb/tb5.htm','https://www.legislation.gov.uk/ukpga/Vict/17-18/90/pdfs/ukpga_18540090_en.pdf'],
    passage_record={
        'status':'Statute locator and substantive rate change independently verified',
        'locator':'21 Jac. I c. 17 (1623/24), Usury Act; repeal schedule confirmed in 17 & 18 Vict. c.90',
        'evidence':'A legal-history transcription identifies 21 Jac. I c.17 as reducing the English statutory interest ceiling to eight per cent; the 1854 repeal schedule confirms the Act as one of the usury laws being repealed.',
        'significance':'Locks the statute’s identity and historical function while reserving page-level verification for an early statute-book scan.',
        'source_url':'https://constitution.org/1-Constitution/tb/tb5.htm',
        'checked':'2026-09-23',
        'verification_note':'The exact 1624 printed statute-book page has not been asserted.'
    })

upd('elizabeth-usury-act-1571',
    verification_status='Primary statute identified and substantive ceiling provision independently verified; statute-book page lock pending',
    source_url='https://onlinebooks.library.upenn.edu/webbin/book/lookupname?key=England+and+Wales.+Sovereign+%281558-1603+%3A+Elizabeth+I%29',
    web_sources=['https://onlinebooks.library.upenn.edu/webbin/book/lookupname?key=England+and+Wales.+Sovereign+%281558-1603+%3A+Elizabeth+I%29','https://www.legislation.gov.uk/ukpga/Vict/17-18/90/pdfs/ukpga_18540090_en.pdf'],
    passage_record={
        'status':'Statute identified; early printed witness located in EEBO catalogue; substantive ceiling independently corroborated',
        'locator':'13 Eliz. I c. 8 (1571), An Acte against Usurie',
        'evidence':'The EEBO/Online Books record identifies the early printed work “By the Queene…an Acte against usurie”; an independent legal-history account records the ten-per-cent ceiling, while the 1854 repeal schedule confirms the statute citation.',
        'significance':'Adds a direct early-printed-witness trail without pretending that a modern transcription is the same thing as a page-locked original witness.',
        'source_url':'https://onlinebooks.library.upenn.edu/webbin/book/lookupname?key=England+and+Wales.+Sovereign+%281558-1603+%3A+Elizabeth+I%29',
        'checked':'2026-09-23',
        'verification_note':'Printed folio/page still pending.'
    })

upd('bank-act-1694',
    verification_status='Primary statute passage verified — official Bank of England transcription; archival page reference available',
    source_url='https://www.bankofengland.co.uk/-/media/boe/files/about/legislation/boe-charter',
    web_sources=['https://www.bankofengland.co.uk/-/media/boe/files/about/legislation/boe-charter','https://www.bankofengland.co.uk/CalmView/Record.aspx?id=M6%2F48&src=CalmView.Catalog'],
    reference_number='5 & 6 Will. & Mar. c. 20, §§ 19 and 26 (Bank of England Act 1694)',
    passage_record={
        'status':'Primary statutory text verified from official institutional transcription',
        'locator':'5 & 6 Will. & Mar. c.20, especially §19 (incorporation power) and §26 (corporation not to trade)',
        'evidence':'The Bank of England’s official transcription identifies the Act and reproduces the provisions authorizing incorporation of subscribers and restricting the corporation from trading in goods.',
        'significance':'Separates the 1694 Act of Parliament from the 27 July 1694 Royal Charter and supplies an official text for quotation.',
        'source_url':'https://www.bankofengland.co.uk/-/media/boe/files/about/legislation/boe-charter',
        'checked':'2026-09-23',
        'verification_note':'The Bank archive catalog identifies the original Charter and a printed transcript of Charter and statutes at archive reference 10A287/4, pp. 5–20; this record does not claim those pages are pages of the Act itself.'
    })

upd('banking-act-1933',
    verification_status='Enacted statutory text verified online — §8 / §12A passage locked; official print-page lock pending',
    source_url='https://fraser.stlouisfed.org/title/banking-act-1933-glass-steagall-act-991/fulltext',
    web_sources=['https://fraser.stlouisfed.org/title/banking-act-1933-glass-steagall-act-991/fulltext'],
    reference_number='Banking Act of 1933, §8 inserting Federal Reserve Act §12A',
    passage_record={
        'status':'Enacted text verified online',
        'locator':'Banking Act of 1933, §8; inserted Federal Reserve Act §12A(a)',
        'evidence':'The full-text reproduction of the enacted Act contains §8 and the language creating a Federal Open Market Committee under the amended Federal Reserve Act.',
        'significance':'The record can now cite the enacted section itself rather than relying only on a Federal Reserve historical summary.',
        'source_url':'https://fraser.stlouisfed.org/title/banking-act-1933-glass-steagall-act-991/fulltext',
        'checked':'2026-09-23',
        'verification_note':'FRASER labels the page as automatically extracted from the original document; final print-page citation remains a separate task.'
    })

upd('banking-act-1935',
    verification_status='Enacted statutory text verified online — §205 / revised §12A passage locked; official print-page lock pending',
    source_url='https://fraser.stlouisfed.org/title/banking-act-1935-983/fulltext',
    web_sources=['https://fraser.stlouisfed.org/title/banking-act-1935-983/fulltext'],
    reference_number='Banking Act of 1935, §205 amending Federal Reserve Act §12A, effective March 1, 1936',
    passage_record={
        'status':'Enacted text verified online',
        'locator':'Banking Act of 1935, §205; revised Federal Reserve Act §12A',
        'evidence':'The enacted text states that §12A was amended effective March 1, 1936 and specifies the Federal Open Market Committee’s composition, including the Board of Governors and five Federal Reserve bank representatives.',
        'significance':'Locks the statutory mechanism for the modern FOMC structure in the enacted text.',
        'source_url':'https://fraser.stlouisfed.org/title/banking-act-1935-983/fulltext',
        'checked':'2026-09-23',
        'verification_note':'FRASER notes that the web text is automatically extracted; final print-page citation remains pending.'
    })

upd('carolingian-usury-aachen-nijmegen',
    verification_status='Nijmegen 806 primary passage verified at manuscript and MGH locators; Aachen 789 retained as contextual/legislative background pending an isolated usury passage',
    source_url='https://capitularia.uni-koeln.de/mss/laon-bm-201/',
    web_sources=['https://capitularia.uni-koeln.de/mss/laon-bm-201/','https://capitularia.uni-koeln.de/en/mss/vatikan-bav-reg-lat-1728/','https://capitularia.uni-koeln.de/en/capit/pre814/bk-nr-022/'],
    reference_number='Nijmegen 806, MGH Capit. 1, no. 46, cc. 11–17, MGH pp. 132–133; manuscript witness Laon BM 201, fols. 103r–104r',
    passage_record={
        'status':'Individual primary passage verified for Nijmegen 806',
        'locator':'Capitulare missorum Niumagae datum (a. 806), cc. 11–17; MGH Capit. 1, Nr. 46, S. 132 Z. 9–27; Laon BM 201, fols. 103r–104r',
        'evidence':'Capitularia records the manuscript witness and gives the incipit “Usura est ubi amplius requiretur” for cc. 11–17. It also identifies the MGH edition and page/line range.',
        'significance':'Provides a direct critical-edition/manuscript trail for the Carolingian definition of usury. The 789 Aachen item is not treated as if its usury wording had been separately isolated here.',
        'source_url':'https://capitularia.uni-koeln.de/mss/laon-bm-201/',
        'checked':'2026-09-23',
        'verification_note':'For Aachen 789, Capitularia confirms the text, dating, transmission, and critical edition; the present sprint does not assert a specific usury chapter there.'
    })

upd('shulchan-arukh-yoreh-deah-160',
    verification_status='Primary passage directly verified online — Yoreh De‘ah 161:1–11; edition-page lock pending',
    source_url='https://www.sefaria.org/Shulchan_Arukh%2C_Yoreh_De%27ah.161',
    web_sources=['https://www.sefaria.org/Shulchan_Arukh%2C_Yoreh_De%27ah.161','https://www.sefaria.org/Shulchan_Arukh%2C_Yoreh_De%27ah.161.2'],
    reference_number='Shulchan Arukh, Yoreh De‘ah 161:1–11 (especially 161:1–5)',
    passage_record={
        'status':'Primary passage verified online',
        'locator':'Yoreh De‘ah 161:1–11; especially §161:1 and §161:5',
        'evidence':'Sefaria’s text gives the Hebrew and translation of the chapter on avak ribbit and biblical interest, including the prohibition on borrowing with an increase and the legal treatment of stipulated interest.',
        'significance':'Corrects the earlier broader chapter-160 targeting by adding a directly relevant, passage-level locator.',
        'source_url':'https://www.sefaria.org/Shulchan_Arukh%2C_Yoreh_De%27ah.161',
        'checked':'2026-09-23',
        'verification_note':'No edition-specific print page is asserted.'
    })

# Keep chronology/labels conservative.
for i in ['maimonides-mishneh-torah-ml-4','maimonides-mishneh-torah-ml-5','maimonides-sefer-mitzvot-235-237']:
    byid[i]['notes'] = (byid[i].get('notes','') + ' 6.3: stable online locator retained; no print-page invented.').strip()

d['sources']=list(byid.values())
d['audit_6_3']={
 'version':'6.3', 'date':'2026-09-23',
 'purpose':'Publication-lock sprint: convert broad research targets into individual passage, statute, manuscript, and enacted-section locators where stable evidence permits, while explicitly preserving remaining edition/page uncertainty.',
 'web_verified':[
  {'id':'roman-digest-22-1','basis':'Digest 22.1 individual fragments, especially 22.1.9 and 22.1.17'},
  {'id':'roman-codex-interest','basis':'Codex 4.32.26–28 individual constitutions'},
  {'id':'elizabeth-usury-act-1571','basis':'EEBO/Online Books early-print witness plus repeal schedule and legal-history corroboration'},
  {'id':'james-usury-act-1624','basis':'Legal-history transcription plus 1854 repeal schedule'},
  {'id':'bank-act-1694','basis':'Official Bank of England statutory transcription and archive catalog'},
  {'id':'banking-act-1933','basis':'FRASER full enacted text, §8 / §12A'},
  {'id':'banking-act-1935','basis':'FRASER full enacted text, §205 / revised §12A'},
  {'id':'carolingian-usury-aachen-nijmegen','basis':'Capitularia manuscript witness and MGH locators for Nijmegen 806'},
  {'id':'shulchan-arukh-yoreh-deah-160','basis':'Sefaria primary text, Yoreh De‘ah 161:1–11'}
 ],
 'remaining_blockers':[
  'Locked-print pagination for Maimonides, al-Mudawwana, al-Umm, al-Mughni, Shulchan Arukh, Calvin, and selected classical economists.',
  'A page-locked early printed witness for 13 Eliz. I c.8 and 21 Jac. I c.17; current records distinguish identification/corroboration from page lock.',
  'Print/statute-book page lock for the 1694 Act; official institutional transcription is now available.',
  'Print-page lock for Banking Acts 1933 and 1935; enacted sections are now directly verified online.',
  'Aachen 789 usury passage still requires an isolated chapter/section citation before it is quoted as a standalone primary passage.',
  'A print-edition page citation for the Roman Digest/Codex fragments if the final narrative quotes from a locked print edition.'
 ],
 'method_note':'No quotation, original-language reading, or page number has been promoted beyond what the cited online or archival locator actually supports.'
}

# Add project notes.
notes='''# Version 6.3 — Publication-Lock Sprint\n\nDate: 2026-09-23\n\n## Purpose\nThis pass narrows the archive from broad source identification to individually controlled passage/statute/manuscript locators. It does not treat online text verification as equivalent to locked-print pagination.\n\n## Major locks added\n- Roman Digest: individual fragments D.22.1.9pr–1 and D.22.1.17, with title-level record retained.\n- Justinian Codex: CJ 4.32.26–28 separated into individual constitutions.\n- English usury statutes: 13 Eliz. I c.8 and 21 Jac. I c.17 now have independent early-print/statutory corroboration, but page lock remains open.\n- Bank of England Act 1694: official Bank of England transcription and archive metadata now support direct quotation/locator work.\n- Banking Act 1933: enacted §8 / inserted §12A directly verified in FRASER.\n- Banking Act 1935: enacted §205 / revised §12A directly verified in FRASER.\n- Carolingian usury: Nijmegen 806, cc.11–17 now has a manuscript witness plus MGH edition/page-line locator; Aachen 789 is deliberately kept contextual until its usury passage is isolated.\n- Shulchan Arukh: Yoreh De‘ah 161:1–11 directly verified online; this is more precise than the prior broad chapter-160 target.\n\n## Editorial guardrail\nThe archive continues to distinguish: surviving primary text; manuscript witness; critical/standard edition; stable online transcription; later witness; secondary analysis; and reconstruction. A page number is never inferred from a web transcription.\n'''
(root/'VERSION_6_3_NOTES.md').write_text(notes)

sprint='''# PRIMARY SOURCE SPRINT 6.3\n\n## Locked or materially improved\n\n### Roman law\n- **Digest 22.1** — use D.22.1.9pr–1 and D.22.1.17 as individually locatable control passages.\n- **Codex 4.32** — use CJ 4.32.26.1–5, 4.32.27pr–2, and 4.32.28pr as separate constitutions.\n\n### Early-modern England\n- **13 Eliz. I c.8** — early printed witness identified through the University of Pennsylvania/Online Books EEBO trail; substantive ceiling corroborated; page lock still open.\n- **21 Jac. I c.17** — statute identity and 8% ceiling corroborated; page lock still open.\n- **1694 Bank Act** — official Bank of England transcription now supplies the Act’s text and correct citation 5 & 6 Will. & Mar. c.20.\n\n### Twentieth-century monetary architecture\n- **Banking Act 1933 §8** — enacted text directly checked; inserted Federal Reserve Act §12A creates the FOMC.\n- **Banking Act 1935 §205** — enacted text directly checked; revised §12A effective March 1, 1936 sets the modern FOMC composition.\n\n### Carolingian legislation\n- **Nijmegen 806** — Capitularia gives manuscript witness Laon BM 201, fols. 103r–104r and MGH Capit. 1, Nr. 46, S.132 Z.9–27 for cc.11–17.\n- **Aachen 789** — keep as a legislative-background record until the specific usury passage is isolated.\n\n### Jewish legal tradition\n- **Shulchan Arukh YD 161** — direct Sefaria passage verification for §§1–11, especially §§1 and 5.\n\n## Still open\nPrint pagination and/or critical-edition page locks remain for several medieval/early-modern works. Those are not treated as failures of passage verification; they are publication-level edition locks.\n'''
(root/'PRIMARY_SOURCE_SPRINT_6_3.md').write_text(sprint)

# Update site version strings and append concise sprint note.
for fn in ['index.html','timeline.html','research.html','references.html','source.html','about.html']:
    fp=root/fn
    if fp.exists():
        t=fp.read_text()
        t=t.replace('Version 6.2','Version 6.3').replace('v6.2','v6.3').replace('6.2 Targeted Primary-Source Verification','6.3 Publication-Lock Sprint')
        fp.write_text(t)

# Add a short visible update if matching marker exists.
for fn in ['timeline.html','research.html']:
    fp=root/fn
    if fp.exists():
        t=fp.read_text()
        marker='<!-- VERSION_6_3_SPRINT -->'
        if marker not in t:
            t=t.replace('</main>', '<section class="card"><h2>6.3 Publication-Lock Sprint</h2><p>Roman law fragments, the 1694 Bank Act, Banking Acts 1933/1935, Nijmegen 806, and Shulchan Arukh YD 161 now have tighter passage-level locators. Early-modern English statute records distinguish statutory corroboration from still-pending page locks.</p></section>'+marker+'</main>',1)
            fp.write_text(t)

# package
zip_path='/mnt/data/FranktheWordsmith_Version_6_3_Publication_Lock_Sprint.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for f in root.rglob('*'):
        if f.is_file() and f.name != Path(zip_path).name:
            z.write(f, f.relative_to(root))
print(zip_path)
print('sources',len(d['sources']))
print('version',d['version'])
