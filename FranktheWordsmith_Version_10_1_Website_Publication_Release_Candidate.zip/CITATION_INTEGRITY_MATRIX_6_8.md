# Citation Integrity Matrix — Version 6.8

| ID | Grade | Locator | Edition/page/section lock signal | Gaps |
|---|---|---|---|---|
| ur-nammu | C | yes | yes | — |
| eshnunna | C | yes | yes | edition/page-or-section-lock |
| hammurabi | C | yes | yes | provenance-caution |
| exodus-22-24 | B | yes | yes | edition/page-or-section-lock |
| leviticus-25-35-37 | B | yes | yes | edition/page-or-section-lock |
| deuteronomy-23-20-21 | B | yes | yes | edition/page-or-section-lock |
| mishnah-bm-5 | B | yes | yes | edition/page-or-section-lock |
| talmud-bm | B | yes | yes | edition/page-or-section-lock |
| roman-twelve-tables | B | yes | yes | — |
| roman-digest-22-1 | B | yes | yes | — |
| roman-codex-interest | B | yes | yes | — |
| nicaea-canon-17 | B | yes | yes | edition/page-or-section-lock |
| ambrose-de-tobia | A | yes | yes | edition/page-or-section-lock |
| augustine-usury | B | yes | yes | edition/page-or-section-lock |
| quran-2-275-279 | B | yes | yes | edition/page-or-section-lock |
| quran-3-130 | B | yes | yes | edition/page-or-section-lock |
| hadith-muslim-1587c | B | yes | yes | edition/page-or-section-lock |
| hadith-muslim-1597 | B | yes | yes | edition/page-or-section-lock |
| hanafi-riba-sarakhsi | A | yes | yes | edition/page-or-section-lock |
| maliki-riba-mudawwana | B | yes | yes | edition/page-or-section-lock, pending-verification |
| shafii-riba-umm | B | yes | yes | edition/page-or-section-lock, pending-verification |
| hanbali-riba-mughni | B | yes | yes | edition/page-or-section-lock, pending-verification |
| aquinas-q78-a1 | B | yes | yes | edition/page-or-section-lock |
| aquinas-q78-a2 | B | yes | yes | — |
| boe-1694 | B | yes | yes | edition/page-or-section-lock |
| hadith-muslim-1584e | B | yes | yes | edition/page-or-section-lock |
| ibn-rushd-bidayat-riba | B | yes | yes | edition/page-or-section-lock, pending-verification |
| aristotle-politics-1258b | B | yes | yes | edition/page-or-section-lock |
| plutarch-solon-15 | C | yes | yes | edition/page-or-section-lock, provenance-caution |
| justinian-codex-4-32-26 | B | yes | yes | edition/page-or-section-lock |
| justinian-codex-4-32-27-28 | B | yes | yes | edition/page-or-section-lock |
| trullo-canon-10 | B | yes | yes | edition/page-or-section-lock |
| carolingian-usury-aachen-nijmegen | D | yes | yes | edition/page-or-section-lock, pending-verification |
| maimonides-sefer-mitzvot-235-237 | B | yes | yes | pending-verification |
| maimonides-mishneh-torah-ml-4 | B | yes | yes | pending-verification |
| maimonides-mishneh-torah-ml-5 | B | yes | yes | pending-verification |
| shulchan-arukh-yoreh-deah-160 | B | yes | yes | pending-verification |
| calvin-de-usuris-1545 | B | yes | yes | edition/page-or-section-lock, pending-verification |
| henry-viii-usury-act-1545 | B | yes | yes | pending-verification |
| elizabeth-usury-act-1571 | B | yes | yes | pending-verification |
| james-usury-act-1624 | B | yes | yes | pending-verification |
| boe-charter-1694 | B | yes | yes | edition/page-or-section-lock |
| bank-act-1694 | B | yes | yes | pending-verification |
| bentham-defence-usury-1787 | B | yes | yes | pending-verification |
| adam-smith-wealth-nations-i9 | B | yes | yes | pending-verification |
| bentham-defence-usury-i | B | yes | yes | pending-verification |
| ricardo-principles-ch-v | B | yes | yes | pending-verification |
| bank-charter-act-1844 | B | yes | yes | — |
| usury-laws-repeal-1854 | B | yes | yes | edition/page-or-section-lock |
| js-mill-principles-interest | B | yes | yes | pending-verification |
| fed-act-1913 | B | yes | yes | — |
| banking-act-1933 | B | yes | yes | pending-verification |
| banking-act-1935 | B | yes | yes | pending-verification |
| bretton-woods-1944 | B | yes | yes | edition/page-or-section-lock |
| bretton-woods-act-1945 | B | yes | yes | pending-verification |
| nixon-1971 | B | yes | yes | edition/page-or-section-lock |
| jamaica-1976-imf | B | yes | yes | edition/page-or-section-lock |
| dodd-frank-2010 | B | yes | yes | edition/page-or-section-lock |
