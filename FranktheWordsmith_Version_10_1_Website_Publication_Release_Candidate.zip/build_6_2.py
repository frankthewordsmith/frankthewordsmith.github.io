import json, os, re, zipfile, shutil
from datetime import date

ROOT='.'
with open('research-data.json',encoding='utf-8') as f: d=json.load(f)
sources=d['sources']
by={s['source_id']:s for s in sources}

# Targeted corrections / locks established in the 6.2 sprint.
updates={
 'maimonides-mishneh-torah-ml-4': {
   'date_start':'1170','date_end':'1180','date_label':'12th century CE; Mishneh Torah composed c. 1170–1180',
   'verification_status':'Passage verified — stable online locator; print-edition page pending',
   'last_verified':'2026-09-23',
   'notes':'Corrected chronology: Maimonides is a 12th-century CE author, not BCE. Sefaria directly exposes Creditor and Debtor 4:1–10; print pagination remains edition-dependent.',
   'source_url':'https://www.sefaria.org/Mishneh_Torah%2C_Creditor_and_Debtor.4.5'
 },
 'maimonides-mishneh-torah-ml-5': {
   'date_start':'1170','date_end':'1180','date_label':'12th century CE; Mishneh Torah composed c. 1170–1180',
   'verification_status':'Passage verified — stable online locator; print-edition page pending',
   'last_verified':'2026-09-23',
   'notes':'Corrected chronology. Sefaria directly exposes Creditor and Debtor 5:2 and related provisions; print pagination remains edition-dependent.'
 },
 'maimonides-sefer-mitzvot-235-237': {
   'date_start':'1170','date_end':'1190','date_label':'12th century CE; Sefer ha-Mitzvot',
   'verification_status':'Passage verified — stable online locator; print-edition page pending',
   'last_verified':'2026-09-23',
   'notes':'Corrected chronology: Maimonides is 12th-century CE. The online text is a stable primary-source locator; publication page lock remains pending.'
 },
 'calvin-de-usuris-1545': {
   'date_start':'1545','date_end':'1546','date_label':'1545/46 CE',
   'source_url':'https://www.leo-bw.de/web/guest/detail/-/Detail/details/DOKUMENT/bsz_swb/1507541090/Anlageberatung+mit+Johan+Calvin+sein+de+usuris+responsum+von+1545-46+zwischen+Patristik+und+%C3%96konomik',
   'verification_status':'Passage verified — stable secondary reproduction of primary text; critical/early edition lock pending',
   'last_verified':'2026-09-23',
   'notes':'Corrected the erroneous URL inherited from the previous build. The archive should not cite a Bentham URL as Calvin evidence. A 2015 scholarly record identifies the 1545/46 De Usuris Responsum and its bibliographic context.'
 },
 'henry-viii-usury-act-1545': {
   'verification_status':'Primary statute verified — stable transcription; statute-book page lock pending',
   'last_verified':'2026-09-23',
   'notes':'The 1545 text is directly available in a stable transcription. For publication, use the statutory citation 37 Hen. VIII c. 9 and lock the quotation against an authoritative statute-book scan. Contemporary/modern legal sources confirm the statute number and chronology.'
 },
 'elizabeth-usury-act-1571': {
   'verification_status':'Primary statute verified — stable secondary transcription; statute-book page lock pending',
   'last_verified':'2026-09-23',
   'notes':'The 13 Eliz. c. 8 identification is independently confirmed by legal-historical sources and the 1854 repeal schedule. Exact quotation should still be locked to a scanned statute-book edition.'
 },
 'james-usury-act-1624': {
   'verification_status':'Primary statute verified — stable secondary transcription; statute-book page lock pending',
   'last_verified':'2026-09-23',
   'notes':'The 21 Jac. I c. 17 identification and 8% statutory ceiling are independently confirmed by legal-historical sources. Exact quotation should still be locked to a scanned statute-book edition.'
 },
 'bank-act-1694': {
   'reference_number':'5 & 6 Will. & Mar. c. 20',
   'verification_status':'Primary statute identified and citation corrected; exact passage/page lock pending',
   'last_verified':'2026-09-23',
   'notes':'Corrected statutory citation to 5 & 6 Will. & Mar. c. 20. The Act is distinct from the 27 July 1694 Royal Charter.'
 },
 'banking-act-1933': {
   'verification_status':'Primary statute identified; section-level passage verified through official historical record; print/statute page lock pending',
   'last_verified':'2026-09-23',
   'notes':'Federal Reserve History confirms the 1933 Act created the FOMC and Regulation Q; the 1935 Act then created the modern FOMC structure. Final publication quotations should use the statutory text rather than the historical summary.'
 },
 'banking-act-1935': {
   'verification_status':'Primary statute identified; section-level passage verified through official historical record; print/statute page lock pending',
   'last_verified':'2026-09-23',
   'notes':'Federal Reserve History confirms that the Banking Act of 1935 created the modern FOMC structure and transferred key monetary-policy powers. Final publication quotations should use the statutory text, especially amended Federal Reserve Act §12A.'
 },
 'jamaica-1976-imf': {
   'verification_status':'Primary institutional record verified — 1976 agreement distinguished from 1978 legal entry into force',
   'last_verified':'2026-09-23',
   'notes':'IMF records establish that the Proposed Second Amendment was approved April 30, 1976 and entered into force April 1, 1978. The timeline now treats those as separate documentary events.'
 },
 'exodus-22-24': {
   'reference_number':'Exodus 22:25 in common modern verse numbering',
   'source_url':'https://www.sefaria.org/Exodus.22.25',
   'verification_status':'Primary passage verified — verse locator corrected',
   'last_verified':'2026-09-23',
   'notes':'Corrected the locator mismatch: the lending-to-the-poor prohibition is Exodus 22:25 in common modern numbering. Older numbering systems may differ.'
 },
}
for sid, vals in updates.items():
    if sid in by:
        by[sid].update(vals)

# Add a compact verification manifest for the sprint.
manifest={
 'version':'6.2',
 'date':'2026-09-23',
 'purpose':'Targeted verification sprint against the highest-impact unresolved or error-prone records from Version 6.1.',
 'web_verified':[
  {'id':'maimonides-mishneh-torah-ml-4','basis':'Sefaria primary text, Creditor and Debtor 4:1–10'},
  {'id':'maimonides-mishneh-torah-ml-5','basis':'Sefaria primary text, Creditor and Debtor 5:2 and related provisions'},
  {'id':'calvin-de-usuris-1545','basis':'Scholarly bibliographic record plus stable reproductions of De Usuris Responsum'},
  {'id':'henry-viii-usury-act-1545','basis':'Stable statute transcription; independent legal-history confirmation'},
  {'id':'elizabeth-usury-act-1571','basis':'Statute identification independently confirmed; 1854 repeal schedule'},
  {'id':'james-usury-act-1624','basis':'Statute identification and rate history independently confirmed'},
  {'id':'bank-act-1694','basis':'Corrected statutory citation: 5 & 6 Will. & Mar. c.20'},
  {'id':'banking-act-1933','basis':'Federal Reserve History; statutory section targets identified'},
  {'id':'banking-act-1935','basis':'Federal Reserve History; amended Federal Reserve Act §12A identified'},
  {'id':'jamaica-1976-imf','basis':'IMF primary treaty record and official chronology'},
  {'id':'exodus-22-24','basis':'Sefaria primary text; verse-number correction'}
 ],
 'remaining_blockers':[
  'Locked-print page verification for Maimonides, al-Mudawwana, al-Umm, al-Mughni, Shulchan Arukh, Calvin and the classical economists.',
  'Critical-edition verification for Carolingian anti-usury legislation.',
  'Individual fragment-level locators for Digest 22.1 and any quoted Codex 4.32 provisions.',
  'Authoritative statute-book scans for exact quotations from 1571 and 1624 usury Acts and the 1694 Bank Act.',
  'A direct statutory scan for Banking Acts 1933 and 1935 if the final narrative quotes the enacted language verbatim.'
 ]
}

d['version']='6.2'
d['architecture']['status']='Passage-driven 4,000-year research archive with targeted primary-source verification sprint completed.'
d['audit_6_2']=manifest
with open('research-data.json','w',encoding='utf-8') as f: json.dump(d,f,ensure_ascii=False,indent=2)

open('VERSION_6_2_NOTES.md','w',encoding='utf-8').write('''# VERSION 6.2 — TARGETED PRIMARY-SOURCE VERIFICATION SPRINT\n\n**Date:** 2026-09-23\n**Baseline:** Version 6.1\n\n## Purpose\nThis release resolves high-impact locator and chronology problems identified in the 6.1 lockdown and upgrades several yellow records where stable primary or institutional evidence is now available. It does **not** pretend that online verification equals locked-print pagination.\n\n## Corrections and upgrades\n\n1. **Maimonides chronology corrected.** The prior build incorrectly represented the 12th-century author with BCE-style negative dates. The Mishneh Torah records now use c. 1170–1180 CE.\n2. **Maimonides primary locators strengthened.** Sefaria exposes *Creditor and Debtor* 4 and 5 directly; print-edition pagination remains pending.\n3. **Calvin URL corrected.** The previous record incorrectly pointed to a Bentham page. The record now points to a scholarly bibliographic record for *De Usuris Responsum* and explicitly distinguishes reproduction from critical-edition verification.\n4. **Exodus locator corrected.** The lending-to-the-poor passage is Exodus 22:25 in common modern numbering; the previous archive record contained a mismatch.\n5. **English usury statutes strengthened.** 37 Hen. VIII c. 9, 13 Eliz. c. 8 and 21 Jac. I c. 17 are retained as primary statutory records, with the requirement that final quotations be checked against statute-book scans. The 1854 repeal Act itself lists the earlier statutes in its schedule.\n6. **Bank of England Act 1694 citation corrected** to 5 & 6 Will. & Mar. c. 20; it remains distinct from the Royal Charter of 27 July 1694.\n7. **Banking Acts 1933/1935 upgraded.** Federal Reserve History confirms the 1933 FOMC creation and the 1935 modern FOMC structure; exact statutory quotations remain a final publication lock.\n8. **IMF Jamaica/Second Amendment distinction strengthened.** The Proposed Second Amendment was approved on April 30, 1976 and entered into force on April 1, 1978.\n\n## Editorial rule retained\nA source can be **passage-verified online** while still being **page-pending in the locked print edition**. Those states must not be collapsed.\n''')

open('PRIMARY_SOURCE_SPRINT_6_2.md','w',encoding='utf-8').write('''# PRIMARY-SOURCE SPRINT 6.2\n\n| Source | Action | Result | Final publication lock? |\n|---|---|---|---|\n| Maimonides, Mishneh Torah 4 | chronology + primary locator | corrected to 12th c. CE; stable text verified | page pending |\n| Maimonides, Mishneh Torah 5 | chronology + primary locator | corrected to 12th c. CE; stable text verified | page pending |\n| Calvin, De Usuris Responsum | source URL and provenance | erroneous Bentham URL removed; Calvin bibliographic record restored | critical edition pending |\n| Exodus 22 | verse locator | corrected to 22:25 modern numbering | yes for verse locator |\n| 37 Hen. VIII c. 9 | statutory identification | stable text and citation confirmed | statute-book page pending |\n| 13 Eliz. c. 8 | statutory identification | citation independently confirmed | statute-book page pending |\n| 21 Jac. I c. 17 | statutory identification | citation/rate history independently confirmed | statute-book page pending |\n| Bank of England Act 1694 | citation | corrected to 5 & 6 Will. & Mar. c. 20 | statute scan pending |\n| Banking Act 1933 | section targets | FOMC/Regulation Q provisions confirmed | statute scan pending |\n| Banking Act 1935 | section targets | modern FOMC structure / §12A confirmed | statute scan pending |\n| IMF Second Amendment | chronology | 1976 approval separated from 1978 entry into force | primary treaty record verified |\n\n## Remaining high-value blockers\n- Critical-edition Carolingian legislation.\n- Individual Digest fragments.\n- Locked print pages for medieval Islamic/Jewish corpora.\n- Statute-book scans for early English usury Acts and 1694 Bank Act.\n- Direct enacted text for 1933/1935 U.S. banking legislation.\n''')

# Update obvious version strings in site files.
for fn in ['index.html','timeline.html','research.html','references.html','source.html','about.html']:
    if os.path.exists(fn):
        s=open(fn,encoding='utf-8').read()
        s=re.sub(r'Version 6\.1', 'Version 6.2', s)
        s=re.sub(r'v6\.1', 'v6.2', s)
        open(fn,'w',encoding='utf-8').write(s)

# Append a concise sprint block to timeline/research pages if not already present.
for fn in ['timeline.html','research.html']:
    if os.path.exists(fn):
        s=open(fn,encoding='utf-8').read()
        if '6.2 Targeted Verification Sprint' not in s:
            s=s.replace('</body>', '<section><h2>6.2 Targeted Verification Sprint</h2><p>High-impact chronology, locator, and source-provenance errors were corrected. Online passage verification remains distinct from locked-print pagination.</p></section></body>')
            open(fn,'w',encoding='utf-8').write(s)

# Build zip
out='/mnt/data/FranktheWordsmith_Version_6_2_Targeted_Primary_Source_Verification.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for root,dirs,files in os.walk('.'):
        for fn in files:
            if fn==os.path.basename(out): continue
            p=os.path.join(root,fn)
            z.write(p,os.path.relpath(p,'.'))
print(out)
