# Primary-Edition Conversion Matrix — 8.1

| Period / cluster | Target | 8.0 grade | 8.1 result | Remaining blocker |
|---|---|---:|---|---|
| Roman | Digest 22.1 | B | Retain B | Locked print pagination |
| Roman | Codex 4.32.26–28 | B | Retain B | Locked edition/page |
| Late antique | Nicaea Canon 17 | B | Retain B | Critical-edition page |
| Medieval Christian | Aquinas II-II q.78 a.1–2 | B | Retain B | Critical Latin edition/page |
| Medieval Jewish | Maimonides ML 4–5 | B | Retain B | Selected scholarly edition/page |
| Maliki | *Mudawwana* | B | Retain B | Volume/page passage |
| Shafi'i | *Umm* | B | Retain B | Volume/page passage |
| Hanbali | *Mughni* | B | Retain B | Volume/page passage |
| England | 37 Hen. VIII c.9 | B | Retain B | Historical print/scan pagination |
| England | 13 Eliz. I c.8 | B | Retain B | Historical print/scan pagination |
| England | 21 Jac. I c.17 | B | Retain B | Historical print/scan pagination |
| Bank of England | Charter/Act 1694 | B | Retain B | Locked archival/printed citation |
| UK finance | Bank Charter Act 1844 | B | Retain B | Printed passage/page |
| UK finance | Usury Laws Repeal Act 1854 | B | Retain B | Project-standard page lock |
| U.S. monetary | Federal Reserve Act 1913 | B | Retain B | Statutes at Large page lock |
| U.S. banking | Banking Acts 1933/1935 | B | Retain B | Statutes at Large page lock |
| Bretton Woods | U.S. Act 1945 | B | Retain B | Printed page lock |
| U.S. monetary | Nixon 1971 | B | Retain B | Official transcript/printed locator |
| IMF | Second Amendment 1976 | B | Retain B | Edition/page lock |
| U.S. finance | Dodd-Frank 2010 | B | Retain B | Statutes at Large page lock |

## Interpretation rule

“Retain B” is not a negative judgment about the underlying source. It means the source is useful primary evidence but does not yet satisfy the archive's stricter A-grade edition-lock requirements.
