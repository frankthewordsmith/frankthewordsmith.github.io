# Version 6.6 — Publication Bibliography

## Editorial rule

This bibliography is generated from the project source records. Primary texts, editions, repositories, and contextual scholarship are kept traceable to their source records. For digitized primary material, the project records the access path and exact locator where available; this follows the general Chicago approach to documenting creator, work, access point, and relevant publication information. citeturn0search0turn0search2

### Adam Smith, The Wealth of Nations, Book I, Chapter IX
Adam Smith, The Wealth of Nations, Book I, Chapter IX

### Ambrose, De Tobia — Christian condemnation of usury
Ambrose, De Tobia, esp. chs. 1–15; final print citation should name the edition used for the Latin text and its page/column range.

### Aristotle, Politics 1.10, 1258b
Perseus / Loeb-derived text

### Augustine — lending, charity and the poor
Augustine: select an individual sermon/letter before quotation; do not cite “Augustine” as a single undifferentiated source. Noonan, The Scholastic Analysis of Usury (Harvard University Press, 1957), provides the historical analysis.

### Babylonian Talmud, Bava Metzia — ribbit sugyot
Babylonian Talmud, Bava Metzia 60b–75b; cite the individual daf/amud for every quotation.

### Bank Charter Act 1844
Bank Charter Act 1844

### Bank of England Act 1694
Bank of England Act 1694

### Bank of England Charter 1694
Bank of England Charter 1694

### Bank of England — foundation and emergence of modern central banking
Bank of England, official institutional history, “History of the Bank”; cite the web page and access date for current web content.

### Banking Act of 1933 / Glass-Steagall
Banking Act of 1933 / Glass-Steagall

### Banking Act of 1935 — modern FOMC structure
Banking Act of 1935 — modern FOMC structure

### Bretton Woods Agreements Act — U.S. implementation
Bretton Woods Agreements Act — U.S. implementation

### Bretton Woods — IMF and IBRD Articles of Agreement
Bretton Woods — IMF and IBRD Articles of Agreement

### Carolingian anti-usury legislation: Aachen 789 and Nijmegen 806
Capitularia regum Francorum; edition-specific passage pending

### Code of Hammurabi
Martha T. Roth, Law Collections from Mesopotamia and Asia Minor, 2nd ed. (Atlanta: Scholars Press, 1997), Laws of Hammurabi, pp. 71–142.

### Codex 4.32 — Justinian on interest
Justinian, Codex 4.32, De usuris; cite individual constitution (C. 4.32.xx).

### David Ricardo, On the Principles of Political Economy and Taxation, Chapter V
David Ricardo, On the Principles of Political Economy and Taxation, Chapter V

### Deuteronomy 23:20–21 — brother and foreigner
Hebrew Bible, Deuteronomy 23:20–21 (JPS 1985).

### Digest 22.1 — interest as a Roman legal category
Justinian, Digesta 22.1, De usuris et fructibus et causis et omnibus accessionibus; cite individual fragment (D. 22.1.xx) rather than a page number.

### Dodd-Frank Wall Street Reform and Consumer Protection Act
Dodd-Frank Wall Street Reform and Consumer Protection Act

### Exodus 22:25 — lending to the poor
Hebrew Bible, Exodus 22:25 (JPS 1985; common modern verse numbering).

### Federal Reserve Act — 1913
Federal Reserve Act — 1913

### First Council of Nicaea — Canon 17
First Council of Nicaea (325), Canon 17; cite the canon number. For a modern critical edition use Norman P. Tanner, Decrees of the Ecumenical Councils, vol. 1 (Georgetown University Press, 1990), Nicaea I, Canon 17.

### Hanafi fiqh — al-Sarakhsi on ribā
al-Sarakhsi, al-Mabsut, Kitab al-Buyuʿ / Kitab al-Sarf; because Beirut printings vary, the archive should store the exact edition, volume and page used for each quotation.

### Hanbali fiqh — Ibn Qudama on ribā
Ibn Qudama, al-Mughni, Kitab al-Buyuʿ / Kitab al-Sarf; store exact edition, volume and page for each quotation.

### Ibn Rushd — Bidāyat al-Mujtahid on ribā
Ibn Rushd, Bidāyat al-Mujtahid, chapter on sales involving ribā.

### Jamaica monetary reform / IMF Second Amendment
Jamaica monetary reform / IMF Second Amendment

### Jeremy Bentham, Defence of Usury
Jeremy Bentham, Defence of Usury

### Jeremy Bentham, Defence of Usury, Letter I
Jeremy Bentham, Defence of Usury, Letter I

### John Calvin, De Usuris Responsum
John Calvin, De Usuris Responsum

### John Stuart Mill, Principles of Political Economy, Book III, Chapter XXIII
John Stuart Mill, Principles of Political Economy, Book III, Chapter XXIII

### Justinian, Codex 4.32.26
Codex Iustinianus, Book 4, Title 32

### Laws of Eshnunna
Martha T. Roth, Law Collections from Mesopotamia and Asia Minor, 2nd ed. (Atlanta: Scholars Press, 1997), Laws of Eshnunna, pp. 57–66; Law 18a.

### Laws of Ur-Nammu
Martha T. Roth, Law Collections from Mesopotamia and Asia Minor, 2nd ed. (Atlanta: Scholars Press, 1997), Laws of Ur-Namma, pp. 13–39; compare CDLI composite.

### Leviticus 25:35–37 — neshekh and tarbit
Hebrew Bible, Leviticus 25:35–37 (JPS 1985).

### Maimonides, Mishneh Torah — Malveh ve-Loveh, Chapter 4
Mishneh Torah, Hilchot Malveh ve-Loveh, chapter 4; online text

### Maimonides, Mishneh Torah — Malveh ve-Loveh, Chapter 5
Mishneh Torah, Creditor and Debtor 5; online text

### Maimonides, Sefer ha-Mitzvot — Negative Commandments 235–237
Sefer ha-Mitzvot, Negative Commandments 235–237; online text

### Maliki fiqh — al-Mudawwana on ribā
Sahnun, al-Mudawwana al-Kubra, relevant Kitab al-Buyuʿ / Kitab al-Sarf; store exact edition, volume and page for each quotation.

### Mishnah Bava Metzia 5 — definitions and mechanisms of ribbit
Mishnah Bava Metzia 5:1–11; Neusner, The Mishnah: A New Translation (Yale University Press, 1988), tractate Bava Metzia, ch. 5.

### Nixon — 15 August 1971 suspension of dollar convertibility
Nixon — 15 August 1971 suspension of dollar convertibility

### Plutarch, Life of Solon 15
Loeb-derived online text

### Quinisext Council in Trullo, Canon 10
Canons of the Quinisext Council

### Qur’an 2:275–279 — ribā and trade
Qur’an 2:275–279; for publication, identify the Arabic text edition and the named English translation used.

### Qur’an 3:130 — multiplied ribā
Qur’an 3:130; for publication, identify the Arabic text edition and the named English translation used.

### Roman Twelve Tables — early interest regulation tradition
Twelve Tables, Table VIII; surviving wording is fragmentary and transmitted through later authors. Use a modern critical edition such as Crawford, Roman Statutes (1996), with the specific fragment cited.

### Sahih Muslim 1584e — equal exchange and ribā
Muslim ibn al-Hajjaj, Sahih Muslim, Kitab al-Musaqah, hadith 1584e.

### Sahih Muslim 1587c — ribā in exchange
Sahih Muslim 1587c, Book 22 (Musaqah), hadith 102 in Sunnah.com numbering; cite the Arabic text/edition if quoting Arabic.

### Sahih Muslim 1597 — six commodities
Sahih Muslim 1597; cite the specific in-book numbering and a named Arabic/print edition for publication.

### Shafi‘i fiqh — al-Umm on ribā
al-Shafiʿi, al-Umm, Kitab al-Buyuʿ / Kitab al-Sarf; store exact edition, volume and page for each quotation.

### Shulchan Arukh, Yoreh De'ah 160 — Laws of Interest
Shulchan Arukh, Yoreh De'ah 160; online text

### Thomas Aquinas — other compensation for a loan
Thomas Aquinas, Summa theologiae II–II, q. 78, a. 2; cite objection/reply number when quoting.

### Thomas Aquinas — usury as unjust sale
Thomas Aquinas, Summa theologiae II–II, q. 78, a. 1; cite objection/reply number when quoting.

### Usury Act 1545 (37 Hen. VIII c. 9)
Usury Act 1545 (37 Hen. VIII c. 9)

### Usury Act 1571 (13 Eliz. I c. 8)
Usury Act 1571 (13 Eliz. I c. 8)

### Usury Act 1624 (21 Jac. I c. 17)
Usury Act 1624 (21 Jac. I c. 17)

### Usury Laws Repeal Act 1854
Usury Laws Repeal Act 1854
