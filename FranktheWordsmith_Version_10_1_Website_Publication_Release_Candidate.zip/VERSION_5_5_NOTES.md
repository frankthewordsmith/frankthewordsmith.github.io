# Version 5.5 — Greek, Byzantine & Early Medieval Bridge

## Completed
- Added Aristotle, *Politics* 1258b as a verified Greek philosophical passage.
- Added Plutarch, *Life of Solon* 15 as later witness evidence, explicitly not as surviving Solonian legislation.
- Added Justinian, *Codex* 4.32.26.1–5 as an individual verified civil-law constitution.
- Added Justinian, *Codex* 4.32.27–28 as individual verified constitutions on accumulation and anatocism.
- Added Quinisext Council in Trullo, Canon 10 as a verified Byzantine ecclesiastical passage.
- Added a Carolingian 789–806 research target, deliberately left unquoted pending critical-edition inspection.

## Methodological result
The bridge now separates philosophical criticism, later historical witness, Byzantine civil regulation, Byzantine clerical discipline, and early medieval western legislative development. This avoids treating “usury” as a single unchanged legal category across periods.

## Next release
Version 5.6 should fill the Jewish medieval legal bridge and then begin the early-modern transition: canon law, Jewish responsa, commercial contracts, and early banking/public debt.
