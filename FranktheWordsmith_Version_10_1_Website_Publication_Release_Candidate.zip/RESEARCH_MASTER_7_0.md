# Version 7.0 — Research Master Evidence Matrix

Frozen master register for the Passage-Driven 4,000-Year Research Edition. This matrix is the canonical evidence-control layer. It preserves the distinction between primary passage, digital verification, print-edition lock, provenance, and historical inference.

## Grade key
- **A** — exact primary passage with edition/locator lock.
- **B** — primary passage with stable locator, but at least one publication/edition control remains open.
- **C** — reconstructed/composite or provenance-qualified material.
- **D** — unresolved research target; not suitable as sole support for a substantive claim.

| ID | Grade | Locator | Gaps | Source URL |
|---|---|---|---|---|
| `ur-nammu` | **C** | §§D10–D11 (reconstructed/fragmentary interest provisions) | — | https://cdli.earth/artifacts/432130 |
| `eshnunna` | **C** | Law 18a | edition/page-or-section-lock | https://cdli.earth/artifacts/480696 |
| `hammurabi` | **C** | §48; lacuna §§ t–u (interest-rate provisions); §§100 and related loan/trade provisions | provenance-caution | https://doi.org/10.2307/jj.25577265 |
| `exodus-22-24` | **B** | Exodus 22:25 in common modern verse numbering | edition/page-or-section-lock | https://www.sefaria.org/Exodus.22.25 |
| `leviticus-25-35-37` | **B** | Leviticus 25:35–37 | edition/page-or-section-lock | https://www.sefaria.org/Leviticus.25.35-37 |
| `deuteronomy-23-20-21` | **B** | Deuteronomy 23:20–21 | edition/page-or-section-lock | https://www.sefaria.org/Deuteronomy.23.20-21 |
| `mishnah-bm-5` | **B** | Mishnah Bava Metzia 5:1–11 | edition/page-or-section-lock | https://www.sefaria.org/Mishnah_Bava_Metzia.5 |
| `talmud-bm` | **B** | Bava Metzia 60b–75b, especially 61b–62a and 70b–75b | edition/page-or-section-lock | https://www.sefaria.org/Bava_Metzia.60b |
| `roman-twelve-tables` | **B** | Twelve Tables, Tabula VIII (fragmentary tradition) | — | https://academic.oup.com/edited-volume/61673/chapter-abstract/548932147 |
| `roman-digest-22-1` | **B** | Digest 22.1, De usuris et fructibus et causis et omnibus accessionibus | — | https://academic.oup.com/book/36387/chapter-abstract/319983267 |
| `roman-codex-interest` | **B** | Codex Justinianus 4.32, De usuris | — | https://droitromain.univ-grenoble-alpes.fr/Anglica/CJ4_Scott.htm |
| `nicaea-canon-17` | **B** | Canon 17 | edition/page-or-section-lock | https://www.newadvent.org/fathers/3801.htm |
| `ambrose-de-tobia` | **A** | De Tobia, especially chapters 1–15 (edition-specific pagination) | edition/page-or-section-lock | https://www.tertullian.org/fathers/ambrose_de_tobia_01.htm |
| `augustine-usury` | **B** | Relevant sermons and letters; exact passage to be selected before quotation | edition/page-or-section-lock | — |
| `quran-2-275-279` | **B** | Qur’an 2:275–279 | edition/page-or-section-lock | https://quran.com/2/275-279 |
| `quran-3-130` | **B** | Qur’an 3:130 | edition/page-or-section-lock | https://quran.com/3/130 |
| `hadith-muslim-1587c` | **B** | Sahih Muslim 1587c, Kitab al-Buyuʿ / relevant chapter | edition/page-or-section-lock | https://sunnah.com/muslim:1587c |
| `hadith-muslim-1597` | **B** | Sahih Muslim 1597 | edition/page-or-section-lock | https://sunnah.com/muslim:1597 |
| `hanafi-riba-sarakhsi` | **A** | al-Mabsut, Kitab al-Buyuʿ / Kitab al-Sarf; cite volume and page from this 2001 edition. | edition/page-or-section-lock | — |
| `maliki-riba-mudawwana` | **B** | al-Mudawwana al-Kubra, relevant Kitab al-Buyuʿ / Kitab al-Sarf; cite volume and page from the 1415/1994 five-volume edition. | edition/page-or-section-lock, pending-verification | https://fiqh.pro/Maliki/Grundlegung/Al-Mudawwana%20al-Kubra.html |
| `shafii-riba-umm` | **B** | al-Umm, Kitab al-Buyuʿ / Kitab al-Sarf; cite volume and page from the 2001 Dar al-Wafaʾ edition. | edition/page-or-section-lock, pending-verification | https://terjemahkitab.com/terjemah-al-umm-juz-3-karya-imamsyafii-pdf/ |
| `hanbali-riba-mughni` | **B** | al-Mughni, Kitab al-Buyuʿ / Kitab al-Sarf; cite volume and page from the 1417/1997 third edition. | edition/page-or-section-lock, pending-verification | https://islam.nu.or.id/amp/syariah/definisi-riba-lengkap-empat-mazhab-11fvp |
| `aquinas-q78-a1` | **B** | Summa Theologiae II–II, q.78, a.1 | edition/page-or-section-lock | https://sourcebooks.web.fordham.edu/source/aquinas-usury.asp |
| `aquinas-q78-a2` | **B** | Summa Theologiae II–II, q.78, a.2 | — | https://www.newadvent.org/summa/3078.htm |
| `boe-1694` | **B** | Bank of England foundation, 1694 | edition/page-or-section-lock | https://www.bankofengland.co.uk/about/history |
| `hadith-muslim-1584e` | **B** | Sahih Muslim 1584e | edition/page-or-section-lock | https://sunnah.com/muslim/22/103 |
| `ibn-rushd-bidayat-riba` | **B** | Bidāyat al-Mujtahid, chapter on sales involving ribā | edition/page-or-section-lock, pending-verification | https://kutub.io/en/book/21739/605 |
| `aristotle-politics-1258b` | **B** | Politics 1.10, 1258b | edition/page-or-section-lock | https://www.perseus.tufts.edu/hopper/text?doc=Perseus%3Atext%3A1999.01.0058%3Abook%3D1%3Asection%3D1258b |
| `plutarch-solon-15` | **C** | Life of Solon 15.3–5 | edition/page-or-section-lock, provenance-caution | https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Plutarch/Lives/Solon%2A.html |
| `justinian-codex-4-32-26` | **B** | C. 4.32.26.1–5 | edition/page-or-section-lock | https://droitromain.univ-grenoble-alpes.fr/Corpus/CJ4.htm |
| `justinian-codex-4-32-27-28` | **B** | C. 4.32.27.1–2; C. 4.32.28pr. | edition/page-or-section-lock | https://droitromain.univ-grenoble-alpes.fr/Corpus/CJ4.htm |
| `trullo-canon-10` | **B** | Canon 10 | edition/page-or-section-lock | https://sourcebooks.web.fordham.edu/basis/trullo.asp |
| `carolingian-usury-aachen-nijmegen` | **D** | Aachen 789; Nijmegen 806 | edition/page-or-section-lock, pending-verification | — |
| `maimonides-sefer-mitzvot-235-237` | **B** | Negative Commandments 235–237 | pending-verification | https://mechon-mamre.org/e/e0002.htm |
| `maimonides-mishneh-torah-ml-4` | **B** | Malveh ve-Loveh 4:1–10 | pending-verification | https://www.sefaria.org/Mishneh_Torah%2C_Creditor_and_Debtor.4.5 |
| `maimonides-mishneh-torah-ml-5` | **B** | Malveh ve-Loveh 5:1–8 | pending-verification | https://www.sefaria.org/Mishneh_Torah%2C_Creditor_and_Debtor.5.2 |
| `shulchan-arukh-yoreh-deah-160` | **B** | Yoreh De'ah 160:1–23 | pending-verification | https://www.sefaria.org/Shulchan_Arukh%2C_Yoreh_De%27ah.160 |
| `calvin-de-usuris-1545` | **B** | Letter to Claude de Sachin | edition/page-or-section-lock, pending-verification | https://www.leo-bw.de/web/guest/detail/-/Detail/details/DOKUMENT/bsz_swb/1507541090/Anlageberatung+mit+Johan+Calvin+sein+de+usuris+responsum+von+1545-46+zwischen+Patristik+und+%C3%96konomik |
| `henry-viii-usury-act-1545` | **B** | 37 Hen. VIII c. 9 | pending-verification | https://vlex.co.uk/vid/usury-act-1545-861268174 |
| `elizabeth-usury-act-1571` | **B** | 13 Eliz. I c. 8 | pending-verification | https://constitution.org/1-Constitution/tb/tb5.htm |
| `james-usury-act-1624` | **B** | 21 Jac. I c. 17 | pending-verification | https://constitution.org/1-Constitution/tb/tb5.htm |
| `boe-charter-1694` | **B** | Bank of England Charter, 27 July 1694 | edition/page-or-section-lock | https://www.bankofengland.co.uk/-/media/boe/files/about/legislation/boe-charter.pdf |
| `bank-act-1694` | **B** | 5 & 6 Will. & Mar. c. 20 | pending-verification | https://statutes.uk/bank-of-england-act-1694 |
| `bentham-defence-usury-1787` | **B** | Letter I, §§I.1–I.5 | pending-verification | https://www.econlib.org/library/Bentham/bnthUs.html?chapter_num=1 |
| `adam-smith-wealth-nations-i9` | **B** | Book I, Chapter IX | pending-verification | https://www.adamsmithworks.org/documents/wn-reading-guide-book-i-chapter-ix |
| `bentham-defence-usury-i` | **B** | Letter I | pending-verification | https://www.econlib.org/library/Bentham/bnthUs.html?chapter_num=1 |
| `ricardo-principles-ch-v` | **B** | Chapter V, On Profits | pending-verification | https://www.gutenberg.org/files/33310/33310-h/33310-h.htm |
| `bank-charter-act-1844` | **B** | 7 & 8 Vict. c. 32 | — | https://www.legislation.gov.uk/ukpga/1844/32/contents |
| `usury-laws-repeal-1854` | **B** | 17 & 18 Vict. c. 90 | edition/page-or-section-lock | https://www.legislation.gov.uk/ukpga/Vict/17-18/90/pdfs/ukpga_18540090_en.pdf |
| `js-mill-principles-interest` | **B** | Book III, Chapter XXIII, Of the Rate of Interest | pending-verification | https://oll-resources.s3.amazonaws.com/titles/243/Mill_0223-03_EBk_v6.0.pdf |
| `fed-act-1913` | **B** | Federal Reserve Act, ch. 6, 38 Stat. 251 | — | https://www.federalreserve.gov/frrs/statutes/federal-reserve-act.htm |
| `banking-act-1933` | **B** | Banking Act of 1933 | pending-verification | https://www.federalreservehistory.org/essays/glass-steagall-act |
| `banking-act-1935` | **B** | Banking Act of 1935; Federal Reserve Act §12A as amended | pending-verification | https://www.federalreservehistory.org/essays/banking-act-of-1935 |
| `bretton-woods-1944` | **B** | Articles of Agreement of IMF and IBRD | edition/page-or-section-lock | https://www.imf.org/en/publications/ft/aa/index |
| `bretton-woods-act-1945` | **B** | 59 Stat. 512 | pending-verification | https://history.state.gov/historicaldocuments/frus1946v01/d716 |
| `nixon-1971` | **B** | Address to the Nation Outlining a New Economic Policy | edition/page-or-section-lock | https://www.presidency.ucsb.edu/documents/address-the-nation-outlining-new-economic-policy-the-challenge-peace |
| `jamaica-1976-imf` | **B** | IMF Second Amendment; Article IV | edition/page-or-section-lock | https://www.elibrary.imf.org/display/book/9781451931068/ch037.xml |
| `dodd-frank-2010` | **B** | Pub. L. 111-203 | edition/page-or-section-lock | https://www.govinfo.gov/app/details/PLAW-111publ203 |

## Audit totals
- Records: **58**
- A: **2**
- B: **51**
- C: **4**
- D: **1**
- Complete-field rows at 6.8: **4**
- Rows with one or more open controls: **57**

## Editorial rule
A high historical confidence proposition is not automatically an A-grade citation. The grade belongs to the evidence record, not to the historian’s confidence.