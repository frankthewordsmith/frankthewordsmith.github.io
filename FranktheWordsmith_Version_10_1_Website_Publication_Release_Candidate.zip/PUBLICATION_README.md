# FranktheWordsmith — Final Research Publication Edition (Version 10.0)

This archive is a passage-driven research system covering roughly four millennia of debt, lending, interest/usury, religious regulation, law, banking, and monetary architecture.

## Start here
1. `publication.html` — public-facing publication status and evidence grades.
2. `PASSAGE_TIMELINE.md` / `timeline.html` — chronological passage structure.
3. `NARRATIVE_EVIDENCE_INTEGRATION_8_7.md` — integrated long-form evidence narrative.
4. `CLAIM_TO_PASSAGE_FINAL_MAP.md` — final claim-to-source control map.
5. `research-data.json` — structured source registry.
6. `FINAL_PUBLICATION_AUDIT_10_0.md` — final evidence inventory and publication decision.
7. `UNRESOLVED_EVIDENCE_REGISTER.md` — explicit remaining blockers.

## Evidence inventory
**59 records: A 8 / B 46 / C 4 / D 1.**

## Interpretation rule
This is a transparent research publication edition. It distinguishes primary passage verification from the stronger condition of edition/page lock. It therefore does not claim that every passage has been verified against a physical or scanned critical-edition page.

## Citation principle
Every serious historical proposition should be traceable to a source record with a stable internal locator. Page numbers, when used, belong to the named edition in that record.
