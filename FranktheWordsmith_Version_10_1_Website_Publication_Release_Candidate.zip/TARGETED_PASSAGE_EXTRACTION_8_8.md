# Targeted Passage Extraction — Version 9.0

## Editorial purpose

Version 9.0 moves four high-value B-grade sources from broad source-level verification into explicit passage-level extraction. The objective is to make the narrative easier to audit while preserving the distinction between an online text witness and an edition-locked print citation.

The Library of Congress notes that useful primary-source citations should identify the source sufficiently for future researchers to locate it, and its guidance includes author, title, version/edition, publisher, date, and location where applicable. citeturn0search0turn0search2

## 1. Thomas Aquinas — *Summa theologiae* II–II, q.78, a.1

**Canonical ID:** `aquinas-q78-a1`  
**Status:** B-grade; passage extracted, print/critical-edition page pending.

**Locator:** II–II, q.78, a.1.

**Orientation excerpt:** “To take usury for money lent is unjust in itself.”

**Bounded reading:** Aquinas's argument treats money as a consumable good in its principal use and therefore rejects charging separately for the use of the money lent. This is a direct scholastic argument about the justice of usury, but the project's publication edition still requires the exact critical-edition citation before promotion.

**Online verification:** New Advent and CCEL witnesses were checked on 2026-09-23. The online witness is not being substituted for the critical-edition page.

## 2. Maimonides — *Mishneh Torah*, *Malveh ve-Loveh* 4:1–10

**Canonical ID:** `maimonides-mishneh-torah-ml-4`  
**Status:** B-grade; stable chapter/halakhah locator, print page pending.

**Locator:** *Malveh ve-Loveh* 4:1–10.

**Orientation excerpt:** “Neshech and marbit are one in the same.”

**Bounded reading:** The chapter identifies neshech and marbit as the same prohibited interest category, extends responsibility beyond the lender to the borrower and intermediaries, and discusses restitution and the treatment of interest in documentary debt instruments.

**Online verification:** The chapter structure and Hebrew/English witness were checked on 2026-09-23. No edition-page promotion is made.

## 3. Roman *Digest* 22.1

**Canonical ID:** `roman-digest-22-1`  
**Status:** B-grade; section-level extraction, individual fragment and print page still required for quotation.

**Locator:** *Digesta* 22.1, *De usuris et fructibus et causis et omnibus accessionibus*.

**Extraction:** The title itself establishes a dedicated Justinianic compilation section for usury, fruits, causes, accessions, and delay. For publication claims, the archive must descend from the title to an individual D.22.1.xx fragment rather than cite the entire title generically.

**No verbatim passage is locked in this round.**

## 4. Justinian — *Codex* 4.32.26.1–5

**Canonical ID:** `justinian-codex-4-32-26`  
**Status:** B-grade; constitution-level extraction, print page pending.

**Locator:** C. 4.32.26.1–5.

**Extraction:** The source is retained as a specific Justinianic constitution dealing with interest rather than as a generic citation to Codex 4.32. The publication edition should quote the identified constitution and bind it to the selected print/critical edition.

**No verbatim passage is locked in this round.**

## Promotion result

**No B-grade source is promoted to A-grade in Version 9.0.** This is deliberate. Passage extraction improves claim-to-source precision, but it does not satisfy the separate print/critical-edition gate.

## Evidence inventory

| Grade | Records |
|---|---:|
| A | 8 |
| B | 46 |
| C | 4 |
| D | 1 |
| **Total** | **59** |

## Next acquisition target

Acquire or inspect the edition-specific pages for the four extracted sources. Only after the exact edition, publisher/date, and stable page/locator are verified should a source be considered for A-grade promotion.
