# Version 7.6 — Targeted A-Grade Conversion Round II

Date: 23 September 2026

## Result

One high-value B-grade record was promoted conservatively: **bretton-woods-1944**. The 1944 Final Act is identified by the IMF archive as the official document containing the IMF and IBRD Articles of Agreement; a government-print reproduction locates Annex A (IMF Articles) beginning at page 19. The 1944 agreement is kept distinct from the 1945 domestic implementing Act.

## Not promoted
Aquinas, Maimonides, the English usury statutes, Bank of England Act, Bentham, Adam Smith, Ricardo, and other candidates remain B where exact edition/page or equivalent primary locator is still incomplete.

## Grade policy
No promotion is made merely because an online transcription is reputable. The project requires a stable primary passage and an edition-level or equivalent precise locator.
