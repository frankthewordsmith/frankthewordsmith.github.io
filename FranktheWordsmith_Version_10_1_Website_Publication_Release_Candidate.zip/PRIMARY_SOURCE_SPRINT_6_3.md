# PRIMARY SOURCE SPRINT 6.3

## Locked or materially improved

### Roman law
- **Digest 22.1** — use D.22.1.9pr–1 and D.22.1.17 as individually locatable control passages.
- **Codex 4.32** — use CJ 4.32.26.1–5, 4.32.27pr–2, and 4.32.28pr as separate constitutions.

### Early-modern England
- **13 Eliz. I c.8** — early printed witness identified through the University of Pennsylvania/Online Books EEBO trail; substantive ceiling corroborated; page lock still open.
- **21 Jac. I c.17** — statute identity and 8% ceiling corroborated; page lock still open.
- **1694 Bank Act** — official Bank of England transcription now supplies the Act’s text and correct citation 5 & 6 Will. & Mar. c.20.

### Twentieth-century monetary architecture
- **Banking Act 1933 §8** — enacted text directly checked; inserted Federal Reserve Act §12A creates the FOMC.
- **Banking Act 1935 §205** — enacted text directly checked; revised §12A effective March 1, 1936 sets the modern FOMC composition.

### Carolingian legislation
- **Nijmegen 806** — Capitularia gives manuscript witness Laon BM 201, fols. 103r–104r and MGH Capit. 1, Nr. 46, S.132 Z.9–27 for cc.11–17.
- **Aachen 789** — keep as a legislative-background record until the specific usury passage is isolated.

### Jewish legal tradition
- **Shulchan Arukh YD 161** — direct Sefaria passage verification for §§1–11, especially §§1 and 5.

## Still open
Print pagination and/or critical-edition page locks remain for several medieval/early-modern works. Those are not treated as failures of passage verification; they are publication-level edition locks.
