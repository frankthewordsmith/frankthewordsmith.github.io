# Version 7.6 — Ancient & Late-Antique Primary-Source Lockdown

Date: 2026-09-23

## Purpose

Targeted primary-source lockdown of the oldest and most evidentially delicate part of the archive: Mesopotamian legal collections, Roman law, Justinianic law, Nicene canon law, and late-antique Christian evidence.

## Result

No new A-grade promotions were made merely because a passage was found online. This is intentional. The round strengthens provenance and negative-control discipline rather than manufacturing page locks.

- **Ur-Nammu:** remains C; CDLI verifies the barley/silver interest provisions but identifies the artifact as a composite.
- **Eshnunna:** remains C; fragmentary/composite textual basis.
- **Hammurabi:** remains C for the reconstructed interest-rate lacuna; secure debt/crop-failure provisions remain separately usable.
- **Digest 22.1:** remains B; Mommsen-based passage and D.22.1.1 are verified, but exact print page remains unconfirmed.
- **Codex 4.32.26–28:** remains B; Krueger-based text and constitution locators are verified, but exact print pagination remains unconfirmed.
- **Nicaea Canon 17:** remains B; canon-level text is secure and Turner/EOMIA is identified, but the exact primary-edition page was not independently locked.
- **Trullo Canon 10:** remains B pending primary-edition page lock.
- **Ambrose, De Tobia 9.33:** retains A-grade CSEL 32.2, p. 536.

## Next

Version 7.6 should target Islamic fiqh primary editions, especially the Maliki, Shafi'i, and Hanbali corpora, then return to unresolved medieval Christian and Jewish print locks.
