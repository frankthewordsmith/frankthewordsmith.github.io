import json, re, os, zipfile, shutil
from collections import Counter
from pathlib import Path
ROOT=Path('/mnt/data/v66work')
data=json.loads((ROOT/'research-data.json').read_text())
sources=data['sources']
# normalize grades
for s in sources:
    s['evidence_grade_6_6']=s.get('evidence_grade_6_4','')
    s['publication_status_6_6']='Publication-ready with evidence-grade caveat' if s['evidence_grade_6_4'] in ('A','B') else 'Retain as explicitly qualified contextual evidence'

data['version']='6.6'
data['audit_6_6']={
 'status':'Publication Edition',
 'source_count':len(sources),
 'grade_counts':dict(Counter(s.get('evidence_grade_6_4','') for s in sources)),
 'principle':'No quotation is presented as edition-locked unless its evidence record explicitly supports that claim.',
 'citation_style':'Chicago Notes and Bibliography, adapted for digital primary sources and legal materials.',
 'generated':'2026-09-23'
}
# bibliography entries
entries=[]
for s in sources:
    e=s.get('bibliography_entry') or s.get('edition') or s.get('title')
    if e:
        entries.append((s['title'],e))
# dedupe exact bibliography text
seen=set(); bib=[]
for title,e in entries:
    if e not in seen:
        seen.add(e); bib.append((title,e))
bib.sort(key=lambda x:x[0].lower())

bib_md=['# Version 6.6 — Publication Bibliography','',
'## Editorial rule','',
'This bibliography is generated from the project source records. Primary texts, editions, repositories, and contextual scholarship are kept traceable to their source records. For digitized primary material, the project records the access path and exact locator where available; this follows the general Chicago approach to documenting creator, work, access point, and relevant publication information. citeturn0search0turn0search2','']
for title,e in bib:
    bib_md.append(f'### {title}\n{e}\n')
(ROOT/'PUBLICATION_BIBLIOGRAPHY_6_6.md').write_text('\n'.join(bib_md),encoding='utf-8')

# passage index
rows=[]
for s in sorted(sources,key=lambda x:(str(x.get('date_start','')),x.get('title',''))):
    p=s.get('passage_record') or {}
    loc=p.get('locator') or s.get('reference_number') or s.get('section') or s.get('chapter') or s.get('verse') or s.get('page') or ''
    ev=p.get('evidence') or s.get('translation') or s.get('historical_claim') or ''
    grade=s.get('evidence_grade_6_4','')
    rows.append((s['source_id'],s['title'],s.get('date_label',''),loc,grade,ev[:300].replace('\n',' ')))
md=['# Version 6.6 — Passage / Quotation Index','',
'Every public quotation or close paraphrase should resolve to this index and then to the underlying source record. The index intentionally preserves qualification language for composite, reconstructed, later-witness, and edition-pending material.','',
'| ID | Source | Date | Exact locator | Grade | Passage evidence / controlled summary |','|---|---|---|---|---|---|']
for r in rows:
    vals=[str(x).replace('|','\\|') for x in r]
    md.append('| '+' | '.join(vals)+' |')
(ROOT/'PASSAGE_QUOTATION_INDEX_6_6.md').write_text('\n'.join(md),encoding='utf-8')

# final editorial audit
counts=Counter(s.get('evidence_grade_6_4','') for s in sources)
missing=[]
for s in sources:
    for field in ('title','source_type','primary_or_secondary','verification_status'):
        if not s.get(field): missing.append((s['source_id'],field))
    if not (s.get('passage_record') or s.get('reference_number') or s.get('section') or s.get('verse')):
        missing.append((s['source_id'],'locator'))

audit=f'''# Version 6.6 — Final Editorial Audit

## Scope
This is the publication-edition audit of the 58-source research archive. It does not promote a source merely because a readable online transcription exists. The project distinguishes exact primary text, stable online verification, reconstructed/composite material, later witnesses, and unresolved edition work.

## Evidence inventory
- Total source records: {len(sources)}
- Grade A: {counts.get('A',0)}
- Grade B: {counts.get('B',0)}
- Grade C: {counts.get('C',0)}
- Grade D: {counts.get('D',0)}

## Publication rules
1. Use Chicago Notes and Bibliography as the default historical citation system; this is particularly suitable for humanities research and flexible primary-source documentation. citeturn0search2
2. For digitized primary sources, identify the original creator/work and the digital repository or access path; include an exact locator when available. citeturn0search0turn0search5
3. Do not silently convert a secondary quotation into a primary-source quotation. When the original is unavailable, identify the secondary source as the intermediary. citeturn0search10
4. Legal statutes remain cited in their legal form and are not forced into ordinary book-bibliography formatting where that would obscure the legal citation. citeturn0search11
5. Never invent pagination, edition data, original-language wording, or manuscript details.
6. Grade C/D material remains explicitly qualified in the public narrative.

## Remaining limitations
'''
if missing:
    audit += '\n'.join(f'- {sid}: missing/weak {field}' for sid,field in missing)
else:
    audit += '- No required core metadata field or locator was found missing under the project validation rules.'
audit += '''\n\n## Publication status\nThe archive is suitable for a publication-facing edition with visible evidence grades. The remaining scholarly work is refinement of individual Grade B records into edition/page-locked Grade A records, not a reason to conceal their present status.\n'''
(ROOT/'FINAL_EDITORIAL_AUDIT_6_6.md').write_text(audit,encoding='utf-8')

# notes
notes='''# Version 6.6 — Publication Edition Notes\n\nVersion 6.6 converts the Version 6.5 synthesis into a publication-facing research package.\n\n### Added\n- Publication bibliography generated from the source records.\n- Passage / quotation index linking each source to its controlled locator and evidence grade.\n- Final editorial audit and publication rules.\n- Evidence-grade and publication-status fields in `research-data.json`.\n- Publication Edition page in the site navigation.\n\n### Citation policy\nThe project uses Chicago Notes and Bibliography as its default historical style, with adaptations for digitized primary sources and legal materials. The Library of Congress notes that digitized primary-source citations should provide enough information for readers to identify and retrieve the source; the Chicago Manual likewise supports Notes and Bibliography for humanities work and unusual source types.\n\n### Final status\nThis is a publication edition, not a claim that every source is edition-perfect. Grade B/C/D labels remain visible and are part of the evidence rather than editorial noise.\n'''
(ROOT/'VERSION_6_6_NOTES.md').write_text(notes,encoding='utf-8')

# update json
(ROOT/'research-data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')

# add publication page
page='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Publication Edition — Version 6.6</title><link rel="stylesheet" href="style.css"></head><body><main class="container"><p><a href="index.html">← Home</a></p><h1>Version 6.6 — Publication Edition</h1><p class="lead">The research archive is now organized as a publication-facing evidence system: synthesis, passage index, bibliography, and explicit evidence grades.</p><h2>Evidence grades</h2><ul><li><strong>A</strong> — exact primary text plus edition/locator lock.</li><li><strong>B</strong> — primary passage with stable locator; print-edition lock may remain open.</li><li><strong>C</strong> — reconstruction, composite text, or later witness.</li><li><strong>D</strong> — unresolved research target.</li></ul><h2>Publication files</h2><ul><li><a href="PASSAGE_DRIVEN_4000_YEAR_SYNTHESIS_6_5.md">4,000-Year Passage-Driven Synthesis</a></li><li><a href="PASSAGE_QUOTATION_INDEX_6_6.md">Passage / Quotation Index</a></li><li><a href="PUBLICATION_BIBLIOGRAPHY_6_6.md">Publication Bibliography</a></li><li><a href="FINAL_EDITORIAL_AUDIT_6_6.md">Final Editorial Audit</a></li></ul><p>Version 6.6 does not erase uncertainty. Where a source is reconstructed, composite, later-witness, or edition-pending, that status remains part of the citation record.</p></main></body></html>'''
(ROOT/'publication.html').write_text(page,encoding='utf-8')

# lightweight version/nav updates
for fn in ['index.html','about.html','references.html','research.html','source.html','timeline.html','synthesis.html']:
    p=ROOT/fn
    if p.exists():
        txt=p.read_text(encoding='utf-8')
        txt=re.sub(r'Version 6\.5', 'Version 6.6', txt)
        if 'publication.html' not in txt and '</nav>' in txt:
            txt=txt.replace('</nav>','<a href="publication.html">Publication Edition</a></nav>',1)
        p.write_text(txt,encoding='utf-8')

# package
zip_path=Path('/mnt/data/FranktheWordsmith_Version_6_6_Publication_Edition.zip')
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.iterdir()):
        if p.name==zip_path.name or p.is_dir(): continue
        z.write(p,p.name)
print(zip_path, zip_path.stat().st_size)
print('grades',dict(counts),'bib',len(bib),'missing',len(missing))
