# VERSION 5.9 — Late-Nineteenth-Century Banking, Central Banking & Monetary Architecture

## Scope
This pass extends the chronology from the 1854 repeal of English usury laws into the institutional development of modern banking and central-bank crisis management.

## Passage records
- **1802 — Henry Thornton, *Paper Credit*:** primary monetary/banking theory; online text verified, edition-page lock pending.
- **1866 — Bank Charter crisis:** statutory and parliamentary evidence surrounding the Panic of 1866; exact statutory quotation remains pending.
- **1873 — Walter Bagehot, *Lombard Street*:** primary passage verified online; chapters VII/XII are the principal lender-of-last-resort evidence. Bagehot is not treated as the inventor of the practice; archival research shows earlier Bank lending during crises.
- **1878 — Banking legislation:** added as an institutional checkpoint; exact section-level quotation remains pending.
- **c. 1870–1914 — gold-standard architecture:** included as a regime-level placeholder, not as a claim that one statute created a universal gold standard. Country-specific primary records remain necessary.

## Evidence rule
The archive distinguishes: (1) what bankers and governments actually did, (2) what statutes authorized, and (3) what economists argued should be done. Later historical studies may establish context, but they do not replace the primary passage.

## Historical qualification
The Bank of England's lender-of-last-resort function developed before Bagehot's 1873 formulation. Modern Bank of England archival research finds substantial crisis lending in 1847, 1857, and 1866, with variation among crises. Bagehot's contribution is therefore recorded as a major theoretical formulation and public articulation, not as the first instance of emergency central-bank lending.

## Next target
Version 6.0: twentieth-century monetary architecture — Federal Reserve, interwar reconstruction, Bretton Woods, 1971 convertibility break, and modern credit regulation.
