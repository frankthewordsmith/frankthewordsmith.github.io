# Version 5.0 — Passage-Driven Timeline

Version 5.0 converts the Version 4.6 source framework into a chronological passage register. It does not erase earlier verification controls. Instead, every timeline entry now carries a passage record with a locator, evidentiary status, evidence summary, and significance.

## Important corrections
- The Ur-Namma rate passage is now tied directly to the CDLI composite lines containing the barley and silver loans.
- The Hammurabi entry explicitly separates intact debt provisions from reconstructed interest-rate material.
- The archive corrects the Exodus citation label: the interest passage is Exodus 22:25 in common modern verse numbering, while the archive title previously used 22:24.
- Biblical, rabbinic, Qur’anic, hadith, patristic, scholastic, statutory and institutional sources are kept in their own evidentiary categories.
- Roman Twelve Tables evidence is marked as secondary transmission because the tablets themselves do not survive intact.
- The three previously page-pending classical Islamic fiqh records remain page-pending; no substitute edition pagination has been imported.

## Next verification pass
The remaining priority is edition-specific page verification for Eshnunna, the three classical fiqh works, and individual Roman Digest/Codex fragments before any long quotation is published.
