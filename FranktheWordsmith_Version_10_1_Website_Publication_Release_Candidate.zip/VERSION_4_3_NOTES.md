# FranktheWordsmith Version 4.3 — Focused Research Archive

This version uses the Hammurabi research record as the canonical template and splits broad historical categories into discrete source records where a precise primary text or institutional event can be independently cited.

## Expanded focused records
- Biblical: Exodus 22:24; Leviticus 25:35–37; Deuteronomy 23:20–21
- Rabbinic: Mishnah Bava Metzia 5; Babylonian Talmud Bava Metzia
- Roman: Twelve Tables tradition; Digest 22.1; Codex 4.32
- Christian: Nicaea Canon 17; Ambrose De Tobia; Augustine research node
- Qur'anic: 2:275–279; 3:130
- Hadith: Sahih Muslim 1587c; 1597
- Sunni fiqh: representative Hanafi, Maliki, Shafi'i and Hanbali records
- Aquinas: Summa II–II q.78 a.1 and a.2
- Modern finance: Bank of England 1694; Federal Reserve Act 1913; Bretton Woods 1944; 1971 suspension of dollar-gold convertibility

## Evidence policy
Records distinguish primary evidence from later interpretation. Fragmentary or reconstruction-dependent material is marked accordingly. School-specific Islamic-law records remain Research Draft until an exact edition, volume and page are selected for quotation.

## Next scholarly pass
Before publication, select one physical/digital edition for each classical corpus and add exact volume/page citations, original-language quotations, translators, and footnotes. Do not treat web pages as substitutes for critical editions where a print scholarly citation is required.
