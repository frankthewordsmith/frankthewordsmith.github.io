# VERSION 6.4 — MASTER PRIMARY-PASSAGE TABLE

This table is the evidence spine for the eventual 4,000-year narrative. It deliberately separates secure passage locators from publication-grade edition locks.

| Date | Source | Passage / locator | Evidence | Verification |
|---|---|---|---|---|
| Ur III period; reign traditionally dated c. 2112–2095 BCE | `ur-nammu` — Laws of Ur-Nammu | RIME 3/2.01.01.20, composite, lines d036–d041 (Q000947) | **C** | Passage verified — composite text |
| Early second millennium BCE; exact dating debated | `eshnunna` — Laws of Eshnunna | RIME 4.05.19.add03, Law 18a, lines 62–63; compare Law 21, lines 70–72 | **C** | Passage verified — composite text |
| Reign of Hammurabi, c. 1792–1750 BCE | `hammurabi` — Code of Hammurabi | Code of Hammurabi §§48–52 and the damaged sequence §§66–99; compare traditional §88 for reconstructed interest rates | **C** | Passage verified — debt provisions; rate passage reconstructed |
| 4th century BCE | `aristotle-politics-1258b` — Aristotle, Politics 1.10, 1258b | Politics 1.10, 1258b | **B** | Passage verified |
| Later witness to 6th-century BCE Solonian reforms | `plutarch-solon-15` — Plutarch, Life of Solon 15 | Life of Solon 15.3–5 | **C** | Secondary/witness evidence |
| 528 CE | `justinian-codex-4-32-26` — Justinian, Codex 4.32.26 | C. 4.32.26.1–5 | **B** | Passage verified |
| 529 CE | `justinian-codex-4-32-27-28` — Justinian, Codex 4.32.27–28 | C. 4.32.27.1–2; C. 4.32.28pr. | **B** | Passage verified |
| 692 CE | `trullo-canon-10` — Quinisext Council in Trullo, Canon 10 | Canon 10 | **B** | Passage verified |
| 789–806 CE | `carolingian-usury-aachen-nijmegen` — Carolingian anti-usury legislation: Aachen 789 and Nijmegen 806 | Aachen 789; Nijmegen 806 | **D** | Research target — critical edition pending |
| 3rd century AH / 9th century CE compilation | `hadith-muslim-1584e` — Sahih Muslim 1584e — equal exchange and ribā | Sahih Muslim 1584e | **B** | Passage-level record established |
| 12th century CE | `ibn-rushd-bidayat-riba` — Ibn Rushd — Bidāyat al-Mujtahid on ribā | Bidāyat al-Mujtahid, chapter on sales involving ribā; online locator 3/148 | **B** | Passage-level record established online; print edition pending |
| 12th century CE; Mishneh Torah composed c. 1170–1180 | `maimonides-mishneh-torah-ml-4` — Maimonides, Mishneh Torah — Malveh ve-Loveh, Chapter 4 | Malveh ve-Loveh 4:1–10 | **B** | Passage verified — stable online locator; print-edition page pending |
| 12th century CE; Mishneh Torah composed c. 1170–1180 | `maimonides-mishneh-torah-ml-5` — Maimonides, Mishneh Torah — Malveh ve-Loveh, Chapter 5 | Malveh ve-Loveh 5:1–8 | **B** | Passage verified — stable online locator; print-edition page pending |
| 12th century CE; Sefer ha-Mitzvot | `maimonides-sefer-mitzvot-235-237` — Maimonides, Sefer ha-Mitzvot — Negative Commandments 235–237 | Negative Commandments 235–237 | **B** | Passage verified — stable online locator; print-edition page pending |
| 1545/46 CE | `calvin-de-usuris-1545` — John Calvin, De Usuris Responsum | Letter to Claude de Sachin | **B** | Passage verified — stable secondary reproduction of primary text; critical/early edition lock pending |
| 1545 CE | `henry-viii-usury-act-1545` — Usury Act 1545 (37 Hen. VIII c. 9) | 37 Hen. VIII c. 9 | **B** | Primary statute verified — stable transcription; statute-book page lock pending |
| 16th century; early modern transition | `shulchan-arukh-yoreh-deah-160` — Shulchan Arukh, Yoreh De'ah 160 — Laws of Interest | Yoreh De'ah 160:1–23 | **B** | Primary passage directly verified online; edition-page verification pending |
| 1571 CE | `elizabeth-usury-act-1571` — Usury Act 1571 (13 Eliz. I c. 8) | 13 Eliz. I c. 8 | **B** | Primary statute verified — stable secondary transcription; statute-book page lock pending |
| 1624 CE | `james-usury-act-1624` — Usury Act 1624 (21 Jac. I c. 17) | 21 Jac. I c. 17 | **B** | Primary statute verified — stable secondary transcription; statute-book page lock pending |
| 1694 CE | `bank-act-1694` — Bank of England Act 1694 | 5 & 6 Will. & Mar. c. 20 | **B** | Primary statute identified and citation corrected; exact passage/page lock pending |
| 27 July 1694 | `boe-charter-1694` — Bank of England Charter 1694 | Bank of England Charter, 27 July 1694 | **B** | Primary document verified — official Bank of England transcript |
| 1776 | `adam-smith-wealth-nations-i9` — Adam Smith, The Wealth of Nations, Book I, Chapter IX | Book I, Chapter IX | **B** | GREEN — primary passage online verified; edition-page lock pending |
| 1787 CE | `bentham-defence-usury-1787` — Jeremy Bentham, Defence of Usury | Letter I, §§I.1–I.5 | **B** | Passage verified — first-edition bibliographic record plus stable online text; page lock pending |
| 1787 | `bentham-defence-usury-i` — Jeremy Bentham, Defence of Usury, Letter I | Letter I | **B** | GREEN — primary passage online verified; first-edition page lock pending |
| 1817 | `ricardo-principles-ch-v` — David Ricardo, On the Principles of Political Economy and Taxation, Chapter V | Chapter V, On Profits | **B** | GREEN — primary passage online verified; edition-page lock pending |
| 19 July 1844 | `bank-charter-act-1844` — Bank Charter Act 1844 | 7 & 8 Vict. c. 32 | **B** | GREEN — statute identified; original section-level verification required for publication quotation |
| 1848 | `js-mill-principles-interest` — John Stuart Mill, Principles of Political Economy, Book III, Chapter XXIII | Book III, Chapter XXIII, Of the Rate of Interest | **B** | GREEN — primary passage online verified; edition-page lock pending |
| 10 August 1854 | `usury-laws-repeal-1854` — Usury Laws Repeal Act 1854 | 17 & 18 Vict. c. 90 | **B** | GREEN — primary statute text verified |
| 23 December 1913 | `fed-act-1913` — Federal Reserve Act — 1913 | Federal Reserve Act, ch. 6, 38 Stat. 251 (1913), especially §§2, 13, 14 | **B** | GREEN — official statutory text identified; section-level citations locked to the Act |
| 16 June 1933 | `banking-act-1933` — Banking Act of 1933 / Glass-Steagall | Banking Act of 1933; FOMC provisions and banking-separation provisions | **B** | Primary statute identified; section-level passage verified through official historical record; print/statute page lock pending |
| 23 August 1935 | `banking-act-1935` — Banking Act of 1935 — modern FOMC structure | Banking Act of 1935, Title II; Federal Reserve Act §12A as amended | **B** | Primary statute identified; section-level passage verified through official historical record; print/statute page lock pending |
| 22 July 1944 | `bretton-woods-1944` — Bretton Woods — IMF and IBRD Articles of Agreement | IMF Articles of Agreement, Articles I–IV; IBRD Articles of Agreement, relevant institutional provisions | **B** | GREEN — official IMF/State Department documentary record verified |
| 31 July 1945 | `bretton-woods-act-1945` — Bretton Woods Agreements Act — U.S. implementation | Bretton Woods Agreements Act, 59 Stat. 512 (1945) | **B** | GREEN/YELLOW — official historical locator verified; section quotation pending locked statute text |
| 15 August 1971 | `nixon-1971` — Nixon — 15 August 1971 suspension of dollar convertibility | Richard Nixon, Address to the Nation Outlining a New Economic Policy, 15 Aug. 1971 | **B** | GREEN — primary speech verified |
| 1976 agreement; 1978 Second Amendment effective | `jamaica-1976-imf` — Jamaica monetary reform / IMF Second Amendment | IMF Second Amendment, Article IV; Jamaica agreement, January 1976 | **B** | Primary institutional record verified — 1976 agreement distinguished from 1978 legal entry into force |
| 21 July 2010 | `dodd-frank-2010` — Dodd-Frank Wall Street Reform and Consumer Protection Act | Pub. L. 111-203 (2010), selected Titles I, II, VII, X | **B** | GREEN — official statute record verified |
| c. 380 CE | `ambrose-de-tobia` — Ambrose, De Tobia — Christian condemnation of usury | De Tobia 9.33; CSEL 32.2, p. 536 | **B** | Passage-level record established |
| c. 1265–1274 CE | `aquinas-q78-a1` — Thomas Aquinas — usury as unjust sale | Summa theologiae II–II, q.78, a.1 | **B** | Passage-level record established |
| c. 1265–1274 CE | `aquinas-q78-a2` — Thomas Aquinas — other compensation for a loan | Summa theologiae II–II, q.78, a.2 | **B** | Citation locked at stable source locator; edition/page to be added if a print quotation is used |
| late 4th–early 5th century CE | `augustine-usury` — Augustine — lending, charity and the poor | Enarratio in Psalmum XXXVI 3.6; CCSL 38, p. 372 | **B** | Passage-level record established |
| 1694 CE | `boe-1694` — Bank of England — foundation and emergence of modern central banking | Bank of England foundation charter / official history, 1694 | **B** | Passage-level record established |
| First millennium BCE / Hebrew Bible | `deuteronomy-23-20-21` — Deuteronomy 23:20–21 — brother and foreigner | Deuteronomy 23:20–21 | **B** | Citation locked — primary/source locator recorded |
| First millennium BCE / Hebrew Bible | `exodus-22-24` — Exodus 22:25 — lending to the poor | Exodus 22:25 in most modern verse numbering (archive title uses 22:24) | **B** | Primary passage verified — verse locator corrected |
| 3rd century AH / 9th century CE compilation | `hadith-muslim-1587c` — Sahih Muslim 1587c — ribā in exchange | Sahih Muslim 1587c | **B** | Passage-level record established |
| 3rd century AH / 9th century CE compilation | `hadith-muslim-1597` — Sahih Muslim 1597 — six commodities | Sahih Muslim 1597; Abd al-Baqi numbering; archive baseline vol. 3, p. 1218 | **B** | Passage-level record established |
| 11th century CE | `hanafi-riba-sarakhsi` — Hanafi fiqh — al-Sarakhsi on ribā | al-Mabsut, Kitab al-Buyuʿ, Anwaʿ al-Riba, vol. 12, pp. 110–111 | **B** | Passage-level record established |
| 12th century CE | `hanbali-riba-mughni` — Hanbali fiqh — Ibn Qudama on ribā | al-Mughni, Kitab al-Buyuʿ / Kitab al-Sarf | **B** | Passage-level record established; locked-print pagination pending |
| First millennium BCE / Hebrew Bible | `leviticus-25-35-37` — Leviticus 25:35–37 — neshekh and tarbit | Leviticus 25:35–37 | **B** | Citation locked — primary/source locator recorded |
| 8th–9th century CE compilation/redaction | `maliki-riba-mudawwana` — Maliki fiqh — al-Mudawwana on ribā | al-Mudawwana al-Kubra, Kitab al-Buyuʿ / Kitab al-Sarf | **B** | Passage-level record established; locked-print pagination pending |
| c. 2nd century CE | `mishnah-bm-5` — Mishnah Bava Metzia 5 — definitions and mechanisms of ribbit | Mishnah Bava Metzia 5:1–2 | **B** | Passage-level record established |
| 325 CE | `nicaea-canon-17` — First Council of Nicaea — Canon 17 | First Council of Nicaea, Canon 17 | **B** | Passage-level record established |
| 7th century CE | `quran-2-275-279` — Qur’an 2:275–279 — ribā and trade | Qur’an 2:275–279 | **B** | Passage-level record established |
| 7th century CE | `quran-3-130` — Qur’an 3:130 — multiplied ribā | Qur’an 3:130 | **B** | Passage-level record established |
| 6th century CE | `roman-codex-interest` — Codex 4.32 — Justinian on interest | Codex 4.32, De usuris | **B** | Citation locked at stable source locator; edition/page to be added if a print quotation is used |
| 6th century CE compilation of earlier Roman law | `roman-digest-22-1` — Digest 22.1 — interest as a Roman legal category | Digesta 22.1, De usuris et fructibus et causis et omnibus accessionibus | **B** | Citation locked at stable source locator; edition/page to be added if a print quotation is used |
| 451–450 BCE | `roman-twelve-tables` — Roman Twelve Tables — early interest regulation tradition | Twelve Tables, Table VIII; later testimony including Tacitus, Annals 6.16 | **B** | Citation framework locked — exact edition/page still required before publication quotation |
| 9th century CE | `shafii-riba-umm` — Shafi‘i fiqh — al-Umm on ribā | al-Umm, Kitab al-Buyuʿ / Kitab al-Sarf | **B** | Passage-level record established; locked-print pagination pending |
| Late antiquity; redacted c. 5th–6th century CE | `talmud-bm` — Babylonian Talmud, Bava Metzia — ribbit sugyot | Babylonian Talmud, Bava Metzia 75a–75b; individual amud required for print citation | **B** | Passage-level record established |
