# Version 7.6 — Primary-Edition Lockdown

This release continues the passage-driven archive by converting the next high-value B-grade records only where an edition-specific page lock could be independently established.

## Promoted to A-grade

1. **Jeremy Bentham, Defence of Usury (1787)** — first edition, T. Payne and Son; Letter I begins on p. 1.
2. **Adam Smith, Wealth of Nations, Book I, Chapter IX** — Glasgow Edition of the Works and Correspondence of Adam Smith, vol. 2; Chapter IX begins on p. 105.
3. **David Ricardo, Principles of Political Economy and Taxation (1817)** — first edition; duplicate chapter numbering preserved as **V*** for “On Profits,” beginning on p. 116.
4. The duplicate **bentham-defence-usury-i** record is synchronized to the same first-edition lock.

## Not promoted

Aquinas II-II q.78 a.1/a.2, Maimonides *Mishneh Torah*, the 1545/1571/1624 English usury statutes, the Bank of England Act 1694, and the Bretton Woods Agreements Act 1945 remain B-grade in this release because this sprint did not establish all required edition/page or folio fields to the archive standard.

## Editorial rule

A web-verified passage and a bibliographic record are not, by themselves, an A-grade print lock. A-grade requires a named edition, exact passage locator, and edition-specific page/folio for the relevant passage.
