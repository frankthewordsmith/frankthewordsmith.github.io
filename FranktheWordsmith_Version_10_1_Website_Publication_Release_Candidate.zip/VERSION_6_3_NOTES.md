# Version 6.3 — Publication-Lock Sprint

Date: 2026-09-23

## Purpose
This pass narrows the archive from broad source identification to individually controlled passage/statute/manuscript locators. It does not treat online text verification as equivalent to locked-print pagination.

## Major locks added
- Roman Digest: individual fragments D.22.1.9pr–1 and D.22.1.17, with title-level record retained.
- Justinian Codex: CJ 4.32.26–28 separated into individual constitutions.
- English usury statutes: 13 Eliz. I c.8 and 21 Jac. I c.17 now have independent early-print/statutory corroboration, but page lock remains open.
- Bank of England Act 1694: official Bank of England transcription and archive metadata now support direct quotation/locator work.
- Banking Act 1933: enacted §8 / inserted §12A directly verified in FRASER.
- Banking Act 1935: enacted §205 / revised §12A directly verified in FRASER.
- Carolingian usury: Nijmegen 806, cc.11–17 now has a manuscript witness plus MGH edition/page-line locator; Aachen 789 is deliberately kept contextual until its usury passage is isolated.
- Shulchan Arukh: Yoreh De‘ah 161:1–11 directly verified online; this is more precise than the prior broad chapter-160 target.

## Editorial guardrail
The archive continues to distinguish: surviving primary text; manuscript witness; critical/standard edition; stable online transcription; later witness; secondary analysis; and reconstruction. A page number is never inferred from a web transcription.
