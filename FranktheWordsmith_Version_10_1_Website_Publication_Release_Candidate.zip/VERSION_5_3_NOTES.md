# Version 5.3 — Islamic Fiqh & Medieval Christianity Passage Verification

Date: 23 September 2026

## Purpose

Version 5.3 extends the passage-driven standard into Islamic hadith/fiqh and medieval Christian scholastic material. It distinguishes a verified textual locator from a locked-print pagination claim.

## Islamic material upgraded

- **Sahih Muslim 1584e** added as a distinct primary hadith passage. The report concerns equal, hand-to-hand exchange of six named commodities and identifies an addition as ribā. Online locator: `Sahih Muslim 1584e`.
- **Sahih Muslim 1587c** upgraded to passage-level verification using the stable hadith locator.
- **al-Mudawwana** upgraded from structural-only to passage-level online verification, while retaining the locked 1994 printing as the authority for future page locking.
- **al-Umm** upgraded from structural-only to passage-level online verification, while retaining the locked 2001 Dar al-Wafaʾ edition as the authority for future page locking.
- **al-Mughni** upgraded from structural-only to passage-level online verification. A secondary reference identifies the 1997 Beirut edition, vol. 4, p. 35, but the archive does not treat that page as directly inspected yet.
- **Ibn Rushd, Bidāyat al-Mujtahid** added as a comparative juristic synthesis. It summarizes ribā in liabilities and sales and records juristic disagreement over excess and deferment. It is not used as evidence for the wording of earlier primary texts.

## Medieval Christian material upgraded

- **Aquinas, Summa theologiae II–II, q.78, a.1** upgraded to passage-level verification using the stable article locator and a separate medieval-source transcription.
- The existing q.78, a.2 entry remains as a separate qualification concerning other forms of compensation associated with a loan.

## Editorial rule

A web-verified passage is not automatically a print-edition page verification. The timeline therefore uses statuses such as **“Passage verified online — print page pending.”** This prevents cross-edition pagination from being silently imported into the research archive.

## Sources checked

- Sahih Muslim 1584e: https://sunnah.com/muslim/22/103
- Sahih Muslim 1587c: https://sunnah.com/muslim:1587c
- al-Mudawwana overview: https://fiqh.pro/Maliki/Grundlegung/Al-Mudawwana%20al-Kubra.html
- al-Umm online witness: https://terjemahkitab.com/terjemah-al-umm-juz-3-karya-imamsyafii-pdf/
- Ibn Qudama / al-Mughni reference: https://islam.nu.or.id/amp/syariah/definisi-riba-lengkap-empat-mazhab-11fvp
- Ibn Rushd, Bidāyat al-Mujtahid: https://kutub.io/en/book/21739/605
- Aquinas, On Usury: https://sourcebooks.web.fordham.edu/source/aquinas-usury.asp
