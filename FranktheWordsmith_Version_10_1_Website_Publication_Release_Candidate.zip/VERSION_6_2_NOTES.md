# VERSION 6.2 — TARGETED PRIMARY-SOURCE VERIFICATION SPRINT

**Date:** 2026-09-23
**Baseline:** Version 6.1

## Purpose
This release resolves high-impact locator and chronology problems identified in the 6.1 lockdown and upgrades several yellow records where stable primary or institutional evidence is now available. It does **not** pretend that online verification equals locked-print pagination.

## Corrections and upgrades

1. **Maimonides chronology corrected.** The prior build incorrectly represented the 12th-century author with BCE-style negative dates. The Mishneh Torah records now use c. 1170–1180 CE.
2. **Maimonides primary locators strengthened.** Sefaria exposes *Creditor and Debtor* 4 and 5 directly; print-edition pagination remains pending.
3. **Calvin URL corrected.** The previous record incorrectly pointed to a Bentham page. The record now points to a scholarly bibliographic record for *De Usuris Responsum* and explicitly distinguishes reproduction from critical-edition verification.
4. **Exodus locator corrected.** The lending-to-the-poor passage is Exodus 22:25 in common modern numbering; the previous archive record contained a mismatch.
5. **English usury statutes strengthened.** 37 Hen. VIII c. 9, 13 Eliz. c. 8 and 21 Jac. I c. 17 are retained as primary statutory records, with the requirement that final quotations be checked against statute-book scans. The 1854 repeal Act itself lists the earlier statutes in its schedule.
6. **Bank of England Act 1694 citation corrected** to 5 & 6 Will. & Mar. c. 20; it remains distinct from the Royal Charter of 27 July 1694.
7. **Banking Acts 1933/1935 upgraded.** Federal Reserve History confirms the 1933 FOMC creation and the 1935 modern FOMC structure; exact statutory quotations remain a final publication lock.
8. **IMF Jamaica/Second Amendment distinction strengthened.** The Proposed Second Amendment was approved on April 30, 1976 and entered into force on April 1, 1978.

## Editorial rule retained
A source can be **passage-verified online** while still being **page-pending in the locked print edition**. Those states must not be collapsed.
