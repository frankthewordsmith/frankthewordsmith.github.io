# Version 7.0 — Claim-Level Synthesis Audit

Every major narrative proposition in the 6.5 synthesis has been reduced to an evidence claim. Statuses are intentionally conservative.

| Claim | Status | Supporting records | Limitation |
|---|---|---|---|
| Mesopotamia: lending as regulated legal object | **Directly demonstrated with qualifications** | ur-nammu; eshnunna; hammurabi | C-grade reconstructed/composite material means rate language must remain qualified. |
| Hebrew Bible: social relationship affects lending rules | **Directly demonstrated** | exodus-22-24; leviticus-25-35-37; deuteronomy-23-20-21 | Translation/edition pagination remains open; verse locators are stable. |
| Greek philosophy: interest becomes a question about money itself | **Directly demonstrated** | aristotle-politics-1258b | Print-edition lock remains open. |
| Roman law: interest becomes a technical legal category | **Directly demonstrated** | roman-digest-22-1; roman-codex-interest; justinian-codex-4-32-26; justinian-codex-4-32-27-28 | Individual fragment/constitution locators must accompany quotations. |
| Christian late antiquity: lending becomes clerical discipline | **Directly demonstrated** | nicaea-canon-17; ambrose-de-tobia; augustine-usury; trullo-canon-10 | Several records remain B-grade despite strong passage locators. |
| Islamic revelation and fiqh: ribā develops into a detailed legal category | **Directly demonstrated as a historical development** | quran-2-275-279; quran-3-130; hadith-muslim-1584e; hadith-muslim-1587c; hadith-muslim-1597; hanafi-riba-sarakhsi; maliki-riba-mudawwana; shafii-riba-umm; hanbali-riba-mughni | Do not project later juristic definitions backward into Qur’anic wording. |
| Medieval Jewish law: prohibition becomes detailed transactional code | **Directly demonstrated** | maimonides-sefer-mitzvot-235-237; maimonides-mishneh-torah-ml-4; maimonides-mishneh-torah-ml-5; shulchan-arukh-yoreh-deah-160 | Edition/page locks remain open for these B-grade records. |
| Medieval Christian scholasticism: loan, use, and compensation are analytically distinguished | **Directly demonstrated** | aquinas-q78-a1; aquinas-q78-a2 | Use article-level citations, not generic “Aquinas on usury.” |
| Reformation and English statutes: treatment shifts toward regulated interest | **Directly demonstrated as a legal trajectory** | calvin-de-usuris-1545; henry-viii-usury-act-1545; elizabeth-usury-act-1571; james-usury-act-1624 | Statutory propositions should retain exact regnal citations; Calvin remains edition-sensitive. |
| Public credit and banking: lending becomes institutionally connected to public finance | **Directly demonstrated** | boe-charter-1694; bank-act-1694 | Act and Charter are separate instruments and citations. |
| Classical political economy reframes interest as an economic variable | **Directly demonstrated** | adam-smith-wealth-nations-i9; bentham-defence-usury-1787; ricardo-principles-ch-v; js-mill-principles-interest | This is a conceptual synthesis across separate works, not a single-source claim. |
| Nineteenth/twentieth-century monetary architecture changes the institutional scale of credit | **Directly demonstrated** | bank-charter-act-1844; usury-laws-repeal-1854; fed-act-1913; banking-act-1933; banking-act-1935; bretton-woods-1944; bretton-woods-act-1945; nixon-1971; jamaica-1976-imf; dodd-frank-2010 | The narrative must distinguish monetary architecture from the legal history of loan interest. |
| Carolingian 789/806 material establishes a secure primary passage for anti-usury legislation | **Not sufficiently demonstrated** | carolingian-usury-aachen-nijmegen | Record remains D; secondary reports cannot be used as if the primary passage were locked. |

## Rule for publication
Where a claim crosses several periods or source traditions, the synthesis may state the pattern only when each component is independently supported. A D-grade record is never treated as proof of a major transition.