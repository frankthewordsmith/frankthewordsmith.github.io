# VERSION 6.0 — Twentieth-Century Monetary Architecture

## Scope
This release extends the passage-driven timeline from the late nineteenth-century banking architecture through the creation of the Federal Reserve, Depression-era banking reform, Bretton Woods, the 1971 suspension of dollar convertibility, the 1976 Jamaica reform, and post-crisis financial regulation.

## New primary-source targets
- 1913 — Federal Reserve Act, 38 Stat. 251; Sections 2, 13, 14 and related provisions.
- 1933 — Banking Act / Glass-Steagall; especially the provisions establishing the FOMC and deposit insurance, with exact statutory sections to be locked against the statute text.
- 1935 — Banking Act; especially Section 12A / FOMC and restructuring of Federal Reserve governance.
- 1944 — IMF Articles of Agreement and IBRD Articles of Agreement, Bretton Woods; Article IV and institutional provisions should be cited by Article/Section.
- 1945 — Bretton Woods Agreements Act, 59 Stat. 512; U.S. implementation of membership in IMF and IBRD.
- 1971 — Richard Nixon, Address to the Nation, 15 August 1971; paired with Proclamation 4074 and later official monetary records.
- 1976/1978 — Jamaica reform and Second Amendment to the IMF Articles; Article IV as amended, with the 1978 entry-into-force date distinguished from the 1976 political agreement.
- 2010 — Dodd-Frank Wall Street Reform and Consumer Protection Act, Pub. L. 111-203; primary statutory framework for post-crisis financial regulation.

## Evidence rule
Institutional history is not substituted for the primary legal or treaty text. Where an official historical essay identifies the effect of an Act but the actual statutory section has not yet been inspected, the record remains YELLOW rather than GREEN.

## Chronological caution
The Federal Reserve Act did not create the modern FOMC in its later form; the FOMC developed through the Banking Acts of 1933 and 1935. Likewise, Bretton Woods did not end in a single instant on 15 August 1971: Nixon's announcement suspended dollar convertibility, while subsequent negotiations and the 1976/1978 IMF amendments reshaped the international monetary rules.
