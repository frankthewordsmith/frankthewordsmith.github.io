# Primary Source Lockdown 7.7

| Source | Primary provenance | Exact analytical page lock | Grade | Action |
|---|---|---|---|---|
| Federal Reserve Act (1913) | Secure | Incomplete | B | Retain |
| Banking Act (1933) | Secure | Incomplete | B | Retain |
| Banking Act (1935) | Secure | Incomplete | B | Retain |
| Nixon address (1971) | Secure | Print edition not locked | B | Retain |
| IMF Second Amendment / Jamaica transition | Secure | Institutional article locator secure; print-page lock incomplete | B | Retain |
| Dodd-Frank (2010) | Secure | Selected analytical sections need page locks | B | Retain |

The purpose of this matrix is to prevent official web access from being mistaken for a locked-print primary edition.
