import json, os, re, zipfile, shutil, collections, datetime
root='/mnt/data/v60work/v53'
p=os.path.join(root,'research-data.json')
d=json.load(open(p))
# normalize statuses into publication audit classes

def cls(s):
    s=(s or '').lower()
    if 'secondary/witness' in s or 'secondary' in s or 'research target' in s or 'institutional synthesis' in s:
        return 'BLUE — secondary/witness or research-target evidence'
    if 'yellow' in s or 'pending' in s or 'edition-page' in s or 'edition/page' in s or 'pagination pending' in s:
        return 'YELLOW — primary/source identified; publication lock pending'
    if 'passage verified' in s or 'green' in s or 'primary document verified' in s or 'primary statute text verified' in s or 'official statutory text identified' in s or 'passage-level record established' in s:
        return 'GREEN — passage/source verified; check edition lock where applicable'
    if 'citation locked' in s or 'citation framework locked' in s:
        return 'YELLOW — locator locked; passage/edition verification still required'
    return 'YELLOW — manual review required'

items=d['sources']+d['records']
counts=collections.Counter(cls(x.get('verification_status','')) for x in items)
rows=[]
for x in items:
    sid=x.get('source_id') or x.get('id')
    rows.append((x.get('date_start',''),sid,x.get('title',''),cls(x.get('verification_status','')),x.get('verification_status',''),x.get('reference_number',''),x.get('source_url','')))
rows.sort(key=lambda z:(int(z[0]) if re.fullmatch(r'-?\d+',str(z[0])) else 999999,str(z[1])))

md=['# VERSION 6.1 — PRIMARY-SOURCE LOCKDOWN & FINAL AUDIT\n',
'**Audit date:** 2026-09-23\n',
'**Baseline:** Version 6.0 — Twentieth-Century Monetary Architecture\n',
'\n## Purpose\nThis release is a publication-control audit, not a new historical chapter. It tests whether each timeline item has an identifiable passage, a stable locator, an appropriate evidence class, and—where the project promises page-level precision—an edition-specific page lock.\n',
'\n## Evidence classes\n- **GREEN:** primary passage/source has been directly verified in a stable online or documentary source. This does not automatically mean the locked print edition page has been checked.\n- **YELLOW:** source or locator is identified, but the exact quotation, section, edition, or page still needs publication-level verification.\n- **ORANGE:** reconstructed, composite, fragmentary, or otherwise materially qualified primary evidence. The underlying source is primary, but wording must not be presented as an intact witness.\n- **BLUE:** secondary witness, later testimony, or research target; not suitable as a verbatim primary quotation without additional verification.\n',
'\n## Current audit counts\n']
for k,v in counts.items(): md.append(f'- {k}: **{v}** records\n')
md += ['\n## Publication blockers\n',
'- Hammurabi §88 remains reconstructed; the secure surviving debt provisions should be quoted separately.\n',
'- The Twelve Tables are not directly extant; later witnesses such as Tacitus must remain explicitly identified as witnesses.\n',
'- Roman Digest/Codex entries need individual fragment/constitution locators when a quotation is used.\n',
'- Sahnun *al-Mudawwana*, al-Shafi\'i *al-Umm*, and Ibn Qudama *al-Mughni* have stable structural locators but still lack locked-edition pagination.\n',
'- Carolingian usury legislation remains a research target until the critical capitulary edition is inspected.\n',
'- English 1571/1624 usury statutes and the 1694 Bank Act need exact statute-section/page locks before publication quotations.\n',
'- Banking Acts 1933/1935 require direct statutory section verification rather than reliance on historical summaries.\n',
'- The Jamaica/IMF 1976–78 material must distinguish the 1976 political agreement from the amended Articles entering into force in 1978.\n',
'\n## Verified institutional checkpoints\n',
'- The Federal Reserve Act of 1913 is available in official section-by-section form from the Federal Reserve and in the U.S. Statutes at Large/GovInfo. citeturn0search1turn0search0\n',
'- The Nixon August 15, 1971 address is preserved in the Nixon Library record and official presidential-document collections; the gold-convertibility suspension should be cited to the speech plus the contemporaneous executive record. citeturn0search3turn0search9\n',
'- The Bretton Woods chronology should treat the 1944 agreement, 1945 implementation, and later IMF amendments as separate documentary stages. citeturn0search5turn0search12\n',
'\n## Rule for final publication\nNo sentence in the finished 4,000-year narrative should call a passage “verified” unless the reader can be taken directly to the exact source locator. Where a print edition is promised, the edition and page must also be locked.\n']
open(os.path.join(root,'PRIMARY_SOURCE_LOCKDOWN_6_1.md'),'w').write(''.join(md))

# Full audit table
t=['# 6.1 MASTER AUDIT TABLE\n','| Date | ID | Source | Audit class | Existing status | Locator | URL |\n','|---|---|---|---|---|---|---|\n']
for date,sid,title,c,e,loc,url in rows:
    def esc(v): return str(v or '').replace('|','\\|').replace('\n',' ')
    t.append(f'| {esc(date)} | `{esc(sid)}` | {esc(title)} | {esc(c)} | {esc(e)} | {esc(loc)} | {esc(url)} |\n')
open(os.path.join(root,'MASTER_AUDIT_TABLE_6_1.md'),'w').write(''.join(t))

# Citation manifest
cm=['# CITATION MANIFEST — VERSION 6.1\n','Every public-facing factual claim should resolve to the strongest available source. The preferred order is: critical/official primary text → stable institutional archive → scholarly edition → secondary synthesis.\n\n']
for date,sid,title,c,e,loc,url in rows:
    cm.append(f'- `{sid}` — {title}; {c}; locator: {loc or "not yet specified"}; source: {url or "not supplied"}\n')
open(os.path.join(root,'CITATION_MANIFEST_6_1.md'),'w').write(''.join(cm))

# update JSON
old=d.get('audit_6_1')
d['version']='6.1'
d['audit_6_1']={'date':'2026-09-23','purpose':'Primary-source lockdown and final publication audit','counts':dict(counts),'publication_rule':'No passage is publication-verified without an exact stable locator; edition/page is mandatory where the project promises edition-specific pagination.','web_checkpoints':{'federal_reserve_act':'Official Federal Reserve and GovInfo records checked 2026-09-23','nixon_1971':'Nixon Library and State Department historical record checked 2026-09-23','bretton_woods':'Federal Reserve/official documentary chronology checked 2026-09-23'}}
json.dump(d,open(p,'w'),ensure_ascii=False,indent=2)
# version notes
open(os.path.join(root,'VERSION_6_1_NOTES.md'),'w').write('''# VERSION 6.1 NOTES\n\nVersion 6.1 is a publication-control release. It does not add a new historical period. It consolidates the passage-verification standard across the full 4,000-year timeline and identifies every remaining publication blocker.\n\n## Completed\n- Master audit table created for all source and record entries.\n- Evidence classes normalized for audit purposes.\n- Publication blockers isolated rather than silently upgraded.\n- Citation manifest generated.\n- research-data.json updated to version 6.1.\n\n## Key rule\nA familiar source title is not enough. A published quotation requires an exact locator, and an edition/page claim requires inspection of the exact locked edition. Composite and reconstructed ancient texts must remain labeled as such.\n''')

# Update visible version strings conservatively in site pages
for fn in ['index.html','timeline.html','research.html','references.html','source.html','about.html']:
    fp=os.path.join(root,fn)
    if os.path.exists(fp):
        s=open(fp,encoding='utf-8').read()
        s=re.sub(r'Version 6\.0', 'Version 6.1', s)
        s=re.sub(r'v6\.0', 'v6.1', s)
        open(fp,'w',encoding='utf-8').write(s)

# zip
out='/mnt/data/FranktheWordsmith_Version_6_1_Primary_Source_Lockdown_Final_Audit.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for dp,_,fs in os.walk('/mnt/data/v60work'):
        for f in fs:
            path=os.path.join(dp,f); arc=os.path.relpath(path,'/mnt/data/v60work'); z.write(path,arc)
print(out)
print(dict(counts))
