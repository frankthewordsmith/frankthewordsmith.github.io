# VERSION 5.8 — Eighteenth–Nineteenth-Century Interest, Banking & Monetary Theory

## Scope
This pass extends the passage-driven chronology from the early-modern legal transition into classical political economy, statutory repeal of usury controls, banking legislation, and nineteenth-century interest theory.

## Passage records added
- **Adam Smith, Wealth of Nations, I.IX (1776):** primary passage verified online. Smith discusses interest, profits, legal restrictions, and evasion. Edition-page lock remains pending.
- **Jeremy Bentham, Defence of Usury, Letter I (1787):** primary passage verified online. Bentham argues for freedom of mutually agreed money bargains; this is an economic/philosophical argument, not legislation.
- **David Ricardo, Principles of Political Economy and Taxation, ch. V (1817):** primary passage verified online. Ricardo connects persistent changes in interest with profits and discusses legal interference with market rates.
- **Bank Charter Act 1844 (7 & 8 Vict. c. 32):** statute identified; section-level publication quotation should use the official legislation text.
- **Usury Laws Repeal Act 1854 (17 & 18 Vict. c. 90):** primary statute text verified. Section I repeals existing laws against usury; Section II preserves rights/remedies concerning prior transactions.
- **John Stuart Mill, Principles of Political Economy, III.XXIII (1848):** primary passage verified online. Mill treats interest through demand and supply of loans and distinguishes market and natural rates.

## Methodological cautions
1. The repeal of usury laws is not treated as synonymous with the emergence of modern banking. These are related but distinct institutional developments.
2. Classical economists are evidence for theories and arguments, not evidence that those theories were legally adopted.
3. The 1844 Bank Charter Act is a banking/currency statute; it should not be collapsed into the history of interest-rate ceilings.
4. The 1854 repeal is a statutory endpoint for the English usury-law sequence, but later credit regulation must be traced separately.
5. Online passage verification is not substituted for the locked edition where the project's publication standard requires page-level citation.

## Next research target
The next chronological pass should examine late-nineteenth-century banking, central banking, lender-of-last-resort doctrine, monetary standards, and the legal transition from usury ceilings to modern regulation of credit and banking.
