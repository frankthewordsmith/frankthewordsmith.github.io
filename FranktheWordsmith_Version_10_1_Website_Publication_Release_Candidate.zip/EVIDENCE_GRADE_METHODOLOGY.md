# Evidence-Grade Methodology — Version 10.0

## A — Edition/locator locked
Use for the strongest publication treatment. The record has a named primary/critical edition or authoritative primary publication and an exact stable passage locator, including page where that edition uses stable pagination.

## B — Primary passage, locator stable; edition lock open
The underlying primary passage is identified and has a stable article/section/verse/chapter or comparable locator, but the archive has not established the stricter print/critical-edition page lock required for A. B is usable for qualified research claims and should not be silently described as A.

## C — Reconstructed/composite/fragmentary/later-witness
The source survives through reconstruction, composite witnesses, lacunae, fragments, or later testimony in a way that prevents a clean primary-text lock. C material may establish a historical research lead or qualified proposition but must retain its limitation in the narrative.

## D — Unresolved
The record remains a research target without enough direct evidence for publication-level passage use. D material should not be presented as a verified passage.

## General rules
1. Primary text comes before interpretation.
2. Exact internal locators are preferred to generic page references.
3. Page numbers belong to a named edition and must never be transferred between editions.
4. Online verification is not automatically print-edition verification.
5. Chronological confidence and textual/edition confidence are separate.
6. Legal statutes, religious norms, contracts, administrative records, and later scholarly interpretations are different evidence types and are not interchangeable.
7. Where uncertainty remains, the uncertainty is part of the citation record.

The Library of Congress similarly emphasizes identifying the source's version/edition, publisher/date, and location when citing digitized primary sources. citeturn0search1turn0search3
