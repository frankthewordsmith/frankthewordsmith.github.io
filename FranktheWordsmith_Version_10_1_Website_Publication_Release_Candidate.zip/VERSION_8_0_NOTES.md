# Version 8.1 — Definitive Publication Edition

## Status
Publication freeze of the passage-driven 4,000-year research archive.

## What is frozen
- 59 canonical source records.
- Evidence grades: A=8, B=46, C=4, D=1.
- Source-to-claim traceability and chronology audit completed through v7.9.
- Primary-source hierarchy preserved: surviving primary text > later witness/reconstruction > secondary source > institutional summary.
- No B/C/D source is silently presented as A-grade.
- Fragmentary and reconstructed ancient material remains explicitly qualified.

## Publication rule
A source is A-grade only where the project has a verified primary text, an identified edition/version, and an exact stable locator sufficient for independent checking. Online verification alone does not equal a locked print-page verification.

## Citation rule
The publication edition follows the general primary-source principle that citations should give readers enough information to identify and retrieve the source, including version/edition and location where applicable. The Library of Congress likewise emphasizes complete identification and source location for digitized primary materials.

## Scope
This is a definitive research/publication edition, not a claim that every historical passage has an A-grade print-page lock. The remaining B/C/D classifications are part of the scholarly result and must remain visible.
