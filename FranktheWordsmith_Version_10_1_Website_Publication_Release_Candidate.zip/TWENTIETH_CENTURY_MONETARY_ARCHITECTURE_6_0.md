# Version 6.0 — Twentieth-Century Monetary Architecture

| Date | Primary document | Passage/locator | Status | Historical function |
|---|---|---|---|---|
| 1913 | Federal Reserve Act | §§2, 13, 14 | GREEN/YELLOW | Creation of Federal Reserve System; rediscounting and Reserve Bank operations |
| 1933 | Banking Act / Glass-Steagall | FOMC and banking provisions | YELLOW | Depression-era banking and open-market reform |
| 1935 | Banking Act | Title II; §12A amendments | YELLOW | Modern FOMC structure and Federal Reserve governance |
| 1944 | IMF/IBRD Articles | Articles I–IV and institutional provisions | GREEN | Bretton Woods international monetary institutions |
| 1945 | Bretton Woods Agreements Act | 59 Stat. 512 | GREEN/YELLOW | U.S. domestic implementation |
| 1971 | Nixon address | 15 Aug. 1971 | GREEN | Suspension of dollar convertibility |
| 1976/78 | IMF Second Amendment | Article IV | YELLOW | Post-Bretton-Woods exchange arrangements |
| 2010 | Dodd-Frank | Pub. L. 111-203 | GREEN | Post-crisis financial regulation |

## Methodological note
The timeline does not collapse these events into a single continuous legal doctrine. Each record identifies the actual institutional or legal object documented by the primary source.
