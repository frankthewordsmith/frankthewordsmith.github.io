# Version 6.4 Notes — Final Primary-Source Evidence Lock

## Purpose
Version 6.4 does not broaden the chronology. It converts the Version 6.3 publication-lock work into a conservative evidence-grade system and creates the master passage table that will drive the final 4,000-year synthesis.

## Evidence grades
- **A** — primary text plus exact edition/locator/page (or equivalent critical-edition unit) locked for publication quotation.
- **B** — primary text and stable passage locator verified, but print-edition/page locking remains incomplete.
- **C** — composite, reconstructed, later-witness, or otherwise indirect evidence.
- **D** — research target whose critical-edition passage is not yet isolated.

The archive intentionally errs toward the lower grade. A source is not upgraded merely because a webpage reproduces a text.

## Targeted confirmations
- Justinian, *Digest* 22.1 is organized as **De usuris et fructibus et causis et omnibus accessionibus et mora**, and individual fragments such as D.22.1.1 are available in the Mommsen-based online Latin text.
- Federal Reserve Act §12A provides the statutory text of the Federal Open Market Committee; the current Federal Reserve transcription identifies the provision as added in 1933 and completely revised in 1935.
- Maimonides, *Mishneh Torah*, Creditor and Debtor 4:5 and 5:2 are directly locatable in Sefaria.
- *Shulchan Arukh*, Yoreh De'ah 161:1 is directly locatable in Sefaria.

## Important correction
The Exodus record now points consistently to **Exodus 22:25 in common modern verse numbering** rather than retaining the earlier mismatched URL.

## Next stage
Version 6.5 should use this table to write the passage-driven 4,000-year synthesis. Remaining A-grade publication locks can be completed in parallel, but C/D material must remain visibly labeled and must not be silently converted into primary quotations.
